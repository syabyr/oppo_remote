
var querystring=require("querystring");
var http = require('http');
var url = require('url');
var fs = require('fs');
var port = 8081;

function find_newest_version(version_arr)
{
	var newesta = 0;
	for(var i=0;i<version_arr.length;i++)
	{
		if(parseInt(version_arr[i]) > newesta)
		{
			newesta = parseInt(version_arr[i]);
		}
	}
	for(var i=0;i<version_arr.length;i++)
	{
		if(parseInt(version_arr[i]) == newesta)
		{
			return version_arr[i];
		}
	}
}
function onRequest(req, res) 
{
	var get = url.parse(req.url);
	var pathname = get.pathname;
	var query = querystring.parse(get.query);
	var method = req.method;
	//console.log("request for " + pathname + " received.");
	//console.log(query);
	if(pathname == "/upgrade/query")
	{
		console.log('a gateway query upgrade:'+query.hid);
		if(query.model == "2000A")
		{
			if(query.hdv == "1.0")
			{
				var fwvs = query.fwv.split('.');
				var fwv = parseInt(fwvs[0])*100 + parseInt(fwvs[1])*10 + parseInt(fwvs[2]);
				var version_arr = fs.readdirSync('firmware/hs2000a');
				//console.log(version_arr);
				var newesta = find_newest_version(version_arr);
				var newestv = parseInt(newesta);
				//console.log(newesta);
				//console.log(newestv);
				//console.log(fwv);
				var file_arr = fs.readdirSync('firmware/hs2000a/' + newesta);
				//console.log(file_arr);
				if(fwv < newestv)
				{
					//console.log("this gateway can upgrade");
					res.writeHead(200,{"Content-Type": "text/plain"});
					res.write("FOUNDUP\r\nfirmware/hs2000a/" + newesta + "/\r\n"+file_arr[0]+"\r\n"+file_arr[1]+"\r\n");
					res.end(); 
				}
				else
				{
					//console.log("this gateway have newest firmware");
					res.writeHead(200,{"Content-Type": "text/plain"});
					res.write("NEWEST\r\nfirmware/hs2000a/" + newesta + "/\r\n"+file_arr[0]+"\r\n"+file_arr[1]+"\r\n");
					res.end(); 
				}
			}
		}
	}
	else if(pathname == "/upgrade/download")
	{
		var file = query.file;
		//console.log("download:"+file);
		var r = fs.createReadStream(file);
		var size = fs.statSync(file).size;
		//console.log("size="+size);
		res.writeHead(200,{	"Content-Length": size});
		if(method == "GET")
		{
			r.on("error", function() { 
				res.writeHead(404); 
				res.end(); 
				console.log("read file fail");
			});
			r.pipe(res);
		}
		else
		{
			res.end();
		}
	}
}
function on()
{
	http.createServer(onRequest).listen(port,function(){
		console.log('OTA Server running : '+port);
	});
}
exports.on = on;