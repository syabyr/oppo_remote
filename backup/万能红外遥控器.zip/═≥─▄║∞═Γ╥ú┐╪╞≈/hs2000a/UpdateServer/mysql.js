var mysql  = require('mysql');  //调用MySQL模块
var connection = mysql.createConnection({
	host     : '250.qiaohui.me',
	user     : 'root',
	password : 'd7739b87',
	database : 'server2000a',
});
connection.connect(function(err)
{
    if(err)
    {       
        console.log('[connection.connect] - :'+err);
        return;
    }
    console.log('[connection.connect]  succeed!' + new Date());
});
connection.query('select * from gateway', function(err, res, fields) 
{
	if (err)
	{
		console.log(err);
		return;
	}
  	console.log(res);
  	console.log(fields);
});
connection.query('SELECT 1 + 1 AS solution', function(err, rows, fields) {
    if (err) 
    {
    	console.log('[connection.query] - :'+err);
    	return;
    }
    console.log('The solution is: ', rows[0].solution);
});



























connection.end(function(err)
{
    if(err)
    {       
        console.log('[connection.end] - :'+err);
        return;
    }
    console.log('[connection.end] succeed!' + new Date());
});












