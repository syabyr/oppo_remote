var nodemailer = require("nodemailer");
var smtpTransport = require('nodemailer-smtp-transport');
var transporter = nodemailer.createTransport(smtpTransport({
    host:"smtp.qq.com",
    secure:true,
    port:465,
    auth:{
        user: "server2000a",
        pass: "server2000a"
    }
}));
transporter.sendMail(
    {
        from: 'server2000a@qq.com',
        to: 'chengjia535@qq.com',
        subject: 'hello world!',
        text: 'Authenticated with SSL'
    },
    function(error,response){
        console.log(error,response);
});
