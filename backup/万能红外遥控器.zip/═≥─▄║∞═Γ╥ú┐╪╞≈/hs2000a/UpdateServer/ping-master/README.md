#Hello, Ping.

##静态文件服务器部分
[用Node.js打造你的静态文件服务器](http://cnodejs.org/blog/?p=3904)

##动态文件服务器部分
[用Node.js构建动态服务器基础](http://cnodejs.org/blog/?p=4520)
