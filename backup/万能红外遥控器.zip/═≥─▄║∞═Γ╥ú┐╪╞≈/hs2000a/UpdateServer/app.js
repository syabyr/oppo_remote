/**
 * Cloud Server Launcher for HS2000A
 */

var cluster = require('cluster');
var http = require('http');
var numCPUs = require('os').cpus().length;

if (cluster.isMaster) {
	// Fork workers.
	for (var i = 0; i < numCPUs; i++) {
		cluster.fork();
	}
	cluster.on('fork', function(worker, code, signal) {
		console.log('worker ' + worker.process.pid + ' started');
	});
	cluster.on('exit', function(worker, code, signal) {
		console.log('worker ' + worker.process.pid + ' died');
		cluster.fork();
	});

} else {
	
	startService()

	process.on('uncaughtException', function() {
		console.log(err);
		//Send some notification about the error
		process.exit(1);
	});
	
}

function startService() {
	var upgrader = require("./upgrade");
	upgrader.on();
}