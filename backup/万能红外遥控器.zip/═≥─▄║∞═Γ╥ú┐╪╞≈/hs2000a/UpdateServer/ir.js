var dgram = require("dgram");
var server = dgram.createSocket("udp4");
var querystring=require("querystring");
var fs=require('fs');
var algo = require('ape-algorithm');

var port = 8266;

var irlib = new Array();

server.on("error", function (err) {
  console.log("server error:\n" + err.stack);
  server.close();
});
server.on("message", function (msg, rinfo) {
	console.log("server got: " + msg + " from " + rinfo.address + ":" + rinfo.port);
	var query = querystring.parse(msg.toString());
	console.log(query);
	if(query.request == "analysis_ir")
	{
		compare(rinfo,query.brand,query.data);
	}
});
server.on("listening", function () {
  var address = server.address();
  console.log("IR server listening" + ": " + address.port);
});
server.bind(port);

function hex2dec(d) {
	return parseInt(d, 16);
}
function hex2arr(code) 
{
	code = code.toLowerCase();
	var data = [];
	if (/^([0-9a-fA-F]{2})*$/.test(code)) 
	{
		for (var i = 0; i < code.length; i += 2) 
		{
			data[i / 2] = hex2dec(code.substr(i, 2));
		}
	} 
	else 
	{
		throw "hex2array: invalid hex string";
	}
	return data;
}

function compare(rinfo,bid,data)
{
	var arr = hex2arr(data);
	var err = new Array();
	for(var i=0;i<irlib.length;i++)
	{
		var erri = new Object();
		erri.index = i;
		erri.err = 0;
		for(var j=0;j<110;j++)
		{
			var delta = Math.abs(irlib[i][j] - arr[j]);
			if((delta*5) > irlib[i][j])
			{
				erri.err++;
			}
		}
		if(bid == 0)
		{
			err.push(erri);
		}
		else
		{
			if(JsonObj[i].bid == bid)
			{
				err.push(erri);
			}
		}
	}
	err = algo.quicksort.sortObj(err,'err','asc');
	e = err[0].err;
	var str="";
	for(var i=0;i<3;i++)
	{
		var index = err[i].index;
		//if(err[i].err == e)
		{
			console.log("error = " + err[i].err);
			console.log(JsonObj[index].brand + " " + JsonObj[index].index);
		}
		str= str + "brand=";
		str = str + JsonObj[index].brand;
		str = str + ",index=";
		str = str + JsonObj[index].index;
		str = str + ",model=";
		str = str + JsonObj[index].bid;
		str = str + "\r\n";
		
	}
	var rsp = new Buffer(str);
	server.send(rsp, 0, rsp.length, rinfo.port, rinfo.address, function(err) 
	{
		if(err!=null)
		{
			console.log("send error:" + err.stack);
			server.close();
		}
	});	
}

//var JsonObj = JSON.parse(fs.readFileSync('ir_analysis.out.json'));
var JsonObj = JSON.parse(fs.readFileSync('ir_slib.json'));
function load()
{
	for(var i=0;i<JsonObj.length;i++)
	{
		irlib[i] = hex2arr(JsonObj[i].data);
		//console.log(irlib);
		//console.log(JsonObj[i].data);
		//console.log(JsonObj[i].brand + " " + JsonObj[i].en + " " + JsonObj[i].index);
	}
	//console.log(irlib[0]);
}
exports.on = load;
