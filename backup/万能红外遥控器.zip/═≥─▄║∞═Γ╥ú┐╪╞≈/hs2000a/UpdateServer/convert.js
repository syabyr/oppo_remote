var fs = require('fs');

var Converter = {
	data: null,
	brands: {},
	init: function() {
	},
	load: function(filename) {
		var self = this;
		fs.readFile(filename, 'utf8', function(err, data) {
			if (err) throw err;
			console.log('file load ok!', 'len=', data.length);
			self.data = JSON.parse(data);
			self.convert();
		});
	},
	findbrands: function() {
		var self = this;
		var brands = {};
		var data = self.data;
		var n = 1;
		for (var i in self.data) {
			var namecn = data[i].brand;
			if (!brands.hasOwnProperty(namecn)) {
				brands[namecn] = n++;
			}
		}
		console.log(brands);
		self.brands = brands;
	},
	update: function() {
		var self = this;
		var data = self.data;
		var brands = self.brands;
		for (var i in data) {
			var namecn = data[i].brand;
			data[i].bid = brands[namecn] || 0;
		}
	},
	save: function() {
		var self = this;
		var data = self.data;
		var brands = self.brands;
		fs.writeFile('ir_analysis.out.json', JSON.stringify(self.data, null, 2));
		var txt = [];
		txt.push('const char* brands[] = {');
		txt.push('\t"",');
		for (var name in brands) {
			var index = brands[name];
			txt.push('\t"'+name+'", // '+index);
		}
		txt.push('};');
		fs.writeFile('ir_brands.c', txt.join('\n'), function(err) {
			if (err) throw err;
			console.log('saved!');
		})
	},
	convert: function() {
		var self = this;
		console.log('data length:', self.data.length);
		self.findbrands();
		self.update();
		self.save();
	},
	process: function(filename) {
		var self = this;
		self.load(filename);
	}
}

Converter.process('ir_analysis.json');



