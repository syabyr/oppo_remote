var dgram = require("dgram");
var server = dgram.createSocket("udp4");
var message = new Buffer("Some bytes");

function getIPAdress(){
    var interfaces = require('os').networkInterfaces();
    for(var devName in interfaces)
    {
          var iface = interfaces[devName];
          for(var i=0;i<iface.length;i++)
          {
               var alias = iface[i];
               if(alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal)
               {
                     //return alias.address;
               }
               console.log(alias);
          }
    }
}
server.on("error", function (err) {
  console.log("server error:\n" + err.stack);
  server.close();
});
server.on("message", function (msg, rinfo) {
	var inbuf = new Buffer(msg);
	console.log("server got: " + inbuf.toString("hex") + " from " + rinfo.address + ":" + rinfo.port);
	

	var len = inbuf[1] * 256 + inbuf[0];
	var crc = inbuf[3] * 256 + inbuf[2];
	var proto = inbuf[5] * 256 + inbuf[4];
	var srcmac = new Buffer(6);
	msg.copy(srcmac,0,6,12);
	var msgtype = inbuf[19] * 256 + inbuf[18];
	console.log("len=" + len + 
	" crc=" + crc + 
	" proto=" + proto + 
	" srcmac=" + srcmac.toString("hex") +
	" msgtype=" + msgtype.toString(16));
	
	
	
	
	
	
	
	server.send(message, 0, message.length, rinfo.port, rinfo.address, function(err) {
		if(err!=null)
		{
			console.log("send error:" + err.stack);
			server.close();
		}
	});
});
server.on("listening", function () {
  var address = server.address();
  console.log("server listening " +
      "250.qiaohui.me" + ":" + address.port);
});
server.bind(65501);
