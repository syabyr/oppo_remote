var net = require("net");
var GatewayPool = [];
var AppPool = [];

var GatewayServer = net.createServer(function(socket) {
	GatewayPool.push(socket);
	socket.on('end', function() {
		console.log('GatewayServer disconnected');
	});
	socket.on('error', function() {
		console.log('GatewayServer error');
	});
	socket.on('data', function(data) {
		broadcast(AppPool, data);
		console.log('Gateway:' + data.toString());
		if(data == "gettime")
		{
			socket.write('i will give you time' + new Date() + '\r\n');
		}
		//socket.write('"action": "sys_upgrade"&"version":233\r\n');
		socket.write('i am server\r\n');
	});
});

var AppServer = net.createServer(function(socket) {
	AppPool.push(socket);
	socket.on('end', function() {
		console.log('AppServer disconnected');
	});
	socket.on('error', function() {
		console.log('AppServer error');
	});
	socket.on('data', function(data) {
		broadcast(GatewsyPool, data);
		console.log('App:' + data.toString());
		socket.write('AppServer:hello\r\n');
	});
});

function broadcast(group, data) {
	console.log(group.length);
	for (var i in group) {
		var socket = group[i];
		socket.write(data);
	}
}

GatewayServer.on('connection', function(socket) {
	console.log('a gateway connected: ' + socket.remoteAddress + ':' + socket.remotePort);
});
AppServer.on('connection', function(socket) {
	console.log('a app connected: ' + socket.remoteAddress + ':' + socket.remotePort);
});
GatewayServer.listen(8000);
AppServer.listen(8443);
