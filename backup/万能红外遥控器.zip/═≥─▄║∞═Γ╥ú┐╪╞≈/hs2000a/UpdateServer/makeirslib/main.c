#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    FILE *fold;
    FILE *fnew;
    FILE *fp;
    char *start;
    char *stop;
    char strline[1024];
    char brand[100];
    char index[100];
    char en[100];
    char data[1024];
    char bidstr[100];
    unsigned long bid=0;
    unsigned long last_bid=0;
    fold = fopen("arc_����1һ��ƥ������-5.8-V1.0.c","rb");
    if(fold == NULL)
    {
        return 0;
    }
    fnew = fopen("ir_slib.json","w+");
    if(fnew == NULL)
    {
        fclose(fold);
        return 0;
    }
    fp = fopen("ir_brands.c","w+");
    if(fp == NULL)
    {
        fclose(fold);
        fclose(fnew);
        return 0;
    }
    fputs("const char *brands[] = {\n\t\"\",\t\t\t// 0\n",fp);

    fputs("[\n",fnew);
    while(fgets(strline,300,fold))
    {
        if(strstr(strline,"==="))
        {
            bid++;
        }
        start = strstr(strline,"//�յ� ");
        if(start)
        {
            //printf("%s",start);
            start = strstr(strline," ");

            start = start + 1;
            stop = strstr(start,"(");
            strncpy(brand,start,stop-start);
            brand[stop-start] = '\0';
            printf("brand = %s\r\n",brand);

            start = stop + 1;
            stop = strstr(start,")");
            strncpy(en,start,stop-start);
            en[stop-start] = '\0';
            printf("en = %s\r\n",en);

            start = stop + 1;
            if(*start==' ')
            {
                start = strstr(start," ");
                start = start + 1;
            }
            stop = strstr(start,"\r");
            strncpy(index,start,stop-start);
            index[stop-start] = '\0';
            printf("index = %s\r\n",index);

            if(fgets(strline,300,fold))
            {
                start = strstr(strline,"\"");
                start = start + 1;
                stop = strstr(start,"\"");
                strncpy(data,start,stop-start);
                data[stop-start] = '\0';
                //printf("data = %s\r\n",data);

                fputs("\t{\n\t\t\"brand\": \"",fnew);
                fputs(brand,fnew);
                fputs("\",\n\t\t\"en\": \"",fnew);
                fputs(en,fnew);
                fputs("\",\n\t\t\"index\": ",fnew);
                fputs(index,fnew);
                fputs(",\n\t\t\"data\": \"",fnew);
                fputs(data,fnew);
                fputs("\",\n\t\t\"bid\": ",fnew);
                itoa(bid,bidstr,10);
                fputs(bidstr,fnew);
                fputs("\n\t},\n",fnew);

                if(last_bid != bid)
                {
                    last_bid = bid;
                    fputs("\t\"",fp);
                    fputs(brand,fp);
                    fputs("\",\t\t// ",fp);
                    fputs(bidstr,fp);
                    fputs("\n",fp);
                }
            }
        }
    }
    fseek(fnew,-3,SEEK_CUR);
    fputs("\n]",fnew);

    fputs("};",fp);

    printf("Complete!\n");
    fclose(fold);
    fclose(fnew);
    fclose(fp);
    return 1;
}
