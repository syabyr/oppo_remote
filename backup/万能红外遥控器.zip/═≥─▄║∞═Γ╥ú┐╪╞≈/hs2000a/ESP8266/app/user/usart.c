#include "include.h"

unsigned char RXcounter;
unsigned char RXbuffer[UART_RX_BUFFER_SIZE];
u8 usart_rx_lock;

void ICACHE_FLASH_ATTR usart_display_cmd(u8 *buf, u8 len, char *str, u8 flag)
{
	if (Sys.debug == 0 && flag == 0)
	{
		return;
	}
	u8 i;
	ESP_DBG("%d-%d-%d %d:%d:%d-> ", Sys.Time.rtc.uwYear, Sys.Time.rtc.ucMon + 1,
			Sys.Time.rtc.ucDay, Sys.Time.rtc.ucHour, Sys.Time.rtc.ucMin,
			Sys.Time.rtc.ucSec);
	ESP_DBG(str);
	ESP_DBG(" -> %d : ", len);
	for (i = 0; i < len; i++)
	{
		ESP_DBG("%02x ", buf[i]);
	}
	ESP_DBG("\r\n");
}
void ICACHE_FLASH_ATTR usart_recv_cb(u8 *buf, u8 len)
{
	u8 cmd;
	if (Sys.Mcup.State != 0)
	{
		mcup_recv_cb(buf, len);
		return;
	}
	if (len != buf[0])
	{
		return;
	}
	cmd = buf[1];
	if (cmd == USART_CMD_DIS_USART)
	{
		ESP_DBG("mcu -> %s", &buf[2]);
	}
	else if (cmd == USART_CMD_ACK)
	{
		usart_display_cmd(buf, len, "USART_CMD_ACK", 1);
	}
	else if (cmd == USART_CMD_REPORT_VERSION)
	{
		Sys.Mcu.Version = buf[2];
		ESP_DBG("mcu firmeare verion = %d.%d\r\n", Sys.Mcu.Version >> 4,
				Sys.Mcu.Version & 0xf);
		if (Sys.Mcu.Version < IOT_MCU_VERSION)
		{
			mcu_boot();
		}
	}
	else if (cmd == USART_CMD_GET_24G)
	{
		usart_display_cmd(buf, len, "USART_CMD_GET_24G", 0);
		if (buf[2] == 0x01)
		{
			if (Sys.Status.study && Sys.Status.study_type == STUDY_24G)
			{
				Sys.Status.study = 0;
				led_green_off();
				do_add_device_now(PRODUCT_SKU_24G1, &buf[6]);
			}
		}
		else if (buf[2] == 0x02)
		{
			usart_display_cmd(buf, len, "USART_CMD_GET_24G", 0);
			RF24G *prf24g = (RF24G*) &buf[3];
			if (prf24g->Bytes.cmd == RF_CMD_PAIR)
			{
				if (Sys.Status.study && Sys.Status.study_type == STUDY_REPT)
				{
					Sys.Status.study = 0;
					save_repeater(prf24g);
					led_green_off();
				}
			}
			else if (prf24g->Bytes.cmd == RF_CMD_IR_REPORT)
			{
				if (prf24g->Bytes.para[0] == 0x01)
				{
					memcpy(&Sys.buf[0], &prf24g->Bytes.para[1], 40);
				}
				else if (prf24g->Bytes.para[0] == 0x02)
				{
					memcpy(&Sys.buf[40], &prf24g->Bytes.para[1], 40);
				}
				else if (prf24g->Bytes.para[0] == 0x03)
				{
					memcpy(&Sys.buf[80], &prf24g->Bytes.para[1], 30);
					if (Sys.Status.study)
					{
						if (Sys.Status.study_type == STUDY_IR
								|| Sys.Status.study_type == STUDY_USER)
						{
							Sys.Status.study = 0;
							ESP_DBG("repeater report ir data\r\n");
							ir_learn_rept(find_rept_by_id(prf24g->Bytes.id),
									Sys.buf);
						}
					}
				}
			}
			else if (prf24g->Bytes.cmd == RF_CMD_FactTest)
			{
				ESP_DBG("2.4G����OK.\r\n");
			}
			else if (prf24g->Bytes.cmd == RF_CMD_FactTestRsp)
			{
				ESP_DBG("hs24g=000000----------------24g-------------24g\r\n");
			}
		}
	}
	else if (cmd == USART_CMD_GET_433)
	{
		usart_display_cmd(buf, len, "USART_CMD_GET_433", 0);
		u8 i;
		u32 tempp = 0;
		for (i = 0; i < 24; i++)
		{
			tempp <<= 1;
			if (buf[i * 2 + 7] > buf[i * 2 + 8])
			{
				tempp += 1;
			}
		}
		os_printf("433 received:%x\r\n", tempp);
		if (tempp == 0x687364 || tempp == 0x647368)
		{
			ESP_DBG("433����OK.\r\n");
		}
		if (Sys.Status.study && Sys.Status.study_type == STUDY_USER)
		{
			os_timer_disarm(&ir_learn_timer);
			Sys.Status.study = 0;
			led_green_off();
			u8 devn = find_dev_by_id(Sys.NetSend.id);
			ESP_DBG("devn=%d sku=%x\r\n", devn, Sys.Config.Device[devn].sku);
			save_study(Sys.NetSend.id, PRODUCT_TYPE_433, Sys.Status.study_func,
					&buf[3], len - 3);
		}
	}
	else if (cmd == USART_CMD_GET_315)
	{
		usart_display_cmd(buf, len, "USART_CMD_GET_315", 0);
		u8 i;
		u32 tempp = 0;
		for (i = 0; i < 24; i++)
		{
			tempp <<= 1;
			if (buf[i * 2 + 7] > buf[i * 2 + 8])
			{
				tempp += 1;
			}
		}
		if (tempp == 0x687364 || tempp == 0x647368)
		{
			ESP_DBG("315����OK.\r\n");
		}
		if (Sys.Status.study && Sys.Status.study_type == STUDY_USER)
		{
			os_timer_disarm(&ir_learn_timer);
			Sys.Status.study = 0;
			led_green_off();
			u8 devn = find_dev_by_id(Sys.NetSend.id);
			ESP_DBG("devn=%d sku=%x\r\n", devn, Sys.Config.Device[devn].sku);
			save_study(Sys.NetSend.id, PRODUCT_TYPE_315, Sys.Status.study_func,
					&buf[3], len - 3);
		}
	}
	else
	{
		usart_display_cmd(buf, len, "USART_CMD_UNKNOW", 0);
	}
}
void uart0_rx_handle(u8 c)
{
	usart_rx_lock = 1;
	RXbuffer[RXcounter++] = c;
}
void ICACHE_FLASH_ATTR usart_rx(void)
{
	if (usart_rx_lock)
	{
		usart_rx_lock = 0;
		return;
	}
	if (RXcounter)
		usart_recv_cb(RXbuffer, RXcounter);
	RXcounter = 0;
}
void ICACHE_FLASH_ATTR usart0_putc(u8 c)
{
	uart0_tx_buffer(&c, 1);
}

void ICACHE_FLASH_ATTR print_buffer(u8 *buf, u32 len)
{
	u32 i;
	for (i = 0; i < len; i++)
	{
		ESP_DBG("%02x ", buf[i]);
	}
	ESP_DBG("\r\n");
}
