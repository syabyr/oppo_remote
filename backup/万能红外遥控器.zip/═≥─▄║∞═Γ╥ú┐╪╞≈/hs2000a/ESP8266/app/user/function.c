#include "include.h"

LOCAL os_timer_t check_timer;
os_timer_t iot_beat_timer;
os_timer_t hex_beat_timer;
os_timer_t ir_learn_timer;
LOCAL os_timer_t t500ms_timer;
LOCAL os_timer_t t1s_timer;
LOCAL os_timer_t scene_timer;
//LOCAL os_timer_t sent_timer;
LOCAL os_timer_t usart_timer;

void ICACHE_FLASH_ATTR study_flash_erase(void)
{
	u32 i;
	u8 *buf = (u8 *) os_zalloc(SPI_FLASH_SEC_SIZE);
	for (i = 0; i <= (MAX_STUDY * sizeof(STUDY) / SPI_FLASH_SEC_SIZE); i++)
	{
		system_soft_wdt_feed();
		ESP_DBG("study_flash_erase:%d\r\n",
		STUDY_ADDR / SPI_FLASH_SEC_SIZE + i);
		spi_flash_erase_sector(STUDY_ADDR / SPI_FLASH_SEC_SIZE + i);
		spi_flash_write(
				(STUDY_ADDR / SPI_FLASH_SEC_SIZE + i) * SPI_FLASH_SEC_SIZE,
				(uint32*) buf, SPI_FLASH_SEC_SIZE);
	}
	os_free(buf);
}
void ICACHE_FLASH_ATTR study_ram2flash(u8 studyn, STUDY *pstudy)
{
	u32 i;
	u32 sector;
	u8 *buf = (u8 *) os_zalloc(SPI_FLASH_SEC_SIZE);
	system_soft_wdt_feed();
	sector = (STUDY_ADDR + studyn * sizeof(STUDY)) / SPI_FLASH_SEC_SIZE;
	spi_flash_read(sector * SPI_FLASH_SEC_SIZE, (uint32*) buf,
	SPI_FLASH_SEC_SIZE);
	spi_flash_erase_sector(sector);
	ESP_DBG("study_ram2flash:sector=%d,studyn=%d\r\n", sector, studyn);
	os_memcpy(buf + (studyn % 4) * sizeof(STUDY), pstudy, sizeof(STUDY));
	spi_flash_write(sector * SPI_FLASH_SEC_SIZE, (uint32*) buf,
	SPI_FLASH_SEC_SIZE);
	os_free(buf);
}
void ICACHE_FLASH_ATTR config_ram2flash(void)
{
	u16 i;
	for (i = 0; i <= (sizeof(Sys.Config) / SPI_FLASH_SEC_SIZE); i++)
	{
		ESP_DBG("spi_flash_erase_sector:%d\r\n",
		CONFIG_ADDR / SPI_FLASH_SEC_SIZE + i);
		spi_flash_erase_sector(CONFIG_ADDR / SPI_FLASH_SEC_SIZE + i);
	}
	spi_flash_write(CONFIG_ADDR, (uint32*) &Sys.Config, sizeof(Sys.Config));
}
void ICACHE_FLASH_ATTR config_flash2ram(void)
{
	ESP_DBG("Config size: %d\r\n", sizeof(Sys.Config));
	spi_flash_read(CONFIG_ADDR, (uint32*) &Sys.Config, sizeof(Sys.Config));
}
//frank
void ICACHE_FLASH_ATTR check_nid_fake(void)
{
	u8 i;
	for (i = 0; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].nid == 0)
		{
			if (Sys.Config.Device[i].sn != 0 || i == 0)
			{
				if (i == 0)
				{
					Sys.Config.Device[i].nid = 0;
					Sys.Config.Device[i].fakeid = 1;
				}
				else
				{
					Sys.Config.Device[i].nid |= Sys.Net.stamac[3];
					Sys.Config.Device[i].nid <<= 8;
					Sys.Config.Device[i].nid |= Sys.Net.stamac[4];
					Sys.Config.Device[i].nid <<= 8;
					Sys.Config.Device[i].nid |= Sys.Net.stamac[5];
					Sys.Config.Device[i].nid <<= 8;
					Sys.Config.Device[i].nid |= Sys.Config.Device[i].sn;
					Sys.Config.Device[i].fakeid = 1;
				}

				/*
				 Sys.Config.Device[i].nid |= Sys.Net.stamac[3];
				 Sys.Config.Device[i].nid <<= 8;
				 Sys.Config.Device[i].nid |= Sys.Net.stamac[4];
				 Sys.Config.Device[i].nid <<= 8;
				 Sys.Config.Device[i].nid |= Sys.Net.stamac[5];
				 Sys.Config.Device[i].nid <<= 8;
				 Sys.Config.Device[i].nid |= Sys.Config.Device[i].sn;
				 Sys.Config.Device[i].fakeid = 1;
				 */
			}
		}
	}
}
void ICACHE_FLASH_ATTR display_devices(void)
{
	u8 i;
	u8 j = 0;
	for (i = 1; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].sku == 0 && Sys.Config.Device[i].sn != 0)
		{
			j++;
		}
	}
	if (j < 5)
	{
		ESP_DBG("display_devices:ready item less than 5:%d\r\n", j);
		for (i = 1; i < MAX_DEVICE; i++)
		{
			if (Sys.Config.Device[i].sku == 0 && Sys.Config.Device[i].sn == 0)
			{
				Sys.Config.sn++;
				if (Sys.Config.sn > 254)
				{
					Sys.Config.sn = 1;
				}
				Sys.Config.Device[i].sn = Sys.Config.sn;
				config_ram2flash();
				os_timer_disarm(&iot_beat_timer);
				os_timer_setfn(&iot_beat_timer, (os_timer_func_t *) iot_beat,
				NULL);
				os_timer_arm(&iot_beat_timer, BEAT_TIME_IOT_F, 1);
				Sys.idbeatcout = 0;
				Sys.idready = 0;
				break;
			}
		}
		if (i == MAX_DEVICE)
		{
			ESP_DBG("display_devices:blank item is very low\r\n");
		}
	}
	check_nid_fake();
	for (i = 0; i < MAX_DEVICE; i++)
	{
		Sys.Config.Device[i].name[NAME_LEN - 1] = 0;
		if (Sys.Config.Device[i].sn != 0 || i == 0)
		{
			ESP_DBG(
					"DEV[%02d].nid=%d,sn=%02d,sku=%04X type=%02d brand=%04x model=%04x name=%s\r\n",
					i, Sys.Config.Device[i].nid, Sys.Config.Device[i].sn,
					Sys.Config.Device[i].sku, Sys.Config.Device[i].type,
					Sys.Config.Device[i].brand, Sys.Config.Device[i].model,
					Sys.Config.Device[i].name);
		}
		for (j = 0; j < MAX_SCENE; j++)
		{
			if (Sys.Config.Device[i].Scene[j].action.powertemp != 0)
			{
				ESP_DBG("       scene[%d]:cmd=%x\r\n", j,
						Sys.Config.Device[i].Scene[j].action.powertemp);
			}
		}
	}
}
void ICACHE_FLASH_ATTR sys_ram_init(void)
{
	u32 i, j;
	Sys.Config.Device[0].sku = PRODUCT_SKU_LVC2000A;
	if (Sys.Config.Device[0].name[0] == 0)
	{
		strcpy(Sys.Config.Device[0].name, "ŷ������ң�غ�");
	}
	Sys.Time.rtc.uwYear = 2000;		// Year
	Sys.Time.rtc.ucMon = 1;			// May
	Sys.Time.rtc.ucDay = 1;			// Day
	Sys.Time.rtc.ucWDay = 1;		// Sat
	i = system_get_chip_id();
	ESP_DBG("cpu id = %08X\r\n", i);
	wifi_get_macaddr(STATION_IF, Sys.Net.stamac);
	ESP_DBG("MACADDR = %02X %02X %02X %02X %02X %02X \r\n", Sys.Net.stamac[0],
			Sys.Net.stamac[1], Sys.Net.stamac[2], Sys.Net.stamac[3],
			Sys.Net.stamac[4], Sys.Net.stamac[5]);
	Sys.NetSend.no = 100000;
	ESP_DBG("PassWord:");
	for (i = 0; i < 16; i++)
	{
		os_printf("%02x", Sys.Config.aucOpPwd[i]);
	}
	ESP_DBG("\r\nPassWord:%s\r\n", Sys.Config.aucOpPwd);
	display_devices();
	for (i = 0; i < MAX_REPEATER; i++)
	{
		if (Sys.Config.Repeater[i].exist != 0
				&& Sys.Config.Repeater[i].exist != 1)
		{
			Sys.Config.Repeater[i].exist = 0;
		}
		if (Sys.Config.Repeater[i].exist)
		{
			ESP_DBG("repeater[%d].id=%02X%02X%02X%02X\r\n", i,
					Sys.Config.Repeater[i].id[0], Sys.Config.Repeater[i].id[1],
					Sys.Config.Repeater[i].id[2], Sys.Config.Repeater[i].id[3]);
		}
	}
	STUDY *pstudy = (STUDY *) os_zalloc(sizeof(STUDY));
	for (i = 0; i < MAX_STUDY; i++)
	{
		spi_flash_read(STUDY_ADDR + i * sizeof(STUDY), (uint32*) pstudy,
				sizeof(STUDY));
		pstudy->name[NAME_LEN - 1] = 0;
		if (pstudy->id != 0)
		{
			ESP_DBG("Study[%d].id=%d bid=%d type=%d name=%s\r\n", i, pstudy->id,
					pstudy->bid, pstudy->type, pstudy->name);
		}
	}
	os_free(pstudy);
}
void ICACHE_FLASH_ATTR sys_factory_reset(void)
{
	memset(&Sys.Config, 0, sizeof(Sys.Config));
	memcpy(Sys.Config.aucOpPwd, Sys.Net.stamac, 6);
	strcpy(Sys.Config.Device[0].name, "ŷ������ң�غ�");
	Sys.Config.Device[1].sn = 1;
	Sys.Config.Device[2].sn = 2;
	Sys.Config.Device[3].sn = 3;
	Sys.Config.Device[4].sn = 4;
	Sys.Config.Device[5].sn = 5;
	Sys.Config.sn = 5;
	Sys.Config.timezone = 8;
	Sys.Config.BlankFlag = 0xab;
	Sys.Config.verh = IOT_VERSION_MAJOR;
	Sys.Config.verl = IOT_VERSION_MINOR;
	config_ram2flash();
	study_flash_erase();
	system_restore();
	system_restart();

	//wifi_softap_get_config(&Sys.Net.apinfo);
	//os_memset(Sys.Net.apinfo.ssid, 0, 32);
	//os_memset(Sys.Net.apinfo.password, 0, 64);
	//os_memcpy(Sys.Net.apinfo.ssid, "OPPLE Gateway", 13);
	//os_memcpy(Sys.Net.apinfo.password, "12345678", 8);
	//Sys.Net.apinfo.authmode = AUTH_WPA_WPA2_PSK;
	//Sys.Net.apinfo.ssid_len = 0;
	//Sys.Net.apinfo.max_connection = 4;
	//wifi_softap_set_config(&Sys.Net.apinfo);
}
void ICACHE_FLASH_ATTR usart_cmd_rftest(u8 type)
{
	if (Sys.Mcup.State)
	{
		ESP_DBG("mcu programing\r\n");
		return;
	}
	usart0_putc(2);
	usart0_putc(type);
	os_delay_us(10000);
}
void ICACHE_FLASH_ATTR usart_cmd_send24g1(u8 id1, u8 id2, u8 id3, u8 bid)
{
	if (Sys.Mcup.State)
	{
		ESP_DBG("mcu programing\r\n");
		return;
	}
	usart0_putc(7);
	usart0_putc(USART_CMD_SEND_24G);
	usart0_putc(0x01);
	usart0_putc(id1);
	usart0_putc(id2);
	usart0_putc(id3);
	usart0_putc(bid);
	os_delay_us(10000);
}
void ICACHE_FLASH_ATTR usart_cmd_send24g2(u8 cmd, u8 *para, u8 paralen)
{
	if (Sys.Mcup.State)
	{
		ESP_DBG("mcu programing\r\n");
		return;
	}
	u8 i;
	usart0_putc(paralen + 8);
	usart0_putc(USART_CMD_SEND_24G);
	usart0_putc(0x02);
	usart0_putc(Sys.Net.stamac[2]);
	usart0_putc(Sys.Net.stamac[3]);
	usart0_putc(Sys.Net.stamac[4]);
	usart0_putc(Sys.Net.stamac[5]);
	usart0_putc(cmd);
	for (i = 0; i < paralen; i++)
	{
		usart0_putc(para[i]);
	}
	os_delay_us(15000);
}
void ICACHE_FLASH_ATTR usart_cmd_send415(u8 cmd, u8 type, u8 *para, u8 paralen)
{
	u8 buf[120];
	if (Sys.Mcup.State)
	{
		ESP_DBG("mcu programing\r\n");
		return;
	}
	u8 i;
	for (i = 0; i < paralen; i++)
	{
		if (i > 16 && para[i] == 0)
		{
			paralen = i;
			break;
		}
	}
	usart0_putc(paralen + 3);
	usart0_putc(cmd);
	usart0_putc(type);
	for (i = 0; i < paralen; i++)
	{
		usart0_putc(para[i]);
	}
	os_delay_us(10000);

	buf[0] = paralen + 3;
	buf[1] = cmd;
	buf[2] = type;
	for (i = 0; i < paralen; i++)
	{
		buf[3 + i] = para[i];
	}
	print_buffer(&buf[3], paralen);
}
u8 ICACHE_FLASH_ATTR find_study_data(u32 id, u8 bid, STUDY *pstudy)
{
	u32 i;
	for (i = 0; i < MAX_STUDY; i++)
	{
		spi_flash_read(STUDY_ADDR + i * sizeof(STUDY), (uint32*) pstudy,
				sizeof(STUDY));
		if (pstudy->id == id && pstudy->bid == bid)
		{
			return i;
		}
	}

	return MAX_STUDY;
}
void ICACHE_FLASH_ATTR usart_control(u16 sku, u8 devn, u8 bid)
{
	u32 id = Sys.Config.Device[devn].nid;
	if (sku == PRODUCT_SKU_24G1)
	{
		usart_cmd_send24g1(Sys.Config.Device[devn].brand >> 8,
				Sys.Config.Device[devn].brand >> 0,
				Sys.Config.Device[devn].model >> 8, bid);
	}
	else if (sku == PRODUCT_SKU_USER1 || sku == PRODUCT_SKU_USER2
			|| sku == PRODUCT_SKU_USER3)
	{
		STUDY *pstudy = (STUDY *) os_zalloc(sizeof(STUDY));
		u8 studyn = find_study_data(Sys.Config.Device[devn].nid, bid, pstudy);
		if (studyn < MAX_STUDY)
		{
			ESP_DBG(
					"usart_control : study[%d].nid=%d,bid=%d,type=%d,name=%s\r\n",
					studyn, Sys.Config.Device[devn].nid, bid, pstudy->type,
					pstudy->name);
			print_buffer(pstudy->dat, pstudy->len);
			if (pstudy->type == PRODUCT_TYPE_433)
			{
				//buf[0] = Sys.Config.Device[devn].brand >> 8;
				//buf[1] = Sys.Config.Device[devn].brand >> 0;
				//buf[2] = Sys.Config.Device[devn].model >> 8;
				usart_cmd_send415(USART_CMD_SEND_433, 0x02, pstudy->dat, 110);
			}
			else if (pstudy->type == PRODUCT_TYPE_315)
			{
				//buf[0] = Sys.Config.Device[devn].brand >> 8;
				//buf[1] = Sys.Config.Device[devn].brand >> 0;
				//buf[2] = Sys.Config.Device[devn].model >> 8;
				usart_cmd_send415(USART_CMD_SEND_315, 0x02, pstudy->dat, 110);
			}
			else if (pstudy->type == PRODUCT_TYPE_IR)
			{

			}
		}
		else
		{
			ESP_DBG("usart_control: can not find data\r\n");
		}
		os_free(pstudy);
	}
}
void ICACHE_FLASH_ATTR save_repeater(RF24G *prf24g)
{
	u8 i;
	for (i = 0; i < MAX_REPEATER; i++)
	{
		if (Sys.Config.Repeater[i].exist)
		{
			if (memcmp(Sys.Config.Repeater[i].id, prf24g->Bytes.id, 4) == 0)
			{
				ESP_DBG(
						"save_repeater: existing index=%d id=%02X%02X%02X%02X\r\n",
						i, prf24g->Bytes.id[0], prf24g->Bytes.id[1],
						prf24g->Bytes.id[2], prf24g->Bytes.id[3]);
				os_delay_us(50000);
				usart_cmd_send24g2(RF_CMD_BEAT_STUDY, NULL, 0);
				return;
			}
		}
	}
	for (i = 0; i < MAX_REPEATER; i++)
	{
		if (Sys.Config.Repeater[i].exist == 0)
		{
			break;
		}
	}
	if (i >= MAX_REPEATER)
	{
		ESP_DBG("repeater full, delete all old repeater\r\n");
		memset(Sys.Config.Repeater, 0, sizeof(Sys.Config.Repeater));
		i = 0;
	}
	Sys.Config.Repeater[i].exist = 1;
	memcpy(Sys.Config.Repeater[i].id, prf24g->Bytes.id, 4);
	config_ram2flash();
	ESP_DBG("save_repeater:index=%d id=%02X%02X%02X%02X\r\n", i,
			prf24g->Bytes.id[0], prf24g->Bytes.id[1], prf24g->Bytes.id[2],
			prf24g->Bytes.id[3]);
	os_delay_us(50000);
	usart_cmd_send24g2(RF_CMD_BEAT_STUDY, NULL, 0);
}
u8 ICACHE_FLASH_ATTR find_dev_by_id(u32 id)
{
	u8 i;
	for (i = 0; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].nid == id)
		{
			return i;
		}
	}
	return i;
}
u8 ICACHE_FLASH_ATTR find_dev_by_sn(u8 sn)
{
	u8 i;
	for (i = 0; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].sn == sn)
		{
			return i;
		}
	}
	return i;
}
u8 ICACHE_FLASH_ATTR find_rept_by_id(u8 *id)
{
	u8 i;
	for (i = 0; i < MAX_REPEATER; i++)
	{
		if (memcmp(Sys.Config.Repeater[i].id, id, 4) == 0)
		{
			return i;
		}
	}
	return i;
}
void ICACHE_FLASH_ATTR dev_control(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(id);
	u8 bid;
	ARC_Struct ac;
	if (devn == MAX_DEVICE)
	{
		ESP_DBG("can not find device\r\n");
		return;
	}
	ESP_DBG("dev[%d]: nid=%d sku=%x brand=%x model=%x name=%s\r\n", devn,
			Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sku,
			Sys.Config.Device[devn].brand, Sys.Config.Device[devn].model,
			Sys.Config.Device[devn].name);
	Sys.Status.study = 0;
	switch (Sys.Config.Device[devn].sku)
	{
	case PRODUCT_SKU_24G1:
		ESP_DBG("devn=%d bid=%d sku=%x\r\n", devn, pstChatMsg->aucContent[1],
				Sys.Config.Device[devn].sku);
		usart_control(PRODUCT_SKU_24G1, devn, pstChatMsg->aucContent[1]);
		Sys.Config.Device[devn].status.powertemp = pstChatMsg->aucContent[1];
		break;
	case PRODUCT_SKU_USER1:
	case PRODUCT_SKU_USER2:
	case PRODUCT_SKU_USER3:
		led_green_on();
		bid = pstChatMsg->aucContent[1];
		ESP_DBG("nid=%d,devn=%d bid=%d sku=%x type=%x\r\n", id, devn, bid,
				Sys.Config.Device[devn].sku, Sys.Config.Device[devn].type);
		usart_control(PRODUCT_SKU_USER1, devn, bid);
		Sys.Config.Device[devn].status.powertemp = bid;
		led_green_off();
		break;
	default:
		break;
	}
}
void ICACHE_FLASH_ATTR do_mac_list_check(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 i;
	u8 *buf = (u8*) os_zalloc(1024);
	u8 devs = 0;
	buf[0] = IOT_USER_MAC_LIST_RSQ;
	for (i = 1; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].sku != 0)
		{
			memcpy(&buf[2 + devs * 8], Sys.Net.stamac, 6);
			buf[2 + devs * 8 + 6] = 0;
			buf[2 + devs * 8 + 7] = Sys.Config.Device[i].sn;
			devs++;
		}
	}
	buf[1] = devs;
	user_iot_sent(Sys.Config.Device[0].nid,
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_MESSAGE, buf, 2 + buf[1] * 8, 1);
	ESP_DBG("do_mac_list_check:\r\n");
	print_buffer(buf, 2 + buf[1] * 8);
	os_free(buf);
}
void ICACHE_FLASH_ATTR do_check_remoteid(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(id);
	if (devn == MAX_DEVICE)
	{
		ESP_DBG("can not find device\r\n");
		return;
	}
	u8 buf[64];
	buf[0] = IOT_USER_REMOTEID_RSP;
	os_memcpy(&buf[1], Sys.Config.Device[devn].remoteid, 64);
	user_iot_sent(Sys.Config.Device[devn].nid,
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_MESSAGE, buf, 65, 1);
	ESP_DBG(
			"do_check_remoteid:dev[%d].nid=%d,sn=%d,sku=%x,brand=%x,model=%x,name=%s,remoteid=",
			devn, Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sn,
			Sys.Config.Device[devn].sku, Sys.Config.Device[devn].brand,
			Sys.Config.Device[devn].model, Sys.Config.Device[devn].name);
	print_buffer(Sys.Config.Device[devn].remoteid, 64);
}
u8 ICACHE_FLASH_ATTR find_study_blank(void)
{
	u32 i;
	STUDY *pstudy = (STUDY *) os_zalloc(sizeof(STUDY));
	for (i = 0; i < MAX_STUDY; i++)
	{
		spi_flash_read(STUDY_ADDR + i * sizeof(STUDY), (uint32*) pstudy,
				sizeof(STUDY));
		if (pstudy->id == 0)
		{
			os_free(pstudy);
			return i;
		}
	}
	os_free(pstudy);
	return i;
}
void ICACHE_FLASH_ATTR button_check_rsp(u32 nid, U32 Type, u32 ID, U32 IP,
		U32 Port)
{
	u8 i;
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("button_check_rsp: can not find nid\r\n");
		return;
	}
	STUDY *pstudy = (STUDY *) os_zalloc(sizeof(STUDY));
	u8 *buf = (u8*) os_zalloc(1024);
	buf[0] = IOT_USER_BUTTON_RSP;
	buf[1] = 0;
	for (i = 0; i < MAX_STUDY; i++)
	{
		spi_flash_read(STUDY_ADDR + i * sizeof(STUDY), (uint32*) pstudy,
				sizeof(STUDY));
		if (pstudy->id == nid)
		{
			memcpy(&buf[2 + buf[1] * 16], pstudy->name, NAME_LEN);
			ESP_DBG("button_check_rsp: study[%d].name=%s\r\n", i, pstudy->name);
			buf[1]++;
		}
	}
	os_free(pstudy);
	if (buf[1] > 20)
	{
		ESP_DBG("button_check_rsp: too many buttons\r\n");
		os_free(buf);
		return;
	}
	user_iot_sent(nid, Type, ID, IP, Port, IOT_MESSAGE, buf, 2 + buf[1] * 16,
			1);
	ESP_DBG("button_check_rsp: nid=%d,buttons=%d\r\n", nid, buf[1]);
	print_buffer(buf, 2 + buf[1] * 16);
	os_free(buf);
}
void ICACHE_FLASH_ATTR save_study(u32 id, u8 type, u8 func, u8 *buf, u16 len)
{
	u8 studyn;
	STUDY *pstudy = (STUDY *) os_zalloc(sizeof(STUDY));
	if (func == 1)
	{
		studyn = find_study_blank();
		if (studyn < MAX_STUDY)
		{
			spi_flash_read(STUDY_ADDR + studyn * sizeof(STUDY),
					(uint32*) pstudy, sizeof(STUDY));
			pstudy->id = id;
			pstudy->bid = studyn;
			pstudy->type = type;
			memcpy(pstudy->name, Sys.rsp_name, NAME_LEN);
			memset(pstudy->dat, 0x0, STUDY_DAT_LEN);
			memcpy(pstudy->dat, buf, len);
			pstudy->len, len;
			pstudy->name[NAME_LEN - 1] = 0;
			ESP_DBG(
					"save_study: nid=%d,studyn=%d,type=%d,name=%s,datalen=%d\r\n",
					id, studyn, type, pstudy->name, len);
			print_buffer(pstudy->dat, len);
			study_ram2flash(studyn, pstudy);
			button_check_rsp(Sys.NetSend.id, Sys.NetSend.srcidtype,
					Sys.NetSend.srcid, Sys.NetSend.ip, Sys.NetSend.port);
		}
		else
		{
			ESP_DBG("save_study: fail no blank item\r\n");
		}
	}
	else if (func == 2)
	{
		ESP_DBG("save study: nid=%d,bid=%d\r\n", id, Sys.rsp_bid);
		studyn = find_study_data(id, Sys.rsp_bid, pstudy);
		if (studyn < MAX_STUDY)
		{
			spi_flash_read(STUDY_ADDR + studyn * sizeof(STUDY),
					(uint32*) pstudy, sizeof(STUDY));
			pstudy->type = type;
			memset(pstudy->dat, 0x0, STUDY_DAT_LEN);
			memcpy(pstudy->dat, buf, len);
			pstudy->name[NAME_LEN - 1] = 0;
			ESP_DBG("save_study : modify study[%d].nid=%d,name=%s\r\n", studyn,
					id, pstudy->name);
			study_ram2flash(studyn, pstudy);
			button_check_rsp(Sys.NetSend.id, Sys.NetSend.srcidtype,
					Sys.NetSend.srcid, Sys.NetSend.ip, Sys.NetSend.port);
		}
		else
		{
			ESP_DBG("save_study: can not find id&bid\r\n");
		}
	}
	os_free(pstudy);
}
void ICACHE_FLASH_ATTR ir_send2rept(u8 reptn, u8 *buf, u8 len)
{
	u8 outbuf[125];
	ESP_DBG("len=%d\r\n", len);
	memcpy(outbuf, Sys.Config.Repeater[reptn].id, 4);
	outbuf[4] = 0;
	memcpy(&outbuf[5], buf, len);
	usart_cmd_send24g2(RF_CMD_IR_SEND, outbuf, len + 5);
}
void ICACHE_FLASH_ATTR ir_send(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(id);
	u8 reptn = Sys.Config.Device[devn].reptn;
	u16 len = pstChatMsg->aucContent[2] * 256 + pstChatMsg->aucContent[1];
	ESP_DBG("ir_send:len=%d\r\n", len);

	reptn = MAX_REPEATER;

	if (reptn < MAX_REPEATER)
	{
		//ir_send2rept(reptn, learn_data_out, 112);
		ESP_DBG("ir send by reptn=%d\r\n", reptn);
	}
	else
	{
		led_green_on();
		IR_Sent_Start(&pstChatMsg->aucContent[1], &pstChatMsg->aucContent[9]);
		ESP_DBG("ir send by gateway reptn=%d\r\n", reptn);
		print_buffer(pstChatMsg->aucContent, 512);
		ESP_DBG("ir send by gateway reptn=%d\r\n", reptn);
		led_green_off();
	}
}
void ICACHE_FLASH_ATTR ir_learn_rept(u8 reptn, u8 *buf)
{
	os_timer_disarm(&ir_learn_timer);
	Sys.irrept = reptn;
	//ir_learn_air(Sys.NetSend.id, buf);
	led_green_off();
}
void ICACHE_FLASH_ATTR ir_study_rsp(u8 *p1, u16 len)
{
	u8 *buf = (u8*) os_zalloc(1024);
	u8 devn = find_dev_by_id(Sys.NetSend.id);
	buf[0] = IOT_USER_IR_STUDY_RSP;
	memcpy(&buf[1], p1, len);
	user_iot_sent(Sys.NetSend.id, Sys.NetSend.srcidtype, Sys.NetSend.srcid,
			Sys.NetSend.ip, Sys.NetSend.port,
			IOT_MESSAGE, buf, len + 1, 1);
	ESP_DBG(
			"Sys.NetSend.id=%d,Sys.NetSend.srcidtype=%d,Sys.NetSend.srcid=%d,Sys.NetSend.ip=%x,Sys.NetSend.port=%d\r\n",
			Sys.NetSend.id, Sys.NetSend.srcidtype, Sys.NetSend.srcid,
			Sys.NetSend.ip, Sys.NetSend.port);
	ESP_DBG("user_iot_sent\r\n");
	print_buffer(buf, len + 1);
	ESP_DBG("dev[%d]: nid=%d sku=%x name=%s\r\n", devn,
			Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sku,
			Sys.Config.Device[devn].name);
	ESP_DBG("ir_study_rsp pstMsg->ulSrcTransNo=%d\r\n", Sys.NetSend.rno);
	os_free(buf);
}
LOCAL void ICACHE_FLASH_ATTR ir_learn_cb(u8 func)
{
	u16 len;
	u8 learn_state;
	u8 *buf = (u8*) os_zalloc(1024);
	os_timer_disarm(&ir_learn_timer);
	if (Sys.Status.study == 0)
	{
		led_green_off();
		os_free(buf);
		return;
	}
	learn_state = IR_Learn_Start(buf, len);
	if (learn_state == 0x66)
	{
		len = buf[1];
		len = len << 8;
		len = len + buf[0] + 10;
		ESP_DBG("ir_learn_cb:received data %d:\r\n", len);
		print_buffer(buf, len);
		Sys.irrept = MAX_REPEATER;
		if (Sys.Status.study)
		{
			if (func == 0)
			{
				ir_study_rsp(buf, len);
			}
			else
			{
				if (len > STUDY_DAT_LEN)
				{
					ESP_DBG("ir_learn_cb:received data too much:\r\n", len);
				}
				else
				{
					save_study(Sys.NetSend.id, PRODUCT_TYPE_IR, func, buf, len);
					button_check_rsp(Sys.NetSend.id, Sys.NetSend.srcidtype,
							Sys.NetSend.srcid, Sys.NetSend.ip,
							Sys.NetSend.port);
				}
			}
			Sys.Status.study = 0;
		}
		led_green_off();
	}
	else
	{
		os_timer_setfn(&ir_learn_timer, (os_timer_func_t *) ir_learn_cb, func);
		os_timer_arm(&ir_learn_timer, 100, 1);
		ESP_DBG("ir_learn_cb: restart\r\n");
	}
	os_free(buf);
}
void ICACHE_FLASH_ATTR ir_learn_start(u8 func)
{
	led_green_on();
	os_timer_disarm(&ir_learn_timer);
	os_timer_setfn(&ir_learn_timer, (os_timer_func_t *) ir_learn_cb, func);
	os_timer_arm(&ir_learn_timer, 100, 1);
}
void ICACHE_FLASH_ATTR ir_lenrn_stop(void)
{
	os_timer_disarm(&ir_learn_timer);
	Sys.Status.study = 0;
	led_green_off();
}
void ICACHE_FLASH_ATTR ir_study(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	Sys.NetSend.srcidtype = pstMsg->stSrcL3Addr.stObject.enObjectType;
	Sys.NetSend.srcid = pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.ip = pstMsg->stSrcL2Addr.ulIP;
	Sys.NetSend.port = pstMsg->stSrcL2Addr.ulPort;
	ir_learn_start(0);
	usart_cmd_send24g2(RF_CMD_IR_STUDY, NULL, 0);
	Sys.Status.study = 1;
	Sys.Status.study_type = STUDY_IR;
}
void ICACHE_FLASH_ATTR light24g_study(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	Sys.NetSend.id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	ESP_DBG("id=%d\r\n", Sys.NetSend.id);
	Sys.Status.study = 1;
	Sys.Status.study_type = STUDY_24G;
	led_green_on(1);
}
void ICACHE_FLASH_ATTR do_button_check(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	ESP_DBG("do_button_check: nid=%d\r\n",
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]);
	button_check_rsp(pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort);
}
void ICACHE_FLASH_ATTR do_button_add_mod(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg,
		u8 func)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	Sys.NetSend.id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.srcidtype = pstMsg->stSrcL3Addr.stObject.enObjectType;
	Sys.NetSend.srcid = pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.ip = pstMsg->stSrcL2Addr.ulIP;
	Sys.NetSend.port = pstMsg->stSrcL2Addr.ulPort;
	if (func == 1)
	{
		memcpy(Sys.rsp_name, &pstChatMsg->aucContent[1], NAME_LEN);
		ESP_DBG("do_button_add:%s\r\n", Sys.rsp_name);
	}
	else if (func == 2)
	{
		Sys.rsp_bid = pstChatMsg->aucContent[1];
		ESP_DBG("do_button_mod:bid=%d\r\n", Sys.rsp_bid);
	}
	Sys.Status.study_func = func;
	Sys.Status.study = 1;
	Sys.Status.study_type = STUDY_USER;
	led_green_on();
	//ir_learn_start(func);
	//usart_cmd_send24g2(RF_CMD_IR_STUDY, NULL, 0);
}
void ICACHE_FLASH_ATTR add_dev_rsp(u8 devn, U32 Type, u32 ID, U32 IP, U32 Port)
{
	u8 buf[64];
	buf[0] = IOT_USER_ADD_DEV_RSQ;
	buf[1] = 1;
	buf[2] = 0;
	buf[3] = Sys.Config.Device[devn].sku >> 8;
	buf[4] = Sys.Config.Device[devn].sku >> 0;
	buf[5] = 0;
	buf[6] = 1;
	memcpy(&buf[7], Sys.Net.stamac, 6); //��Ʒ���кź���(������Կ)
	buf[13] = 0;
	buf[14] = Sys.Config.Device[devn].sn;
	buf[15] = Sys.Config.Device[devn].nid >> 24;
	buf[16] = Sys.Config.Device[devn].nid >> 16;
	buf[17] = Sys.Config.Device[devn].nid >> 8;
	buf[18] = Sys.Config.Device[devn].nid >> 0;
	*((u32*) &buf[19]) = 0; //IOT ID High
	memcpy(&buf[23], Sys.Config.Device[devn].name, NAME_LEN); //�豸������Ϣ
	user_iot_sent(Sys.Config.Device[0].nid, Type, ID, IP, Port,
	IOT_MESSAGE, buf, 39, 1);
	ESP_DBG("dev[%d]:nid=%d,sn=%d,sku=0x%04x,name=%s\r\n", devn,
			Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sn,
			Sys.Config.Device[devn].sku, Sys.Config.Device[devn].name);

}
void ICACHE_FLASH_ATTR find_dev_rsp(u8 devn, U32 Type, u32 ID, U32 IP, U32 Port)
{
	u8 buf[64];
	buf[0] = 0;
	buf[1] = 0;
	buf[2] = 0;
	buf[3] = 1;
	buf[4] = 0;
	buf[5] = Sys.Config.Device[devn].sku >> 8;
	buf[6] = Sys.Config.Device[devn].sku >> 0;
	buf[7] = 0;
	buf[8] = 1;
	memcpy(&buf[9], Sys.Net.stamac, 6); //��Ʒ���кź���(������Կ)
	buf[15] = 0;
	buf[16] = Sys.Config.Device[devn].sn;
	buf[17] = 0;
	buf[18] = 1;
	buf[19] = Sys.Config.Device[devn].nid >> 24;
	buf[20] = Sys.Config.Device[devn].nid >> 16;
	buf[21] = Sys.Config.Device[devn].nid >> 8;
	buf[22] = Sys.Config.Device[devn].nid >> 0;
	*((u32*) &buf[23]) = 0; //IOT ID High

	buf[27] = IOT_VERSION_MAJOR; //�����豸�������汾��
	buf[28] = IOT_VERSION_MINOR; //�����豸�������汾��
	buf[29] = 0; //�����豸�������汾��
	buf[30] = 0; //�����豸�������汾��
	*((u32*) &buf[31]) = Sys.Net.ipinfo.ip.addr; //����������IP
	buf[35] = IOT_LOCAL_PORT >> 8; //���ط���UDP�˿�
	buf[36] = (u8) IOT_LOCAL_PORT; //���ط���UDP�˿�
	memcpy(&buf[37], Sys.Config.Device[devn].name, NAME_LEN); //�豸������Ϣ
	user_iot_sent(Sys.Config.Device[devn].nid, Type, ID, IP, Port,
	IOT_APP_FIND_RSP, buf, 53, 0);
	ESP_DBG("dev[%d]:nid=%d,sn=%d,sku=0x%04x,name=%s\r\n", devn,
			Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sn,
			Sys.Config.Device[devn].sku, Sys.Config.Device[devn].name);
}
void ICACHE_FLASH_ATTR find_dev_all_rsp(void)
{
	u8 i, j;
	u8 totaldev = 0;
	u8 buf[1024];
	for (i = 1; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].sku != 0)
		{
			totaldev++;
		}
	}
	buf[0] = IOT_USER_FIND_DEV_RSQ;
	buf[1] = totaldev;
	buf[2] = 0;				// OpCode
	buf[3] = 0;				// AgentFlag
	buf[4] = 0;				// AgentFlag
	buf[5] = 1;				// Class
	buf[6] = 0;				// Class
	buf[7] = Sys.Config.Device[0].sku >> 8;
	buf[8] = Sys.Config.Device[0].sku >> 0;
	buf[9] = 0;				// Source
	buf[10] = 1;			// Source
	memcpy(&buf[11], Sys.Net.stamac, 6); //��Ʒ���кź���(������Կ)
	buf[17] = 0;
	buf[18] = Sys.Config.Device[0].sn;
	buf[19] = 0;			// ObjectType
	buf[20] = 1;			// ObjectType
	buf[21] = Sys.Config.Device[0].nid >> 24;
	buf[22] = Sys.Config.Device[0].nid >> 16;
	buf[23] = Sys.Config.Device[0].nid >> 8;
	buf[24] = Sys.Config.Device[0].nid >> 0;
	*((u32*) &buf[25]) = 0; //IOT ID High
	buf[29] = IOT_VERSION_MAJOR; 	//�����豸�������汾��
	buf[30] = IOT_VERSION_MINOR; 	//�����豸�������汾��
	buf[31] = 0; 					//�����豸�������汾��
	buf[32] = 0; 					//�����豸�������汾��
	*((u32*) &buf[33]) = Sys.Net.ipinfo.ip.addr; //����������IP
	buf[37] = IOT_LOCAL_PORT >> 8; //���ط���UDP�˿�
	buf[38] = (u8) IOT_LOCAL_PORT; //���ط���UDP�˿�
	memcpy(&buf[39], Sys.Config.Device[0].name, NAME_LEN); //�豸������Ϣ
	ESP_DBG("find_dev_all_rsp:totaldev=%d\r\n", totaldev);
	ESP_DBG("dev[%d]:nid=%d,sn=%d,sku=0x%04x,name=%s\r\n", 0,
			Sys.Config.Device[0].nid, Sys.Config.Device[0].sn,
			Sys.Config.Device[0].sku, Sys.Config.Device[0].name);
	j = 0;
	for (i = 1; i < MAX_DEVICE && j < 20; i++)
	{
		if (Sys.Config.Device[i].sku != 0)
		{
			ESP_DBG("dev[%d]:nid=%d,sn=%d,sku=0x%04x,name=%s\r\n", i,
					Sys.Config.Device[i].nid, Sys.Config.Device[i].sn,
					Sys.Config.Device[i].sku, Sys.Config.Device[i].name);
			buf[55 + j * 36 + 0] = 1;	// Class
			buf[55 + j * 36 + 1] = 0;	// Class
			buf[55 + j * 36 + 2] = Sys.Config.Device[i].sku >> 8;
			buf[55 + j * 36 + 3] = Sys.Config.Device[i].sku >> 0;
			memcpy(&buf[55 + j * 36 + 4], Sys.Net.stamac, 6); //��Ʒ���кź���(������Կ)
			buf[55 + j * 36 + 10] = 0;
			buf[55 + j * 36 + 11] = Sys.Config.Device[i].sn;
			buf[55 + j * 36 + 12] = Sys.Config.Device[i].nid >> 24;
			buf[55 + j * 36 + 13] = Sys.Config.Device[i].nid >> 16;
			buf[55 + j * 36 + 14] = Sys.Config.Device[i].nid >> 8;
			buf[55 + j * 36 + 15] = Sys.Config.Device[i].nid >> 0;
			buf[55 + j * 36 + 16] = 0;	//IOT ID High
			buf[55 + j * 36 + 17] = 0;	//IOT ID High
			buf[55 + j * 36 + 18] = 0;	//IOT ID High
			buf[55 + j * 36 + 19] = 0;	//IOT ID High
			memcpy(&buf[55 + j * 36 + 20], Sys.Config.Device[i].name,
			NAME_LEN); //�豸������Ϣ
			j++;
		}
	}
	buf[1] = j;
	if (j < 20)
	{
		ESP_DBG("IOT_APP_FIND FINISHED at %08x\r\n", system_get_time());
		Sys.NetSend.find_dev_pak = 0;
	}
	else
	{
		Sys.NetSend.find_dev_pak = 1;
	}
	user_iot_sent(Sys.Config.Device[0].nid, Sys.NetSend.srcidtype,
			Sys.NetSend.srcid, Sys.NetSend.ip, Sys.NetSend.port,
			IOT_SEARCH_RSP, buf, 55 + j * 36, 0);
	print_buffer(buf, 55 + j * 36);
}
void ICACHE_FLASH_ATTR do_scene_check(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 i;
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("do_scene_check: can not find nid\r\n");
		return;
	}
	u8 buf[256];
	buf[0] = 0;
	buf[1] = 0;
	buf[2] = 0;
	buf[3] = 0;
	buf[4] = MAX_SCENE;
	for (i = 0; i < MAX_SCENE; i++)
	{
		buf[5 + i * 20] = 0;
		buf[6 + i * 20] = 0;
		buf[7 + i * 20] = 0;
		buf[8 + i * 20] = i;
		memcpy(&buf[9 + i * 20], Sys.Config.Device[devn].Scene[i].name,
		NAME_LEN);
	}
	user_iot_sent(nid, pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_SCENE_CHECK_RSP, buf, 9 + i * 20 + NAME_LEN, 1);
	print_buffer(buf, 9 + i * 20 + NAME_LEN);
}
void ICACHE_FLASH_ATTR do_scene_rsp(u8 n, u32 msg,
		ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[1];
	buf[0] = 0;
	user_iot_sent(pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort, msg, buf, 1,
			1);
	//ESP_DBG("do scene[%d]: sid=%d name=%s\r\n", n, n,
	//		Sys.Config.Device[find_dev_by_id(
	//				pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0])].Scene[n].name);
}
void ICACHE_FLASH_ATTR do_scene_set(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 i;
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("do_scene_set: can not find nid\r\n");
		return;
	}
	u8 sid = pstChatMsg->aucContent[3];
	if (sid >= MAX_SCENE)
	{
		ESP_DBG("can not find scene\r\n");
		return;
	}
	memcpy(Sys.Config.Device[devn].Scene[sid].name, &pstChatMsg->aucContent[4],
	NAME_LEN);
	config_ram2flash();
	do_scene_rsp(sid, IOT_SCENE_SET_RSP, pstMsg);
}
void ICACHE_FLASH_ATTR do_scene_study(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u8 bid;
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("do_scene_study: can not find nid\r\n");
		return;
	}
	ARC_Struct ac;
	u8 sid = pstChatMsg->aucContent[1];
	if (sid >= MAX_SCENE)
	{
		ESP_DBG("do_scene_del: can not find scene\r\n");
		return;
	}
	u16 sku = Sys.Config.Device[devn].sku;
	if (sku == PRODUCT_SKU_AC)
	{
		//Sys.Config.Device[devn].Scene[sid].action.powertemp = bid;
		ac.temp = pstChatMsg->aucContent[2];
		ac.wind = pstChatMsg->aucContent[3];
		ac.dir = pstChatMsg->aucContent[4];
		ac.power = pstChatMsg->aucContent[5];
		ac.op = pstChatMsg->aucContent[6];
		ac.mode = pstChatMsg->aucContent[7];
		Sys.Config.Device[devn].Scene[sid].action.powertemp = ac.power;
		Sys.Config.Device[devn].Scene[sid].action.powertemp <<= 7;
		Sys.Config.Device[devn].Scene[sid].action.powertemp += ac.temp;
		Sys.Config.Device[devn].Scene[sid].action.modeop = ac.mode;
		Sys.Config.Device[devn].Scene[sid].action.modeop <<= 4;
		Sys.Config.Device[devn].Scene[sid].action.modeop += ac.op;
		Sys.Config.Device[devn].Scene[sid].action.winddir = ac.wind;
		Sys.Config.Device[devn].Scene[sid].action.winddir <<= 4;
		Sys.Config.Device[devn].Scene[sid].action.winddir += ac.dir;
		ESP_DBG("temp=%d,wind=%d,dir=%d,power=%d,op=%d,mode=%d\r\n", ac.temp,
				ac.wind, ac.dir, ac.power, ac.op, ac.mode);
	}
	else
	{
		bid = pstChatMsg->aucContent[2];
		Sys.Config.Device[devn].Scene[sid].action.powertemp = bid;
		ESP_DBG("nid=%d,sid=%d,bid=%d\r\n", nid, sid, bid);
	}
	config_ram2flash();
}
void ICACHE_FLASH_ATTR do_scene_del(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u8 sid = pstChatMsg->aucContent[1];
	if (sid >= MAX_SCENE)
	{
		ESP_DBG("do_scene_del: can not find scene\r\n");
		return;
	}
	ESP_DBG("do_scene_del: sid=%d\r\n", sid);
	u8 i;
	for (i = 1; i < MAX_DEVICE; i++)
	{
		memset(&Sys.Config.Device[i].Scene[sid], 0, sizeof(SCENE));
	}
	config_ram2flash();
	do_scene_rsp(sid, IOT_USER_SCENE_DEL_RSP, pstMsg);
}
void ICACHE_FLASH_ATTR do_scene(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u8 i;
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 sid = pstChatMsg->aucContent[3];
	if (sid >= MAX_SCENE)
	{
		Sys.Status.scenen = 0;
		ESP_DBG("can not find scene\r\n");
		return;
	}
	Sys.Status.scenen = sid;
	Sys.Status.doscene = 1;
	ESP_DBG("excute scene[%d]\r\n", Sys.Status.scenen);
	do_scene_rsp(Sys.Status.scenen, IOT_SCENE_CAL_RSP, pstMsg);
}
void ICACHE_FLASH_ATTR do_timer_rsp(u32 msg, ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[1];
	buf[0] = 0;
	user_iot_sent(pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort, msg, buf, 1,
			1);
}
void ICACHE_FLASH_ATTR do_dev_sync(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ARC_Struct *ac;
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("do_dev_sync: can not find nid\r\n");
		return;
	}
	ac->temp = pstChatMsg->aucContent[1];
	ac->wind = pstChatMsg->aucContent[2];
	ac->dir = pstChatMsg->aucContent[3];
	ac->power = pstChatMsg->aucContent[4];
	ac->op = pstChatMsg->aucContent[5];
	ac->mode = pstChatMsg->aucContent[6];
	Sys.Config.Device[devn].status.powertemp = ac->power;
	Sys.Config.Device[devn].status.powertemp <<= 7;
	Sys.Config.Device[devn].status.powertemp += ac->temp;
	Sys.Config.Device[devn].status.modeop = ac->mode;
	Sys.Config.Device[devn].status.modeop <<= 4;
	Sys.Config.Device[devn].status.modeop += ac->op;
	Sys.Config.Device[devn].status.winddir = ac->wind;
	Sys.Config.Device[devn].status.winddir <<= 4;
	Sys.Config.Device[devn].status.winddir += ac->dir;
	ESP_DBG("power=%d temp=%d mode=%d op=%d wind=%d dir=%d\r\n", ac->power,
			ac->temp, ac->mode, ac->op, ac->wind, ac->dir);
}
void ICACHE_FLASH_ATTR do_timer_check(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[31];
	TIMER_INFO *timer;
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("do_timer_check: can not find nid\r\n");
		return;
	}
	buf[0] = 0;
	memcpy(&buf[1], Sys.Config.Device[devn].Timer, 30);
	user_iot_sent(pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_TIMER_CHECK_RSP, buf, 31, 1);
	print_buffer(buf, 31);
}
void ICACHE_FLASH_ATTR do_timer_set(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	print_buffer(pstChatMsg->aucContent, sizeof(TIMER_INFO) * 2);
	u32 nid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(nid);
	if (devn >= MAX_DEVICE)
	{
		ESP_DBG("do_timer_set: can not find nid\r\n");
		return;
	}
	memcpy(&Sys.Config.Device[devn].Timer[0], &pstChatMsg->aucContent[0], 15);
	ESP_DBG(
			"Hour=%d Minute=%d ValidFlag=%d Mon=%d Tus=%d Wed=%d Tur=%d Fri=%d Sat=%d Sun=%d Reserve=%d CMD=%d\r\n",
			Sys.Config.Device[devn].Timer[0].Hour,
			Sys.Config.Device[devn].Timer[0].Minute,
			Sys.Config.Device[devn].Timer[0].ValidFlag,
			Sys.Config.Device[devn].Timer[0].TimerFlag[0],
			Sys.Config.Device[devn].Timer[0].TimerFlag[1],
			Sys.Config.Device[devn].Timer[0].TimerFlag[2],
			Sys.Config.Device[devn].Timer[0].TimerFlag[3],
			Sys.Config.Device[devn].Timer[0].TimerFlag[4],
			Sys.Config.Device[devn].Timer[0].TimerFlag[5],
			Sys.Config.Device[devn].Timer[0].TimerFlag[6],
			Sys.Config.Device[devn].Timer[0].Reserve,
			Sys.Config.Device[devn].Timer[0].cmd);
	memcpy(&Sys.Config.Device[devn].Timer[1], &pstChatMsg->aucContent[15], 15);
	ESP_DBG(
			"Hour=%d Minute=%d ValidFlag=%d Mon=%d Tus=%d Wed=%d Tur=%d Fri=%d Sat=%d Sun=%d Reserve=%d CMD=%d\r\n",
			Sys.Config.Device[devn].Timer[1].Hour,
			Sys.Config.Device[devn].Timer[1].Minute,
			Sys.Config.Device[devn].Timer[1].ValidFlag,
			Sys.Config.Device[devn].Timer[1].TimerFlag[0],
			Sys.Config.Device[devn].Timer[1].TimerFlag[1],
			Sys.Config.Device[devn].Timer[1].TimerFlag[2],
			Sys.Config.Device[devn].Timer[1].TimerFlag[3],
			Sys.Config.Device[devn].Timer[1].TimerFlag[4],
			Sys.Config.Device[devn].Timer[1].TimerFlag[5],
			Sys.Config.Device[devn].Timer[1].TimerFlag[6],
			Sys.Config.Device[devn].Timer[1].Reserve,
			Sys.Config.Device[devn].Timer[1].cmd);
	u8 i;
	for (i = 0; i < MAX_TIMER; i++)
	{
		if (Sys.Config.Device[devn].Timer[i].cmd)
		{
			Sys.Config.Device[devn].status.powertemp |= 0x80;
		}
		else
		{
			Sys.Config.Device[devn].status.powertemp &= 0x7f;
		}
		Sys.Config.Device[devn].status.modeop &= 0xf0;
		Sys.Config.Device[devn].status.modeop |= 0x01;
		Sys.Config.Device[devn].Timer[i].powertemp =
				Sys.Config.Device[devn].status.powertemp;
		Sys.Config.Device[devn].Timer[i].LumiFrom =
				Sys.Config.Device[devn].status.modeop;
		Sys.Config.Device[devn].Timer[i].LumiTo =
				Sys.Config.Device[devn].status.winddir;
		ESP_DBG("powertemp=%x\r\n", Sys.Config.Device[devn].Timer[i].powertemp);
	}
	config_ram2flash();
	do_timer_rsp(IOT_TIMER_SET_RSP, pstMsg);
}
void ICACHE_FLASH_ATTR do_rssi_check(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[5];
	s8 rssi;
	rssi = wifi_station_get_rssi();
	ESP_DBG("do_rssi_check: rssi=%ddbm\r\n", rssi);
	if (rssi >= -55)
	{
		rssi = 100;
	}
	else if (rssi <= -95)
	{
		rssi = 0;
	}
	else
	{
		rssi = (rssi + 95) * 5 / 2;
	}
	ESP_DBG("do_rssi_check: rssi=%d%%\r\n", rssi);
	buf[0] = 0;
	buf[1] = rssi;
	user_iot_sent(Sys.Config.Device[0].nid,
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_RSSI_CHECK_RSP, buf, 2, 1);
}
void ICACHE_FLASH_ATTR do_ota_check(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[5];
	buf[0] = IOT_USER_OTA_CHECK_RSP;
	buf[1] = IOT_VERSION_MAJOR;
	buf[2] = IOT_VERSION_MINOR;
	buf[3] = Sys.Config.verh;
	buf[4] = Sys.Config.verl;
	user_iot_sent(Sys.Config.Device[0].nid,
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_MESSAGE, buf, 5, 1);
	ESP_DBG("���������\r\n");
	print_buffer(buf, 5);
}
void ICACHE_FLASH_ATTR do_ota_start(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	Sys.NetSend.id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.srcidtype = pstMsg->stSrcL3Addr.stObject.enObjectType;
	Sys.NetSend.srcid = pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.ip = pstMsg->stSrcL2Addr.ulIP;
	Sys.NetSend.port = pstMsg->stSrcL2Addr.ulPort;
	Sys.Status.forceupgrade = 1;
	hex_beat();
}

/******************************************************************************
 * ״̬���ذ�
 *
 * @param
 * @return
 *******************************************************************************/
void ICACHE_FLASH_ATTR do_check_status(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[2048];
	u8 i, j;
	u8 totaldev = 0;
	Sys.NetSend.srcidtype = pstMsg->stSrcL3Addr.stObject.enObjectType;
	Sys.NetSend.srcid = pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0];
	//Sys.NetSend.id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.ip = pstMsg->stSrcL2Addr.ulIP;
	Sys.NetSend.port = pstMsg->stSrcL2Addr.ulPort;
	for (i = 1; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].sku != 0)
		{
			totaldev++;
		}
	}
	buf[0] = IOT_USER_FIND_DEV_RSQ;
	buf[1] = totaldev;
	j = 0;
	for (i = 1; i < MAX_DEVICE && j < 20; i++)
	{
		if (Sys.Config.Device[i].sku != 0)
		{
			ESP_DBG("dev[%d]:nid=%d,sn=%d,sku=0x%04x,name=%s\r\n", i,
					Sys.Config.Device[i].nid, Sys.Config.Device[i].sn,
					Sys.Config.Device[i].sku, Sys.Config.Device[i].name);
			buf[2 + j * 36 + 0] = 1;	// Class
			buf[2 + j * 36 + 1] = 0;	// Class
			buf[2 + j * 36 + 2] = Sys.Config.Device[i].sku >> 8;
			buf[2 + j * 36 + 3] = Sys.Config.Device[i].sku >> 0;
			memcpy(&buf[2 + j * 36 + 4], Sys.Net.stamac, 6); //��Ʒ���кź���(������Կ)
			buf[2 + j * 36 + 10] = 0;
			buf[2 + j * 36 + 11] = Sys.Config.Device[i].sn;
			buf[2 + j * 36 + 12] = Sys.Config.Device[i].nid >> 24;
			buf[2 + j * 36 + 13] = Sys.Config.Device[i].nid >> 16;
			buf[2 + j * 36 + 14] = Sys.Config.Device[i].nid >> 8;
			buf[2 + j * 36 + 15] = Sys.Config.Device[i].nid >> 0;
			buf[2 + j * 36 + 16] = 0;	//IOT ID High
			buf[2 + j * 36 + 17] = 0;	//IOT ID High
			buf[2 + j * 36 + 18] = 0;	//IOT ID High
			buf[2 + j * 36 + 19] = 0;	//IOT ID High
			memcpy(&buf[2 + j * 36 + 20], Sys.Config.Device[i].name,
			NAME_LEN); //�豸������Ϣ
			j++;
		}
	}
	buf[1] = j;
	if (j < 20)
	{
		ESP_DBG("IOT_APP_FIND FINISHED at %08x\r\n", system_get_time());
		Sys.NetSend.find_dev_pak = 0;
	}
	else
	{
		Sys.NetSend.find_dev_pak = 1;
	}
	user_iot_sent(Sys.Config.Device[0].nid, Sys.NetSend.srcidtype,
			Sys.NetSend.srcid, Sys.NetSend.ip, Sys.NetSend.port,
			IOT_DEV_CHECK_RSP, buf, 2 + j * 36, 1);
	print_buffer(buf, 2 + j * 36);
}

void ICACHE_FLASH_ATTR do_restore_factory(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[1];
	u32 selfid = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	if (selfid == Sys.Config.Device[0].nid)
	{
		buf[0] = 0;
		user_iot_sent(selfid, pstMsg->stSrcL3Addr.stObject.enObjectType,
				pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
				pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
				IOT_DEV_RESTORE_RSP, buf, 1, 0);
		sys_factory_reset();
	}
}
void ICACHE_FLASH_ATTR do_change_pass(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	u8 buf[1];
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg;
	pstChatMsg = (ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	memcpy(Sys.Config.aucOpPwd, pstChatMsg->aucContent, 16);
	config_ram2flash();
	buf[0] = 0;
	user_iot_sent(Sys.Config.Device[0].nid,
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_PASS_CHANGE_RSP, buf, 1, 0);
	ESP_DBG("do_change_pass: nid=%d opcode=%d\r\n", Sys.Config.Device[0].nid,
			buf[0]);
}
void ICACHE_FLASH_ATTR do_add_device_now(u16 sku, u8 *dat)
{
	u8 i;
	for (i = 1; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].sku == 0 && Sys.Config.Device[i].sn != 0)
		{
			Sys.Config.Device[i].sku = sku;
			if (sku == PRODUCT_SKU_24G1)
			{
				Sys.Config.Device[i].brand = dat[0];
				Sys.Config.Device[i].brand <<= 8;
				Sys.Config.Device[i].brand += dat[1];
				Sys.Config.Device[i].model = dat[2];
				Sys.Config.Device[i].model <<= 8;
			}
			memcpy(Sys.Config.Device[i].name, Sys.rsp_name, NAME_LEN);
			memcpy(Sys.Config.Device[i].remoteid, Sys.rsp_remoteid, 64);
			ESP_DBG(
					"do_add_device_now:dev[%d]:nid=%d,sn=%d,sku=%x,brand=%x,model=%x,name:%s\r\n",
					i, Sys.Config.Device[i].nid, Sys.Config.Device[i].sn,
					Sys.Config.Device[i].sku, Sys.Config.Device[i].brand,
					Sys.Config.Device[i].model, Sys.Config.Device[i].name);
			ESP_DBG("RemoteID:");
			print_buffer(Sys.Config.Device[i].remoteid, 64);
			config_ram2flash();
			display_devices();
			add_dev_rsp(i, Sys.NetSend.srcidtype, Sys.NetSend.srcid,
					Sys.NetSend.ip, Sys.NetSend.port);
			//find_dev_rsp(0, Sys.NetSend.srcidtype, Sys.NetSend.srcid,
			//				Sys.NetSend.ip, Sys.NetSend.port);
			return;
		}
	}
	ESP_DBG("do_add_device_now:can not find blank item\r\n");
}
void ICACHE_FLASH_ATTR do_add_device(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	Sys.NetSend.srcidtype = pstMsg->stSrcL3Addr.stObject.enObjectType;
	Sys.NetSend.srcid = pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	Sys.NetSend.ip = pstMsg->stSrcL2Addr.ulIP;
	Sys.NetSend.port = pstMsg->stSrcL2Addr.ulPort;
	memcpy(Sys.rsp_name, &pstChatMsg->aucContent[3], NAME_LEN);
	memcpy(Sys.rsp_remoteid, &pstChatMsg->aucContent[19], 64);
	u16 sku = pstChatMsg->aucContent[1];
	sku <<= 8;
	sku |= pstChatMsg->aucContent[2];
	if (sku == PRODUCT_SKU_24G1)
	{
		light24g_study(pstMsg);
	}
	else
	{
		do_add_device_now(sku, NULL);
	}
}
void ICACHE_FLASH_ATTR del_device(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(id);
	u8 i;
	if (devn == MAX_DEVICE)
	{
		ESP_DBG("can not find device\r\n");
		return;
	}
	ESP_DBG("dev[%d]:nid=%d,sn=%d,sku=0x%04x name=%s\r\n", devn,
			Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sn,
			Sys.Config.Device[devn].sku, Sys.Config.Device[devn].name);
	i = IOT_USER_DEL_DEVICE_RSP;
	user_iot_sent(Sys.Config.Device[devn].nid,
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_MESSAGE, &i, 1, 1);
	memset(&Sys.Config.Device[devn], 0, sizeof(Sys.Config.Device[devn]));
	STUDY *pstudy = (STUDY *) os_zalloc(sizeof(STUDY));
	for (i = 0; i < MAX_STUDY; i++)
	{
		spi_flash_read(STUDY_ADDR + i * sizeof(STUDY), (uint32*) pstudy,
				sizeof(STUDY));
		if (pstudy->id == id)
		{
			ESP_DBG("del study[%d].id=%d,bid=%d\r\n", i, id, pstudy->bid);
			memset(pstudy, 0, sizeof(STUDY));
			study_ram2flash(i, pstudy);
		}
	}
	os_free(pstudy);
	config_ram2flash();
	display_devices();
}
void ICACHE_FLASH_ATTR do_dev_mod_name(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg =
			(ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	u32 id = pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
	u8 devn = find_dev_by_id(id);
	if (devn == MAX_DEVICE)
	{
		ESP_DBG("can not find device\r\n");
		return;
	}
	memcpy(Sys.Config.Device[devn].name, &pstChatMsg->aucContent[8],
	NAME_LEN);
	ESP_DBG("do_dev_mod: name=%s\r\n", Sys.Config.Device[devn].name);
	config_ram2flash();
	u8 buf[1];
	buf[0] = 0;
	user_iot_sent(pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL3Addr.stObject.enObjectType,
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0],
			pstMsg->stSrcL2Addr.ulIP, pstMsg->stSrcL2Addr.ulPort,
			IOT_DEV_MOD_RSP, buf, 1, 1);
}
void ICACHE_FLASH_ATTR timer(void)
{
	u8 i, j;
	if (Sys.Time.rtc.uwYear < 2014)
	{
		return;
	}
	for (i = 1; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].nid != 0 && Sys.Config.Device[i].name[0])
		{
			for (j = 0; j < MAX_TIMER; j++)
			{
				if (Sys.Config.Device[i].Timer[j].ValidFlag)
				{
					u8 n = Sys.Time.rtc.ucWDay;
					if (Sys.Config.Device[i].Timer[j].TimerFlag[n])
					{
						//ESP_DBG(
						//		"dev[%d].name=%s timer[%d] TimerFlag[%d]=%d\r\n",
						//		i, Sys.Config.Device[i].name, j, n,
						//		Sys.Config.Device[i].Timer[j].TimerFlag[n]);
						time_t rtc_stamp;
						time_t timer_stamp;
						rtc_stamp = system_mktime(Sys.Time.rtc.uwYear,
								Sys.Time.rtc.ucMon + 1, Sys.Time.rtc.ucDay,
								Sys.Time.rtc.ucHour, Sys.Time.rtc.ucMin,
								Sys.Time.rtc.ucSec);
						timer_stamp = system_mktime(Sys.Time.rtc.uwYear,
								Sys.Time.rtc.ucMon + 1, Sys.Time.rtc.ucDay,
								Sys.Config.Device[i].Timer[j].Hour,
								Sys.Config.Device[i].Timer[j].Minute, 0);
						if (rtc_stamp < (timer_stamp + 10)
								&& (rtc_stamp + 10) > timer_stamp
								&& Sys.DTimer[i].Timer[j].excutestamp == 0)
						{
							Sys.DTimer[i].Timer[j].excutestamp = rtc_stamp;
							ESP_DBG("excute timer[%d] devn=%d\r\n", j, i);
							u16 sku = Sys.Config.Device[i].sku;
							if (sku == PRODUCT_SKU_24G1)
							{
								u8 bid;
								if (Sys.Config.Device[i].Timer[j].powertemp
										& 0x80)
								{
									bid = 1;
								}
								else
								{
									bid = 2;
								}
								ESP_DBG("devn=%d bid=%d sku=%x\r\n", i, bid,
										Sys.Config.Device[i].sku);
								usart_control(PRODUCT_SKU_24G1, i, bid);
							}
							/*
							 else if (sku == PRODUCT_SKU_AC)
							 {
							 ARC_Struct ac;
							 ac.power =
							 Sys.Config.Device[i].Timer[j].powertemp;
							 ac.power >>= 7;
							 ac.temp =
							 Sys.Config.Device[i].Timer[j].powertemp;
							 ac.temp &= 0x7f;
							 ac.mode =
							 Sys.Config.Device[i].Timer[j].LumiFrom;
							 ac.mode >>= 4;
							 ac.op = Sys.Config.Device[i].Timer[j].LumiFrom;
							 ac.op &= 0x0f;
							 ac.wind = Sys.Config.Device[i].Timer[j].LumiTo;
							 ac.wind >>= 4;
							 ac.dir = Sys.Config.Device[i].Timer[j].LumiTo;
							 ac.dir &= 0x0f;
							 ac_control(i, &ac);
							 }
							 else if (sku == PRODUCT_SKU_TV)
							 {
							 tv_control(Sys.Config.Device[i].nid, 1);
							 }
							 */
							if (Sys.Config.Device[i].Timer[j].TimerFlag[n] == 1)
							{
								Sys.Config.Device[i].Timer[j].TimerFlag[n] = 0;
								config_ram2flash();
								ESP_DBG("once timer finished,never repeat\r\n");
							}
						}
					}
				}
			}
		}
	}
}
void ICACHE_FLASH_ATTR scene(void)
{
	u8 i;
	if (Sys.Status.doscene)
	{
		for (i = Sys.Status.doscene; i < MAX_DEVICE; i++)
		{
			if (Sys.Config.Device[i].nid && Sys.Config.Device[i].name[0]
					&& Sys.Status.scenen < MAX_SCENE)
			{
				if (Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp
						== 0)
				{
					continue;
				}
				u16 sku = Sys.Config.Device[i].sku;
				if (sku == PRODUCT_SKU_24G1)
				{
					usart_control(PRODUCT_SKU_24G1, i,
							Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp);
					os_delay_us(10000);
				}
				/*
				 else if (sku == PRODUCT_SKU_AC)
				 {
				 ARC_Struct ac;
				 ac.power =
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp;
				 ac.power >>= 7;
				 ac.temp =
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp;
				 ac.temp &= 0x7f;
				 ac.mode =
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.modeop;
				 ac.mode >>= 4;
				 ac.op =
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.modeop;
				 ac.op &= 0x0f;
				 ac.wind =
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.winddir;
				 ac.wind >>= 4;
				 ac.dir =
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.winddir;
				 ac.dir &= 0x0f;
				 ac_control(i, &ac);
				 }
				 else if (sku == PRODUCT_SKU_TV)
				 {
				 tv_control(Sys.Config.Device[i].nid,
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp);
				 }
				 else if (sku == PRODUCT_SKU_XM)
				 {
				 box_control(Sys.Config.Device[i].nid, XM,
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp);
				 }
				 else if (sku == PRODUCT_SKU_LS)
				 {
				 box_control(Sys.Config.Device[i].nid, LS,
				 Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp);
				 }
				 */
				else if (sku == PRODUCT_SKU_USER1 || sku == PRODUCT_SKU_USER2
						|| sku == PRODUCT_SKU_USER3)
				{
					usart_control(PRODUCT_SKU_USER1, i,
							Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp);
				}
				else
				{
					continue;
				}
				ESP_DBG("id=%d devn=%d cmd=%d sku=%x scenen=%d name=%s\r\n",
						Sys.Config.Device[i].nid, i,
						Sys.Config.Device[i].Scene[Sys.Status.scenen].action.powertemp,
						Sys.Config.Device[i].sku, Sys.Status.scenen,
						Sys.Config.Device[i].name);
				Sys.Status.doscene = i + 1;
				return;
			}
		}
		Sys.Status.doscene = 0;
		ESP_DBG("excute scene[%d] finished\r\n", Sys.Status.scenen);
	}
}
void ICACHE_FLASH_ATTR t500ms(void)
{
	u32 i;
	Sys.Time.sys.ms += 500;
	if (Sys.Time.sys.ms % 1000 == 0)
	{
		if (!Sys.Net.Stuatus.hasiotip)
		{
			led_blue_toggle();
		}
		if (Sys.Status.smartconfiging)
		{
			led_green_toggle();
		}
	}
	if (Sys.Status.study)
	{
		Sys.Status.study++;
		if (Sys.Status.study > STUDY_TIMEOUT * 2)
		{
			Sys.Status.study = 0;
			led_green_off();
			ESP_DBG("�ȴ���ʱ\r\n");
		}
	}
}
void ICACHE_FLASH_ATTR t1s(void)
{
	u8 buf[10];
	static u32 t1s_cout = 0;
	t1s_cout++;
	get_time();
	timer();
	if (t1s_cout % 2 == 0)
	{
		if (Sys.facttest)
		{
			if (Sys.facttest == 1)
			{
				led_green_on();
				//IR_Sent_Start(&bufff[1], &bufff[9]);
				ESP_DBG("ir send by gateway ir test\r\n");
				led_green_off();
				Sys.facttest++;
			}
			else if (Sys.facttest == 2)
			{
				buf[0] = 'h';
				buf[1] = 's';
				buf[2] = 'd';
				usart_cmd_send415(USART_CMD_SEND_433, 0x01, buf, 3);
				os_delay_us(10000);
				Sys.facttest++;
			}
			else if (Sys.facttest == 3)
			{
				buf[0] = 'h';
				buf[1] = 's';
				buf[2] = 'd';
				usart_cmd_send415(USART_CMD_SEND_315, 0x01, buf, 3);
				os_delay_us(10000);
				Sys.facttest++;
			}
			else if (Sys.facttest == 4)
			{
				usart_cmd_send24g2(RF_CMD_FactTest, NULL, 0);
				os_delay_us(10000);
				Sys.facttest++;
			}
			else if (Sys.facttest == 5)
			{
				ir_learn_start(0);
				Sys.Status.study = 1;
				Sys.facttest++;
			}
			else
			{
				Sys.facttest = 0;
			}
		}
	}
	if (t1s_cout % 60 == 0)
	{
		//usart_cmd_send24g2(RF_CMD_BEAT, NULL, 0);
	}
}
void ICACHE_FLASH_ATTR user_start(void)
{
	user_udp_init();
	user_tcpc_init();
	os_timer_disarm(&check_timer);
	os_timer_setfn(&check_timer, (os_timer_func_t *) user_check, NULL);
	os_timer_arm(&check_timer, 1000, 1);
	os_timer_disarm(&iot_beat_timer);
	os_timer_setfn(&iot_beat_timer, (os_timer_func_t *) iot_beat, NULL);
	os_timer_arm(&iot_beat_timer, BEAT_TIME_IOT_F, 1);
	os_timer_disarm(&hex_beat_timer);
	os_timer_setfn(&hex_beat_timer, (os_timer_func_t *) hex_beat, NULL);
	os_timer_arm(&hex_beat_timer, 30000, 0);
	os_timer_disarm(&t500ms_timer);
	os_timer_setfn(&t500ms_timer, (os_timer_func_t *) t500ms, NULL);
	os_timer_arm(&t500ms_timer, 500, 1);
	os_timer_disarm(&t1s_timer);
	os_timer_setfn(&t1s_timer, (os_timer_func_t *) t1s, NULL);
	os_timer_arm(&t1s_timer, 1000, 1);
	os_timer_disarm(&scene_timer);
	os_timer_setfn(&scene_timer, (os_timer_func_t *) scene, NULL);
	os_timer_arm(&scene_timer, 500, 1);
	os_timer_disarm(&usart_timer);
	os_timer_setfn(&usart_timer, (os_timer_func_t *) usart_rx, NULL);
	os_timer_arm(&usart_timer, 10, 1);
}

