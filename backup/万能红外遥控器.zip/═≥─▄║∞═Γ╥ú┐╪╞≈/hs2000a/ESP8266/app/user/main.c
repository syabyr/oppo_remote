#include "include.h"

SYS Sys;
os_timer_t beacon_send_timer;
u16 beacon_interval_time = 200; //200ms

static uint8 beacon_pack[90] =
{
//
		0x80, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
//----------------------------Modify BSSID------------------------//
		0x1a, 0xFE, 0x34, 0xa2, 0xc7,
		0x11,  //1a:fe:34:a2:c7:12
		0x1a, 0xFE, 0x34, 0xa2, 0xc7,
		0x11,  //1a:fe:34:a2:c7:12
//----------------------------------------------------------------//
		0x20, 0x01, 0x1e, 0xfa, 0x15, 0x00, 0x00, 0x00, 0x00, 0x00,
//----------------------------Modify beacon interval--------------//
		0xc8,
		0x00, 	//beacon interval  == beacon_interval_time
//----------------------------------------------------------------//
		0x01, 0x00, 0x00,
//----------------------------Modify SSID-------------------------//
		0x09,//length
		'O', 'P', 'P', 'L', 'E', '_', 'E', 'S', 'P',
//----------------------------------------------------------------//
		0x01, 0x08, 0x8b, 0x96, 0x82, 0x84, 0x0c, 0x18, 0x30, 0x60, 0x03, 0x01,
		0x01, 0x05, 0x04, 0x01, 0x02, 0x00, 0x00, 0x32, 0x04, 0x6c, 0x12, 0x24,
		0x48, 0xdd, 0x09, 0x18, 0xfe, 0x34, 0x03, 0x01, 0x00, 0x00, 0x00, 0x90,
		0xe2, 0x25, 0xf3 };

void ICACHE_FLASH_ATTR freedom_outside_cb_send(u8 status)
{
	static uint16 count = 0;

	if (0 == status)
	{
		//os_printf("$%d\r\n", (count++));
	}
	else
	{
		os_printf("send cb err\r\n");
	}
	if (Sys.Status.smartconfiging == 0)
	{
		ESP_DBG("һ��������ɣ�AP������ʧ\r\n");
	}
	else
	{
		os_timer_arm(&beacon_send_timer, beacon_interval_time, 0);
	}
}
void ICACHE_FLASH_ATTR send_beacon_timer_cb()
{
	if (0 != wifi_register_send_pkt_freedom_cb(freedom_outside_cb_send))
	{
		os_printf("register_send_pkt err!\r\n");
	}
	if (0 != wifi_send_pkt_freedom(beacon_pack, 88, 1))
	{ //36
		os_printf("send_pkt err!\r\n");
	}
}
void ICACHE_FLASH_ATTR wifi_handle_event_cb(System_Event_t *evt)
{
	os_printf("event %x\n", evt->event);
	switch (evt->event)
	{
	case EVENT_STAMODE_CONNECTED:
		os_printf("connect to ssid %s, channel %d\n",
				evt->event_info.connected.ssid,
				evt->event_info.connected.channel);
		break;
	case EVENT_STAMODE_DISCONNECTED:
		os_printf("disconnect from ssid %s, reason %d\n",
				evt->event_info.disconnected.ssid,
				evt->event_info.disconnected.reason);
		break;
	case EVENT_STAMODE_AUTHMODE_CHANGE:
		os_printf("mode: %d -> %d\n", evt->event_info.auth_change.old_mode,
				evt->event_info.auth_change.new_mode);
		break;
	case EVENT_STAMODE_GOT_IP:
		os_printf("ip:" IPSTR ",mask:" IPSTR ",gw:" IPSTR,
				IP2STR(&evt->event_info.got_ip.ip),
				IP2STR(&evt->event_info.got_ip.mask),
				IP2STR(&evt->event_info.got_ip.gw));
		os_printf("\n");
		break;
	case EVENT_SOFTAPMODE_STACONNECTED:
		os_printf("station: " MACSTR "join, AID = %d\n",
				MAC2STR(evt->event_info.sta_connected.mac),
				evt->event_info.sta_connected.aid);
		break;
	case EVENT_SOFTAPMODE_STADISCONNECTED:
		os_printf("station: " MACSTR "leave, AID = %d\n",
				MAC2STR(evt->event_info.sta_disconnected.mac),
				evt->event_info.sta_disconnected.aid);
		break;
	case EVENT_SOFTAPMODE_PROBEREQRECVED:
		os_printf("ʲô�����\r\n");
		break;
	default:
		break;
	}
}
void ICACHE_FLASH_ATTR scan_done(void *arg, STATUS status)
{
	u8 have_test_ssid = 0;
	u32 i = system_get_time();
	ESP_DBG("system_get_time = %d\r\n", i);
	uint8 ssid[33];
	char temp[128];
	if (status == OK)
	{
		struct bss_info *bss_link = (struct bss_info *) arg;
		bss_link = bss_link->next.stqe_next; //ignore the first one , it's invalid.
		while (bss_link != NULL)
		{
			os_memset(ssid, 0, 33);
			if (os_strlen(bss_link->ssid) <= 32)
			{
				os_memcpy(ssid, bss_link->ssid, os_strlen(bss_link->ssid));
			}
			else
			{
				os_memcpy(ssid, bss_link->ssid, 32);
			}
			os_printf("(%d,\"%s\",%d,\""MACSTR"\",%d)\r\n", bss_link->authmode,
					ssid, bss_link->rssi, MAC2STR(bss_link->bssid),
					bss_link->channel);
			if (!os_strcmp(bss_link->ssid, TESTSSID))
			{
				have_test_ssid = 1;
			}
			bss_link = bss_link->next.stqe_next;
		}
		wifi_station_get_config(&Sys.Net.stainfo);
		if (Sys.Net.stainfo.ssid[0] == 0x00 || Sys.Net.stainfo.ssid[0] == 0xff)
		{
			if (have_test_ssid == 1)
			{
				os_printf("find test router\r\n");
				os_strcpy(Sys.Net.stainfo.ssid, TESTSSID);
				os_strcpy(Sys.Net.stainfo.password, TESTPASS);
				Sys.Net.stainfo.bssid_set = 0;
				wifi_station_set_config_current(&Sys.Net.stainfo);
				wifi_station_connect();
			}
			else
			{
				ESP_DBG("don't have router,need into scan mode\r\n");
				wifi_set_opmode(STATION_MODE);
				wifi_set_channel(1);
				os_timer_disarm(&beacon_send_timer);
				os_timer_setfn(&beacon_send_timer,
						(os_timer_func_t *) send_beacon_timer_cb,
						NULL);
				os_timer_arm(&beacon_send_timer, 100, 0);
				smartconfig_set_type(SC_TYPE_ESPTOUCH); //SC_TYPE_ESPTOUCH,SC_TYPE_AIRKISS,SC_TYPE_ESPTOUCH_AIRKISS
				smartconfig_start(smartconfig_done);
				Sys.Status.smartconfiging = 1;
			}
		}
		else
		{
			ESP_DBG("already have station info\r\n");
			ESP_DBG("hostname=%s\r\n", wifi_station_get_hostname());
			wifi_set_opmode(STATION_MODE);
			wifi_station_set_reconnect_policy(true);
			wifi_station_ap_number_set(1);
			wifi_station_set_auto_connect(1);
		}
		wifi_set_event_handler_cb(wifi_handle_event_cb);
	}
	else
	{
		os_printf("scan fail !!!\r\n");
	}
	usart0_putc(0x02);
	usart0_putc(USART_CMD_GET_VERSION);
	os_delay_us(20000);
	user_start();
	// ----------------TX test-------------
	//wifi_station_scan(NULL, scan_done);
	// ----------------TX test-------------
}
void ICACHE_FLASH_ATTR system_init_do(void)
{
	os_printf("\r\nsystem init done\r\n");
	wifi_station_scan(NULL, scan_done);
}
uint32 ICACHE_FLASH_ATTR user_rf_cal_sector_set(void)
{
	enum flash_size_map size_map = system_get_flash_size_map();
	uint32 rf_cal_sec = 0;
	switch (size_map)
	{
	case FLASH_SIZE_4M_MAP_256_256:
		rf_cal_sec = 128 - 5;
		break;
	case FLASH_SIZE_8M_MAP_512_512:
		rf_cal_sec = 256 - 5;
		break;
	case FLASH_SIZE_16M_MAP_512_512:
	case FLASH_SIZE_16M_MAP_1024_1024:
		rf_cal_sec = 512 - 5;
		break;
	case FLASH_SIZE_32M_MAP_512_512:
	case FLASH_SIZE_32M_MAP_1024_1024:
		rf_cal_sec = 1024 - 5;
		break;
	default:
		rf_cal_sec = 0;
		break;
	}
	os_printf("user_rf_cal_sector_set:%d\r\n", size_map);
	return rf_cal_sec;
}
void ICACHE_FLASH_ATTR user_rf_pre_init(void)
{
}
char* rsts[] =
{ "REASON_DEFAULT_RST", "REASON_WDT_RST", "REASON_EXCEPTION_RST",
		"REASON_SOFT_WDT_RST", "REASON_SOFT_RESTART", "REASON_DEEP_SLEEP_AWAKE",
		"REASON_EXT_SYS_RST" };
void ICACHE_FLASH_ATTR user_init(void)
{
	u32 i;
	u8 iot_version[20];
	uart_init(BIT_RATE_115200, BIT_RATE_115200);
	UART_SetParity(UART0, EVEN_BITS);
	UART_SetPrintPort(UART1);
	system_set_os_print(1);
	os_printf("\r\n\r\nwelcome to use this smart home product!\r\n");
	struct rst_info* rst = system_get_rst_info();
	os_printf("exccause:%x epc1=%x epc2=%x epc3=%x excvaddr=%x depc=%x\r\n",
			rst->exccause, rst->epc1, rst->epc2, rst->epc3, rst->excvaddr,
			rst->depc);
	os_printf("reason:%s\r\n", rsts[rst->reason]);
	os_memset(&Sys, 0, sizeof(Sys));
	config_flash2ram();
	if (Sys.Config.BlankFlag != 0xab)
	{
		os_printf("System Restore in First Time\n");
		sys_factory_reset();
	}
	sys_ram_init();
	os_printf("Compile Time: %s %s\r\n", __DATE__, __TIME__);
	os_printf("SDK version:%s\r\n", system_get_sdk_version());
	os_sprintf(iot_version, "%s%d.%dt%s", VERSION_TYPE, IOT_VERSION_MAJOR,
	IOT_VERSION_MINOR, DEVICE_TYPE);
	os_printf("FIRMWARE VERSION = %s\r\n", iot_version);
	i = system_get_boot_version();
	os_printf("boot version = %d\r\n", i);
	i = system_get_cpu_freq();
	if (i == SYS_CPU_80MHz)
	{
		os_printf("system frequency = 80MHz\r\n");
	}
	else if (i == SYS_CPU_160MHz)
	{
		os_printf("system frequency = 160MHz\r\n");
	}
	else
	{
		os_printf("SELF-CHECK:NG->system frequency Unknow\r\n");
	}
	i = system_get_userbin_addr();
	os_printf("current userbin addr = %x\r\n", i);
	if (system_get_boot_mode() == 0)
	{
		os_printf("boot mode = SYS_BOOT_ENHANCE_MODE\r\n");
	}
	else
	{
		os_printf("boot mode = SYS_BOOT_NORMAL_MODE\r\n");
	}
	if (system_upgrade_userbin_check() == UPGRADE_FW_BIN1)
		os_printf("currunt system is APP1\r\n");
	else
		os_printf("currunt system is APP2\r\n");
	system_print_meminfo();
	i = system_get_free_heap_size();
	ESP_DBG("free heap size = %d\r\n", i);
	i = spi_flash_get_id();
	ESP_DBG("FLASH ID = %08X\r\n", i);
	if ((i >> 16) == 0x16)
	{
		os_printf("SELF-CHECK:OK->FLASH : W25Q32 4MBytes\r\n");
	}
	else
	{
		os_printf("SELF-CHECK:NG->FLASH Wrong!\r\n");
	}
	i = system_get_flash_size_map();
	if (i == FLASH_SIZE_32M_MAP_512_512)
	{
		os_printf("FLASH_SIZE_32M_MAP_512_512\r\n");
	}
	else if (i == FLASH_SIZE_32M_MAP_1024_1024)
	{
		os_printf("FLASH_SIZE_32M_MAP_1024_1024\r\n");
	}
	else
	{
		os_printf("SELF-CHECK:NG->FLASH MAP\r\n");
	}
	i = system_get_vdd33() * 100 / 1024;
	if (i < 310 || i > 350)
	{
		os_printf("SELF-CHECK:NG->VDD = %d.%02dV\r\n", i / 100, i % 100);
	}
	else
	{
		os_printf("SELF-CHECK:OK->VDD = %d.%02dV\r\n", i / 100, i % 100);
	}
	led_init();
	key_init();
	mcu_init();
	wifi_set_opmode(STATION_MODE);
	system_init_done_cb(system_init_do);
	//wifi_softap_get_config(&Sys.Net.apinfo);
	//ESP_DBG("softap->ssid:%s pass:%s\r\n", Sys.Net.apinfo.ssid,Sys.Net.apinfo.password);
	//wifi_set_opmode(STATIONAP_MODE);
	//wifi_station_get_config();
	//wifi_station_get_config_default();
	//wifi_station_set_config();
	//wifi_station_set_config_current();
	//wifi_station_disconnect();
	//wifi_station_connect();
	//wifi_station_get_connect_status();
	//wifi_station_scan();	//������ user_init �е��ñ��ӿڣ����ӿڱ�����ϵͳ��ʼ����ɺ󣬲��� ESP8266 station �ӿ�ʹ�ܵ�����µ��á�
	//wifi_station_get_ap_info();
	//wifi_station_ap_change();
	//wifi_station_get_current_ap_id();
	//wifi_station_set_hostname();
	//wifi_get_ip_info(STATION_IF,*info);
	//wifi_set_ip_info();
	//wifi_set_broadcast_if();
	//wifi_get_broadcast_if();
	//system_phy_set_max_tpw
	//system_phy_set_tpw_via_vdd33(uint16 vdd33)
	//system_restart_enhance
	//system_update_cpu_freq
}
