#include "include.h"

LOCAL void ICACHE_FLASH_ATTR led_on(unsigned char led)
{
	if (led == 1)
		GPIO_OUTPUT_SET(LED1_IO_NUM, 0);
	else if (led == 2)
		GPIO_OUTPUT_SET(LED2_IO_NUM, 1);
}
LOCAL void ICACHE_FLASH_ATTR led_off(unsigned char led)
{
	if (led == 1)
		GPIO_OUTPUT_SET(LED1_IO_NUM, 1);
	else if (led == 2)
		GPIO_OUTPUT_SET(LED2_IO_NUM, 0);
}

void ICACHE_FLASH_ATTR led_blue_on(void)
{
	led_on(2);
}
void ICACHE_FLASH_ATTR led_blue_off(void)
{
	led_off(2);
}
void ICACHE_FLASH_ATTR led_blue_toggle(void)
{
	if (GPIO_INPUT_GET(LED2_IO_NUM))
	{
		GPIO_OUTPUT_SET(LED2_IO_NUM, 0);
	}
	else
	{
		GPIO_OUTPUT_SET(LED2_IO_NUM, 1);
	}
}
void ICACHE_FLASH_ATTR led_green_toggle(void)
{
	if (GPIO_INPUT_GET(LED1_IO_NUM))
	{
		GPIO_OUTPUT_SET(LED1_IO_NUM, 0);
	}
	else
	{
		GPIO_OUTPUT_SET(LED1_IO_NUM, 1);
	}
}

void ICACHE_FLASH_ATTR led_green_on(void)
{
	led_on(1);
}
void ICACHE_FLASH_ATTR led_green_off(void)
{
	led_off(1);
}

void ICACHE_FLASH_ATTR led_init(void)
{
	PIN_FUNC_SELECT(LED1_IO_MUX, LED1_IO_FUNC);
	PIN_FUNC_SELECT(LED2_IO_MUX, LED2_IO_FUNC);
	led_green_off();
	led_blue_on();
}
