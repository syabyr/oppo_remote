#include "include.h"

void ICACHE_FLASH_ATTR transno_fifo_in(u32 dat)
{
	u8 i;
	for (i = 0; i < (MAX_TRANSNO - 1); i++)
	{
		Sys.NetSend.transno[i] = Sys.NetSend.transno[i + 1];
	}
	Sys.NetSend.transno[MAX_TRANSNO - 1] = dat;
}
u8 ICACHE_FLASH_ATTR transno_fifo_check(u32 dat)
{
	u8 i;
	for (i = 0; i < MAX_TRANSNO; i++)
	{
		if (Sys.NetSend.transno[i] == dat)
		{
			return 1;
		}
	}
	return 0;
}
u8 ICACHE_FLASH_ATTR check_trans_no(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	if (pstMsg->ulMsgType == IOT_SHKHAND_ACK)
	{
		return 0;
	}
	if (pstMsg->ulSrcTransNo == 0xffffffff)
	{
		return 1;
	}
	if (pstMsg->ulMsgType == IOT_APP_FIND_REQ)
	{
		if (Sys.NetSend.no != pstMsg->ulSrcTransNo)
		{
			Sys.NetSend.no = pstMsg->ulSrcTransNo;
			return 0;
		}
	}
	Sys.NetSend.no = pstMsg->ulSrcTransNo;
	if (transno_fifo_check(pstMsg->ulSrcTransNo) == 0)
	{
		transno_fifo_in(pstMsg->ulSrcTransNo);
		return 0;
	}
	return 1;
}
void ICACHE_FLASH_ATTR do_user_define(ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{

	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg;
	pstChatMsg = (ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	print_buffer(pstChatMsg->aucContent, 83);
	switch (pstChatMsg->aucContent[0])
	{
	case IOT_USER_ADD_DEVICE:
		do_add_device(pstMsg);
		break;
	case IOT_USER_DEL_DEVICE:
		del_device(pstMsg);
		break;
	case IOT_USER_DEV_CTL:
		dev_control(pstMsg);
		break;
	case IOT_USER_REMOTEID_REQ:
		do_check_remoteid(pstMsg);
		break;
	case IOT_USER_IR_SEND:
		ir_send(pstMsg);
		break;
	case IOT_USER_IR_STUDY:				// maybe not used
		ir_study(pstMsg);
		break;
	case IOT_USER_BUTTON_ADD:
		do_button_add_mod(pstMsg, 1);
		break;
	case IOT_USER_BUTTON_MOD:
		do_button_add_mod(pstMsg, 2);
		break;
	case IOT_USER_BUTTON_REQ:
		do_button_check(pstMsg);
		break;
	case IOT_USER_OTA_CHECK:
		do_ota_check(pstMsg);
		break;
	case IOT_USER_OTA_START:
		do_ota_start(pstMsg);
		break;
	case IOT_USER_MAC_LIST_REQ:
		do_mac_list_check(pstMsg);
		break;
	case IOT_USER_SCENE_DEL_REQ:
		do_scene_del(pstMsg);
		break;
	case IOT_USER_SCENE_STUDY_REQ:
	case IOT_USER_SCENE_ACSTUDY_REQ:
		do_scene_study(pstMsg);
		break;
	case IOT_USER_DEV_SYNC_REQ:
		do_dev_sync(pstMsg);
		break;
	default:
		break;
	}
}
void ICACHE_FLASH_ATTR user_udp_recv(void *arg, char *data, unsigned short len)
{
	U8 g_aucMsgBuff[1024];
	ST_IOT_MSG_BASE_HEAD_MSG* pstMsg = (ST_IOT_MSG_BASE_HEAD_MSG*) g_aucMsgBuff;
	ST_IOT_UPDATE_HOST_IND_MSG* pstUpdtHostIndMsg = NULL;
	ST_IOT_CHAT_SHKHAND_ACK_MSG* pstShkHandAckMsg = NULL;
	ST_IOT_CHAT_CONTENT_MSG* pstChatMsg = NULL;
	U8 aucPassPhrase[21] = "1234567890abcdfghjef";
	U8 aucOpPassPhrase[21] = "";
	U32 ulCheckSumCRC = 0;
	if (data == NULL)
	{
		ESP_DBG("user_udp_recv: data null\r\n");
		return;
	}
	os_memset(g_aucMsgBuff, 0, sizeof(g_aucMsgBuff));
	os_memcpy(g_aucMsgBuff, data, len);
	if (sizeof(ST_IOT_MSG_BASE_HEAD_MSG) > len)
	{
		ESP_DBG("user_udp_recv: data too short=%d\r\n", len);
		print_buffer(g_aucMsgBuff, len);
		return;		//�����Ƿ���Ϣ
	}
	remot_info *premot = NULL;
	if (espconn_get_connection_info(&udp_conn, &premot, 0) != ESPCONN_OK)
	{
		ESP_DBG("��ȡ�����Է�ip��Ϣ\r\n");
		return;
	}
	pstMsg->stSrcL2Addr.ulIP = OPP_NTOHL(*(u32* ) premot->remote_ip);
	pstMsg->stSrcL2Addr.ulPort = OPP_NTOHL(premot->remote_port);
	//os_sprintf(DeviceBuffer, "%s" MACSTR " " IPSTR, device_find_response_ok, MAC2STR(hwaddr), IP2STR(&ipconfig.ip));
	if (((0xF0E0D0C0 != OPP_NTOHL(pstMsg->ulL2Type))
			|| (IOT_UPDATE_HOST_IND != OPP_NTOHL(pstMsg->ulMsgType)))
			&& (Sys.Net.iot_ip == *(u32*) premot->remote_ip))
	{
		//����
		IOT_DECodeNetMsgToHostMsg(pstMsg,
				OffsetOf(ST_IOT_MSG_BASE_HEAD_MSG, ulSrcTransNo),
				OffsetOfNext(ST_IOT_MSG_BASE_HEAD_MSG, ulReserve),
				aucPassPhrase);
	}
	pstChatMsg = (ST_IOT_CHAT_CONTENT_MSG*) (&(pstMsg->ulSrcTransNo));
	if ((IOT_UPDATE_HOST_IND != OPP_NTOHL(pstMsg->ulMsgType))
			&& (IOT_SHKHAND_REQ != OPP_NTOHL(pstMsg->ulMsgType))
			&& (IOT_SHKHAND_ACK != OPP_NTOHL(pstMsg->ulMsgType))
			&& (IOT_SHKHAND_ACK_EX != OPP_NTOHL(pstMsg->ulMsgType))
			&& (IOT_CHAT_CONTENT != OPP_NTOHL(pstMsg->ulMsgType))
			&& (IOT_APP_OTA_REQ != OPP_NTOHL(pstMsg->ulMsgType)))
	{
		//��ȡ������Կ
		u8 pass[16];
		if (memcmp(Sys.Config.aucOpPwd, Sys.Net.stamac, 6) == 0)
		{
			memset(pass, 0, 16);
			memcpy(pass, Sys.Net.stamac, 6);
			//pass[7] =	find_dev_by_id(	OPP_NTOHL(pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]));
		}
		else
		{
			memcpy(pass, Sys.Config.aucOpPwd, 16);
		}
		IOT_PassPhrase_Generate(pass, aucOpPassPhrase);
		//APP��Ϣ�����
		IOT_DECodeNetMsgToHostMsg(pstMsg,
				OffsetOfNext(ST_IOT_MSG_BASE_HEAD_MSG, ulReserve),
				(OffsetOfNext(ST_IOT_MSG_BASE_HEAD_MSG, ulReserve)
						+ (OPP_NTOHL(pstMsg->ulMsgLen) - IOT_MSG_BASE_HEAD_LEN)),
				aucOpPassPhrase);
	}
	//CRCУ�����
	ulCheckSumCRC = OPP_NTOHL(pstMsg->ulCheckSum);
	pstMsg->ulCheckSum = OPP_HTONL(0);
	pstMsg->ulCheckSum = OppCalcCRC((U8*) (&(pstMsg->ulSrcTransNo)),
			OPP_NTOHL(pstMsg->ulMsgLen));
	pstMsg->ulCheckSum = OPP_HTONL(pstMsg->ulCheckSum);
	if (ulCheckSumCRC != OPP_NTOHL(pstMsg->ulCheckSum))
	{
		ESP_DBG("CRC error:%x\r\n", OPP_NTOHL(pstMsg->ulMsgType));
		return;
	}
	//ϵͳͨ�Ż�����Ϣͷ�ֽ���ת��
	IOT_TransNetOrderToHostOrder((ST_IOT_MSG_BASE_HEAD_MSG*) g_aucMsgBuff);
	if (check_trans_no(pstMsg))
	{
		if (Sys.debug)
		{
			ESP_DBG("same transno=%x msg=%x\r\n", pstMsg->ulSrcTransNo,
					pstMsg->ulMsgType);
		}
		return;
	}
	// ��Ҫ�ظ������
	if (pstMsg->ulMsgType != IOT_UPDATE_HOST_IND
			&& pstMsg->ulMsgType != IOT_SHKHAND_ACK)
	{
		Sys.NetSend.rno = pstMsg->ulSrcTransNo;
		//ESP_DBG("��Ҫ�ظ���������ǣ�%d\r\n", pstMsg->ulSrcTransNo);
	}
	//��Ϣ����
	switch (pstMsg->ulMsgType)
	{
	case IOT_SHKHAND_ACK_EX:
		ESP_DBG("����ʲô��Ϣ��\r\n");
		break;
	case IOT_UPDATE_HOST_IND:	//����IOT������������ַ��Ϣ
		pstUpdtHostIndMsg = (ST_IOT_UPDATE_HOST_IND_MSG*) pstMsg;
		//��Ϣ���ֽ���ת��
		pstUpdtHostIndMsg->ulHOSTServerIP = OPP_NTOHL(
				pstUpdtHostIndMsg->ulHOSTServerIP);
		pstUpdtHostIndMsg->ulHOSTServerPort = OPP_NTOHL(
				pstUpdtHostIndMsg->ulHOSTServerPort);
		//���¸ý���IOT������������Ϣ
		Sys.Net.iot_ip = pstUpdtHostIndMsg->ulHOSTServerIP;
		ESP_DBG("IOT_UPDATE_HOST_IND\r\n");
		ESP_DBG("����ʲô��Ϣ��\r\n");
		break;
	case IOT_SHKHAND_ACK: //��ַѧϰ��Ӧ
		pstShkHandAckMsg =
				(ST_IOT_CHAT_SHKHAND_ACK_MSG*) (&(pstMsg->ulSrcTransNo));
		Sys.Net.outip = pstMsg->stDstL2Addr.ulIP;
		Sys.Net.outport = pstMsg->stDstL2Addr.ulPort;
		if ((1 != pstMsg->stDstL3Addr.stObject.enObjectType)
				|| (Sys.Net.selfID
						!= pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]))
		{
			//ȷ��ȷʵ�Ǳ��豸��㷢��ȥSHK HAND����Ķ�Ӧ��SHK HAND��Ӧ
			if (((IOT_MSG_BASE_HEAD_LEN + sizeof(pstShkHandAckMsg->aucPhyObjID))
					== pstShkHandAckMsg->ulMsgLen)
					&& (0
							== os_memcmp(pstShkHandAckMsg->aucPhyObjID,
									Sys.Net.selfSN, sizeof(Sys.Net.selfSN))))
			{
				if (Sys.debug)
				{
					ESP_DBG("ulSelfIDType:%d ulSelfID:%d\r\n",
							pstMsg->stDstL3Addr.stObject.enObjectType,
							pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]);
				}
				u8 devn;
				devn = find_dev_by_sn(Sys.Net.selfSN[7]);
				if (devn < MAX_DEVICE)
				{

					Sys.Config.Device[devn].nid =
							pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0];
					Sys.Config.Device[devn].fakeid = 0;
					ESP_DBG("ID���£�devn[%d].nid=%d,sn=%d,oldid=%d,newid=%d\r\n",
							devn, Sys.Config.Device[devn].nid,
							Sys.Config.Device[devn].sn, Sys.Net.selfID,
							pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]);
				}
			}
		}
		//(����)���µ�ǰʱ��(NTPʱ���IOT�����Ʒ�����ʱ��->����ʱ��)
		//IOT_UpdateTimeFromIOTHost(pstShkHandAckMsg->ulReserve);
		Sys.Time.timestamp = pstShkHandAckMsg->ulReserve;
		if (abs(Sys.Config.timezone) < 14)
		{
			Sys.Time.timestamp += Sys.Config.timezone * 3600;
			net_set_time();
		}
		break;
	case IOT_DEV_CHECK_REQ:
		ESP_DBG("IOT_DEV_CHECK_REQ\r\n");
		do_check_status(pstMsg);
		ESP_DBG("do_check_status:ip=%x,port=%x\r\n", Sys.NetSend.ip,
				Sys.NetSend.port);
		break;
	case IOT_DEV_MOD_REQ:
		ESP_DBG("IOT_DEV_MOD_REQ\r\n");
		do_dev_mod_name(pstMsg);
		break;
	case IOT_DEV_RESTORE_REQ:
		ESP_DBG("IOT_DEV_RESTORE_REQ\r\n");
		do_restore_factory(pstMsg);
		break;
	case IOT_PASS_CHANGE_REQ:
		ESP_DBG("IOT_PASS_CHANGE_REQ\r\n");
		do_change_pass(pstMsg);
		break;
	case IOT_MESSAGE:
		do_user_define(pstMsg);
		break;
	case IOT_RSSI_CHECK_REQ:
		do_rssi_check(pstMsg);
		break;
	case IOT_APP_FIND_REQ:
		if (is_same_net(pstMsg->stSrcL2Addr.ulIP))
		{
			//if (Sys.NetSend.asyncmsg1 != IOT_APP_FIND_REQ)
			//{
			//	Sys.NetSend.asyncmsg1 = IOT_APP_FIND_REQ;
			ESP_DBG("IOT_APP_FIND at %d\r\n", system_get_time());
			Sys.NetSend.srcidtype = pstMsg->stSrcL3Addr.stObject.enObjectType;
			Sys.NetSend.srcid =
					pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0];
			Sys.NetSend.ip = pstMsg->stSrcL2Addr.ulIP;
			Sys.NetSend.port = pstMsg->stSrcL2Addr.ulPort;
			//find_dev_all_rsp();
			find_dev_rsp(0, Sys.NetSend.srcidtype, Sys.NetSend.srcid,
					Sys.NetSend.ip, Sys.NetSend.port);
			//}
		}
		break;
	case IOT_SCENE_CHECK_REQ:
		do_scene_check(pstMsg);
		break;
	case IOT_SCENE_SET_REQ:
		do_scene_set(pstMsg);
		break;
	case IOT_SCENE_CAL_REQ:
		do_scene(pstMsg);
		break;
	case IOT_TIMER_CHECK_REQ:
		do_timer_check(pstMsg);
		break;
	case IOT_TIMER_SET_REQ:
		do_timer_set(pstMsg);
		break;
	default:
		ESP_DBG("UNKNOW IOT Msg(0x%08X)\r\n", pstMsg->ulMsgType);
		break;
	}
}
void ICACHE_FLASH_ATTR user_iot_sent(U32 ulSelfID, U32 IDType, u32 targetID,
		U32 ulPeerIP, U32 ulPeerPort, u32 ulMsgType, char* pbuf, u32 len,
		U32 ulAppENCFlag)
{
	ST_IOT_CHAT_CONTENT_MSG stObjMsg;
	stObjMsg.ulSrcTransNo = Sys.NetSend.rno;
	stObjMsg.ulDstTransNo = Sys.NetSend.rno;
	stObjMsg.ulMsgLen = IOT_MSG_BASE_HEAD_LEN + len;
	stObjMsg.ulCheckSum = 0;
	stObjMsg.ulMsgType = ulMsgType;
	stObjMsg.ulReserve = 0;
	memcpy(stObjMsg.aucContent, pbuf, len);
	IOT_CHAT_SendToObject(ulSelfID, ulPeerIP, ulPeerPort,
			EN_IOT_MSG_L3_ADDR_OBJ, IDType, targetID, (U8*) (&stObjMsg),
			stObjMsg.ulMsgLen, ulAppENCFlag);
}
