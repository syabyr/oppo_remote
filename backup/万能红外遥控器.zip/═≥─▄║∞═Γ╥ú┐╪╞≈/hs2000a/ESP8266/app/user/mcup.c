#include "include.h"

enum
{
	MCUP_NONE = 0,
	MCUP_GET,
	MCUP_GET_VERSION,
	MCUP_GET_ID,
	MCUP_ERASE_MEMORY,
	MCUP_ERASE_MEMORY_ALL,
	MCUP_WRITE_MEMORY,
	MCUP_WRITE,
	MCUP_RESULT
};
enum
{
	MCUP_ACK = 0x79, MCUP_NACK = 0x1f
};
extern binfile_t binfile;

void ICACHE_FLASH_ATTR mcu_rst_high(void)
{
	GPIO_OUTPUT_SET(RST_IO_NUM, 1);
	GPIO_DIS_OUTPUT(RST_IO_NUM);
	PIN_PULLUP_EN(RST_IO_MUX);
}
void ICACHE_FLASH_ATTR mcu_rst_low(void)
{
	GPIO_OUTPUT_SET(RST_IO_NUM, 0);
}
void ICACHE_FLASH_ATTR mcu_boot_high(void)
{
	GPIO_OUTPUT_SET(BOOT_IO_NUM, 1);
}
void ICACHE_FLASH_ATTR mcu_boot_low(void)
{
	GPIO_OUTPUT_SET(BOOT_IO_NUM, 0);
}
void ICACHE_FLASH_ATTR mcu_boot(void)
{
	mcu_boot_high();
	mcu_rst_low();
	os_delay_us(10000);
	mcu_rst_high();
	Sys.Mcup.State = MCUP_GET;
	os_delay_us(10000);
	usart0_putc(0x7f);
}
void ICACHE_FLASH_ATTR mcu_init(void)
{
	PIN_FUNC_SELECT(RST_IO_MUX, RST_IO_FUNC);
	PIN_PULLUP_EN(RST_IO_MUX);
	PIN_FUNC_SELECT(BOOT_IO_MUX, BOOT_IO_FUNC);
	PIN_PULLUP_DIS(BOOT_IO_MUX);
	mcu_boot_low();
	mcu_rst_low();
	os_delay_us(10000);
	mcu_rst_high();
}
void ICACHE_FLASH_ATTR mcup_exit(u8 flag)
{
	if (flag)
	{
		ESP_DBG("mcup error = %d\r\n", flag);
	}
	else
	{
		ESP_DBG("mcup success\r\n");
	}
	mcu_boot_low();
	os_delay_us(10000);
	mcu_rst_low();
	os_delay_us(10000);
	mcu_rst_high();
	Sys.Mcup.State = MCUP_NONE;
}
void ICACHE_FLASH_ATTR mcup_recv_cb(u8 *buf, u8 len)
{
	u32 i;
	unsigned char checksum = 0;
	static u32 rom_addr;
	static u32 addr;
	if (Sys.Mcup.State == MCUP_GET)
	{
		if (buf[0] == MCUP_ACK)
		{
			Sys.Mcup.State = MCUP_GET_VERSION;
			usart0_putc(0x01);
			usart0_putc(0xfE);
		}
		else
		{
			mcup_exit(MCUP_GET_VERSION);
		}
	}
	else if (Sys.Mcup.State == MCUP_GET_VERSION)
	{
		if (buf[0] == MCUP_ACK)
		{
			Sys.Mcup.Version = buf[1];
			Sys.Mcup.Option[0] = buf[2];
			Sys.Mcup.Option[1] = buf[3];
			ESP_DBG("mcup version = %d.%d option bytes = 0x%02x 0x%02x\r\n",
					Sys.Mcup.Version >> 4, Sys.Mcup.Version & 0x0f,
					Sys.Mcup.Option[0], Sys.Mcup.Option[1]);
			Sys.Mcup.State = MCUP_GET_ID;
			usart0_putc(0x02);
			usart0_putc(0xfd);
		}
		else
		{
			mcup_exit(MCUP_GET_VERSION);
		}
	}
	else if (Sys.Mcup.State == MCUP_GET_ID)
	{
		if (buf[0] == MCUP_ACK)
		{
			Sys.Mcup.ID[0] = buf[2];
			Sys.Mcup.ID[1] = buf[3];
			ESP_DBG("mcup ID = 0x%02x 0x%02x\r\n", Sys.Mcup.ID[0],
					Sys.Mcup.ID[1]);
			Sys.Mcup.State = MCUP_ERASE_MEMORY;
			usart0_putc(0x44);
			usart0_putc(0xbb);
		}
		else
		{
			mcup_exit(MCUP_GET_ID);
		}
	}
	else if (Sys.Mcup.State == MCUP_ERASE_MEMORY)
	{
		if (buf[0] == MCUP_ACK)
		{
			Sys.Mcup.State = MCUP_ERASE_MEMORY_ALL;
			rom_addr = binfile.startaddr;
			addr = 0;
			ESP_DBG("rom_addr=%x len=%d version=%d\r\n", rom_addr, binfile.len,
					binfile.version);
			usart0_putc(0xff);
			usart0_putc(0xff);
			usart0_putc(0x00);
		}
		else
		{
			mcup_exit(MCUP_ERASE_MEMORY);
		}
	}
	else if (Sys.Mcup.State == MCUP_ERASE_MEMORY_ALL)
	{
		if (buf[0] == MCUP_ACK)
		{
			Sys.Mcup.State = MCUP_WRITE_MEMORY;
			usart0_putc(0x31);
			usart0_putc(0xce);
		}
		else
		{
			mcup_exit(MCUP_ERASE_MEMORY_ALL);
		}
	}
	else if (Sys.Mcup.State == MCUP_WRITE_MEMORY)
	{

		if (buf[0] == MCUP_ACK)
		{
			Sys.Mcup.State = MCUP_WRITE;
			usart0_putc((rom_addr >> 24) & 0xff);
			usart0_putc((rom_addr >> 16) & 0xff);
			usart0_putc((rom_addr >> 8) & 0xff);
			usart0_putc((rom_addr >> 0) & 0xff);
			checksum = 0;
			checksum ^= (rom_addr >> 24) & 0xff;
			checksum ^= (rom_addr >> 16) & 0xff;
			checksum ^= (rom_addr >> 8) & 0xff;
			checksum ^= (rom_addr >> 0) & 0xff;
			usart0_putc(checksum);
		}
		else
		{
			mcup_exit(MCUP_WRITE_MEMORY);
		}
	}
	else if (Sys.Mcup.State == MCUP_WRITE)
	{

		if (buf[0] == MCUP_ACK)
		{
			ESP_DBG("mcup write : %07x\r\n", rom_addr);
			if (addr < binfile.len)
				Sys.Mcup.State = MCUP_ERASE_MEMORY_ALL;
			else
				Sys.Mcup.State = MCUP_RESULT;
			usart0_putc(0xff);
			checksum = 0;
			checksum ^= 0xff;
			for (i = 0; i < 64; i++)
			{
				unsigned char temp_data[4];
				temp_data[0] = binfile.data[addr / 4 + i] >> 0;
				temp_data[1] = binfile.data[addr / 4 + i] >> 8;
				temp_data[2] = binfile.data[addr / 4 + i] >> 16;
				temp_data[3] = binfile.data[addr / 4 + i] >> 24;

				usart0_putc(temp_data[0]);
				usart0_putc(temp_data[1]);
				usart0_putc(temp_data[2]);
				usart0_putc(temp_data[3]);

				checksum ^= temp_data[0];
				checksum ^= temp_data[1];
				checksum ^= temp_data[2];
				checksum ^= temp_data[3];
				//ESP_DBG("%08X ", binfile.data[addr / 4 + i]);
			}
			usart0_putc(checksum);
			addr += 256;
			rom_addr += 256;
		}
		else
		{
			mcup_exit(MCUP_WRITE);
		}
	}
	else if (Sys.Mcup.State == MCUP_RESULT)
	{
		if (buf[0] == MCUP_ACK)
		{
			ESP_DBG("mcup result\r\n");
			mcup_exit(0);
		}
		else
		{
			mcup_exit(MCUP_RESULT);
		}
	}
}

