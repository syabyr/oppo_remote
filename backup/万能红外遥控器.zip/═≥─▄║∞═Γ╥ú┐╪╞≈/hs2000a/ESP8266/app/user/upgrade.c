#include "include.h"

LOCAL void ICACHE_FLASH_ATTR user_upgrade_rsp(void *arg)
{
	struct upgrade_server_info *server = arg;
	if (server->upgrade_flag == true)
	{
		ESP_DBG("user_esp_platform_upgrade_successful\n");
		if (Sys.Status.forceupgrade)
		{
			u8 buf[5];
			buf[0] = IOT_USER_OTA_START_RSP;
			user_iot_sent(Sys.NetSend.id, Sys.NetSend.srcidtype,
					Sys.NetSend.srcid, Sys.NetSend.ip, Sys.NetSend.port,
					IOT_MESSAGE, buf, 1, 1);
			os_delay_us(1000);
			ESP_DBG("������ɣ���Ҫ����һ�£����ϻ���~\r\n");
			system_upgrade_reboot();
		}
		else
		{
			ESP_DBG("already download done new app,could upgrade now\r\n");
		}
	}
	else
	{
		ESP_DBG("user_esp_platform_upgrade_failed\n");
	}
	Sys.Status.forceupgrade = 0;
	Sys.Status.upgrading = 0;
	os_timer_disarm(&hex_beat_timer);
	os_timer_setfn(&hex_beat_timer, (os_timer_func_t *) hex_beat, NULL);
	os_timer_arm(&hex_beat_timer, BEAT_TIME_HEX, 0);
	os_free(server->url);
	server->url = NULL;
	os_free(server);
	server = NULL;
}
void ICACHE_FLASH_ATTR user_upgrade_begin(struct espconn *pespconn, char *path,
		char *file1, char *file2)
{
	struct upgrade_server_info *server;
	server = (struct upgrade_server_info *) os_zalloc(
			sizeof(struct upgrade_server_info));

	server->pespconn = pespconn;
	server->port = pespconn->proto.tcp->remote_port;
	server->check_cb = user_upgrade_rsp;
	server->check_times = 120000;
	os_memcpy(server->ip, pespconn->proto.tcp->remote_ip, 4);
	if (server->url == NULL)
	{
		server->url = (uint8 *) os_zalloc(512);
	}
	if (system_upgrade_userbin_check() == UPGRADE_FW_BIN1)
	{
		os_sprintf(server->url,
				"GET /upgrade/download?file=%s%s HTTP/1.0\r\nHost: "IPSTR":%d\r\n"upgradehd"",
				path, file2, IP2STR(server->ip), server->port);
	}
	else if (system_upgrade_userbin_check() == UPGRADE_FW_BIN2)
	{
		os_sprintf(server->url,
				"GET /upgrade/download?file=%s%s HTTP/1.0\r\nHost: "IPSTR":%d\r\n"upgradehd"",
				path, file1, IP2STR(server->ip), server->port);
	}
	ESP_DBG("user_upgrade_begin:url=%s\n", server->url);
	if (Sys.Status.upgrading == 0)
	{
		Sys.Status.upgrading = 1;
		os_timer_disarm(&hex_beat_timer);
		if (system_upgrade_start(server) == false)
		{
			ESP_DBG("upgrade is already started\r\n");
		}
		else
		{
			ESP_DBG("system_upgrade_start:ok\r\n");
		}
	}
}
