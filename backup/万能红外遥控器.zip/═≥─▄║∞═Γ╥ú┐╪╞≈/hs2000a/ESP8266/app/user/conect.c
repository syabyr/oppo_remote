#include "include.h"

struct espconn udp_conn;
struct espconn tcp_conn;

void ICACHE_FLASH_ATTR retry_smartconfig(void)
{
	Sys.Net.stainfo.ssid[0] = 0x00;
	wifi_station_set_config(&Sys.Net.stainfo);
	system_restart();
}
void ICACHE_FLASH_ATTR smartconfig_done(sc_status status, void *pdata)
{
	switch (status)
	{
	case SC_STATUS_WAIT:
		os_printf("SC_STATUS_WAIT\n");
		break;
	case SC_STATUS_FIND_CHANNEL:
		os_printf("SC_STATUS_FIND_CHANNEL\n");
		break;
	case SC_STATUS_GETTING_SSID_PSWD:
		os_printf("SC_STATUS_GETTING_SSID_PSWD\n");
		sc_type *type = pdata;
		if (*type == SC_TYPE_ESPTOUCH)
		{
			os_printf("SC_TYPE:SC_TYPE_ESPTOUCH\n");
		}
		else
		{
			os_printf("SC_TYPE:SC_TYPE_AIRKISS\n");
		}
		break;
	case SC_STATUS_LINK:
		os_printf("SC_STATUS_LINK\n");
		struct station_config *sta_conf = pdata;
		ESP_DBG("���ҵ�WIFI������\r\n");
		wifi_station_set_config(sta_conf);
		wifi_station_disconnect();
		wifi_station_connect();
		Sys.Status.smartconfiging = 0;
		led_green_off();
		break;
	case SC_STATUS_LINK_OVER:
		os_printf("SC_STATUS_LINK_OVER\n");
		if (pdata != NULL)
		{
			uint8 phone_ip[4] =
			{ 0 };

			os_memcpy(phone_ip, (uint8*) pdata, 4);
			os_printf("Phone ip: %d.%d.%d.%d\n", phone_ip[0], phone_ip[1],
					phone_ip[2], phone_ip[3]);
		}
		smartconfig_stop();
		break;
	}
}
LOCAL void ICACHE_FLASH_ATTR user_tcpc_sent_cb(void *arg)
{
	Sys.Net.Stuatus.tcpcsend = 0;
}
LOCAL void ICACHE_FLASH_ATTR user_tcpc_recv_cb(void *arg, char *pusrdata,
		unsigned short length)
{
	u8 tverh;
	u8 tverl;
	char *pstr = NULL;
	char path[100];
	char file1[50];
	char file2[50];
	char verh[4];
	char verl[4];
	if (length == 0 || pusrdata == NULL)
	{
		return;
	}
	//ESP_DBG("user_tcpc_recv_cb: %d\r\n%s\r\n", length, pusrdata);
	pstr = (char*) os_strstr(pusrdata, "\r\n\r\n");
	if (pstr == NULL)
		return;
	pusrdata = pstr + 4;				// pass "\r\n\r\n"
	pstr = (char*) os_strstr(pusrdata, "\r\n");
	if (pstr == NULL)
		return;
	pusrdata = pstr + 2;				// pass "NEWEST"
	pstr = (char*) os_strstr(pusrdata, "\r\n");	// find "path"
	if (pstr == NULL)
		return;
	os_memcpy(path, pusrdata, pstr - pusrdata);
	path[pstr - pusrdata] = 0;
	//ESP_DBG("path=%s\r\n", path);
	pstr = (char*) os_strstr(pusrdata, "lvc2000a/");
	if (pstr == NULL)
		return;
	pusrdata = pstr + 9;
	pstr = (char*) os_strstr(pusrdata, ".");
	if (pstr == NULL)
		return;
	os_memcpy(verh, pusrdata, pstr - pusrdata);
	verh[pstr - pusrdata] = 0;
	pusrdata = pstr + 1;
	pstr = (char*) os_strstr(pusrdata, "/");
	if (pstr == NULL)
		return;
	os_memcpy(verl, pusrdata, pstr - pusrdata);
	verl[pstr - pusrdata] = 0;
	tverh = atoi(verh);
	tverl = atoi(verl);
	if (Sys.Config.verh != tverh || Sys.Config.verl != tverl)
	{
		Sys.Config.verh = tverh;
		Sys.Config.verl = tverl;
		config_ram2flash();
	}
	ESP_DBG("�ƶ˹̼��汾��:%d.%d\r\n", Sys.Config.verh, Sys.Config.verl);

	pstr = (char*) os_strstr(pusrdata, "\r\n");
	if (pstr == NULL)
		return;

	pusrdata = pstr + 2;
	pstr = (char*) os_strstr(pusrdata, "\r\n");
	if (pstr == NULL)
		return;
	os_memcpy(file1, pusrdata, pstr - pusrdata);
	file1[pstr - pusrdata] = 0;
	//ESP_DBG("file1=%s\r\n", file1);

	pusrdata = pstr + 2;
	pstr = (char*) os_strstr(pusrdata, "\r\n");
	if (pstr == NULL)
		return;
	os_memcpy(file2, pusrdata, pstr - pusrdata);
	file2[pstr - pusrdata] = 0;
	//ESP_DBG("file2=%s\r\n", file2);

	if (Sys.Status.forceupgrade == 1)
	{
		user_upgrade_begin((struct espconn *) arg, path, file1, file2);
	}
}
LOCAL void ICACHE_FLASH_ATTR user_tcpc_connect_cb(void *arg)
{
	struct espconn *pespconn = arg;
	//ESP_DBG("user_tcpc_connect_cb\r\n");
	espconn_regist_recvcb(pespconn, user_tcpc_recv_cb);
	espconn_regist_sentcb(pespconn, user_tcpc_sent_cb);
	os_timer_disarm(&hex_beat_timer);
	os_timer_setfn(&hex_beat_timer, (os_timer_func_t *) hex_beat, NULL);
	os_timer_arm(&hex_beat_timer, 500, 0);
}

LOCAL void ICACHE_FLASH_ATTR user_tcpc_recon_cb(void *arg, sint8 err)
{
	struct espconn *pespconn = (struct espconn *) arg;
	//ESP_DBG("user_tcpc_recon_cb,error=%d\r\n", err);
}
LOCAL void ICACHE_FLASH_ATTR user_tcpc_discon_cb(void *arg)
{
	//ESP_DBG("user_tcpc_discon_cb\n");
}
LOCAL void ICACHE_FLASH_ATTR user_iot_dns_found(const char *name,
		ip_addr_t *ipaddr, void *arg)
{
	struct espconn *pespconn = (struct espconn *) arg;
	if (ipaddr == NULL)
	{
		ESP_DBG("user_iot_dns_found NULL\n");
		return;
		*((u8*) &Sys.Net.iot_ip + 0) = 42;
		*((u8*) &Sys.Net.iot_ip + 1) = 159;
		*((u8*) &Sys.Net.iot_ip + 2) = 231;
		*((u8*) &Sys.Net.iot_ip + 3) = 45;
	}
	else
	{
		Sys.Net.iot_ip = *(u32*) ipaddr;
	}
	Sys.Net.Stuatus.hasiotip = 1;
	led_blue_on();
	ESP_DBG("user_iot_dns_found %d.%d.%d.%d\n", *((uint8 *) &Sys.Net.iot_ip),
			*((uint8 *) &Sys.Net.iot_ip + 1), *((uint8 *) &Sys.Net.iot_ip + 2),
			*((uint8 *) &Sys.Net.iot_ip + 3));
	udp_conn.proto.udp->remote_ip[0] = *((u8*) &Sys.Net.iot_ip + 0);
	udp_conn.proto.udp->remote_ip[1] = *((u8*) &Sys.Net.iot_ip + 1);
	udp_conn.proto.udp->remote_ip[2] = *((u8*) &Sys.Net.iot_ip + 2);
	udp_conn.proto.udp->remote_ip[3] = *((u8*) &Sys.Net.iot_ip + 3);
	ESP_DBG("�����Ϸ�������\r\n");
}
LOCAL void ICACHE_FLASH_ATTR user_hex_dns_found(const char *name,
		ip_addr_t *ipaddr, void *arg)
{
	struct espconn *pespconn = (struct espconn *) arg;
	if (ipaddr == NULL)
	{
		ESP_DBG("user_hex_dns_found NULL\n");
		return;
		*((u8*) &Sys.Net.hex_ip + 0) = 218;
		*((u8*) &Sys.Net.hex_ip + 1) = 244;
		*((u8*) &Sys.Net.hex_ip + 2) = 158;
		*((u8*) &Sys.Net.hex_ip + 3) = 15;
	}
	else
	{
		Sys.Net.hex_ip = *(u32*) ipaddr;
	}
	Sys.Net.Stuatus.hashexip = 1;
	ESP_DBG("user_hex_dns_found %d.%d.%d.%d\n", *((uint8 *) &Sys.Net.hex_ip),
			*((uint8 *) &Sys.Net.hex_ip + 1), *((uint8 *) &Sys.Net.hex_ip + 2),
			*((uint8 *) &Sys.Net.hex_ip + 3));
	pespconn->proto.tcp->remote_ip[0] = *((u8*) &Sys.Net.hex_ip + 0);
	pespconn->proto.tcp->remote_ip[1] = *((u8*) &Sys.Net.hex_ip + 1);
	pespconn->proto.tcp->remote_ip[2] = *((u8*) &Sys.Net.hex_ip + 2);
	pespconn->proto.tcp->remote_ip[3] = *((u8*) &Sys.Net.hex_ip + 3);
}
void ICACHE_FLASH_ATTR user_tcpc_sent(struct espconn *pespconn, char* pbuf)
{
	if (Sys.Net.Stuatus.tcpcsend)
		return;
	Sys.Net.Stuatus.tcpcsend = 1;
	espconn_sent(pespconn, pbuf, os_strlen(pbuf));
}
void ICACHE_FLASH_ATTR user_udp_sent(void *arg)
{
	//ESP_DBG("user_udp_sent\r\n");
}
void ICACHE_FLASH_ATTR user_udp_init(void)
{
	s8 result;
	udp_conn.type = ESPCONN_UDP;
	udp_conn.proto.udp = (esp_udp *) os_zalloc(sizeof(esp_udp));
	udp_conn.proto.udp->local_port = IOT_LOCAL_PORT;
	udp_conn.proto.udp->remote_port = IOT_PORT;
	espconn_regist_recvcb(&udp_conn, user_udp_recv);
	espconn_regist_sentcb(&udp_conn, user_udp_sent);
	result = espconn_create(&udp_conn);
	if (result == ESPCONN_OK)
	{
		ESP_DBG("espconn_create:�ɹ�\r\n");
	}
	else if (result == ESPCONN_ARG)
	{
		ESP_DBG("espconn_create:��������\r\n");
	}
	else if (result == ESPCONN_MEM)
	{
		ESP_DBG("espconn_create:�ռ䲻��\r\n");
	}
	else if (result == ESPCONN_ISCONN)
	{
		ESP_DBG("espconn_create:�����Ѿ�����\r\n");
	}
}
void ICACHE_FLASH_ATTR user_tcpc_init(void)
{
	tcp_conn.type = ESPCONN_TCP;
	tcp_conn.proto.tcp = (esp_tcp *) os_zalloc(sizeof(esp_tcp));
	tcp_conn.proto.tcp->local_port = espconn_port();
	tcp_conn.proto.tcp->remote_port = HEX_PORT;
	tcp_conn.state = ESPCONN_NONE;
	espconn_regist_connectcb(&tcp_conn, user_tcpc_connect_cb);
	espconn_regist_disconcb(&tcp_conn, user_tcpc_discon_cb);
	espconn_regist_reconcb(&tcp_conn, user_tcpc_recon_cb);
}

U32 ICACHE_FLASH_ATTR IOT_StrDataLen(U8* pucStr, U32 ulSize)
{
	U32 ulLoop = 0;
	for (ulLoop = ulSize - 1; 0 <= ulLoop; ulLoop--)
	{
		if (0 != pucStr[ulLoop])
		{
			return (1 + ulLoop);
		}
		if (0 == ulLoop)
		{
			break;
		}
	}
	return 0;
}
//��Կת�������㷨
void ICACHE_FLASH_ATTR IOT_PassPhrase_Generate(U8* pucPassword,
		U8 aucPassPhrase[20])
{
	U32 ulPwdLen = IOT_StrDataLen((S8*) pucPassword, 16);
	U32 ulPassPhraseSize = 20;
	U8* pucWork = aucPassPhrase;
	U32 ulLoop = 0;
	memset(aucPassPhrase, 0, ulPassPhraseSize);
	if (0 == ulPwdLen)
	{
		return;
	}
	//���볤�ȴ��ڵ�����Կ����
	if (ulPwdLen >= ulPassPhraseSize)
	{
		memcpy(aucPassPhrase, pucPassword, ulPassPhraseSize);
		return;
	}
	//���볤��С����Կ����
	//�ȿ�����������PWD
	for (ulLoop = 0, pucWork = aucPassPhrase;
			ulLoop < (ulPassPhraseSize / ulPwdLen); ulLoop++)
	{
		memcpy(pucWork, pucPassword, ulPwdLen);
		pucWork += ulPwdLen;
	}
	//�ٿ������µ�PWD�Ŀ�ǰ�沿��
	if (0 != (ulPassPhraseSize % ulPwdLen))
	{
		memcpy(pucWork, pucPassword, (ulPassPhraseSize % ulPwdLen));
	}
}
U16 ICACHE_FLASH_ATTR OppCalcCRC(U8* pui16_Data, U16 ui16_lenth)
{
	U8 i;
	U16 crc = 0;
	U16 lenth;
	lenth = ui16_lenth;
	while (0 < lenth)
	{
		crc = crc ^ ((U16) (*pui16_Data++) << 8);
		i = 8;
		do
		{
			if (crc & 0x8000)
			{
				crc = (crc << 1) ^ 0x1021;
			}
			else
			{
				crc <<= 1;
			}
		} while (--i);
		lenth--;
	}
	return (crc);
}
//������������
void ICACHE_FLASH_ATTR IOT_TransNetOrderToHostOrder(
		ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	//L2
	pstMsg->stSrcL2Addr.ulIP = OPP_NTOHL(pstMsg->stSrcL2Addr.ulIP);
	pstMsg->stSrcL2Addr.ulPort = OPP_NTOHL(pstMsg->stSrcL2Addr.ulPort);
	pstMsg->stDstL2Addr.ulIP = OPP_NTOHL(pstMsg->stDstL2Addr.ulIP);
	pstMsg->stDstL2Addr.ulPort = OPP_NTOHL(pstMsg->stDstL2Addr.ulPort);
	pstMsg->ulL2Type = OPP_NTOHL(pstMsg->ulL2Type);
	//L3
	pstMsg->ulL3Version = OPP_NTOHL(pstMsg->ulL3Version);
	pstMsg->ulServType = OPP_NTOHL(pstMsg->ulServType);
	pstMsg->ulDataPkgLen = OPP_NTOHL(pstMsg->ulDataPkgLen);
	pstMsg->ulL3Id = OPP_NTOHL(pstMsg->ulL3Id);
	pstMsg->ulOffset = OPP_NTOHL(pstMsg->ulOffset);
	pstMsg->ulTtl = OPP_NTOHL(pstMsg->ulTtl);
	pstMsg->ulProto = OPP_NTOHL(pstMsg->ulProto);
	pstMsg->ulL3ChkSum = OPP_NTOHL(pstMsg->ulL3ChkSum);
	pstMsg->stSrcL3Addr.enAddrType = /*(EN_IOT_MSG_L3_ADDR_TYPE)*/(OPP_NTOHL(
			pstMsg->stSrcL3Addr.enAddrType));
	pstMsg->stSrcL3Addr.stObject.enObjectType =
	/*(EN_IOT_OBJECT_TYPE)*/(OPP_NTOHL(
			pstMsg->stSrcL3Addr.stObject.enObjectType));
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0] = OPP_NTOHL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0]);
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[1] = OPP_NTOHL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[1]);
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[2] = OPP_NTOHL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[2]);
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[3] = OPP_NTOHL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[3]);
	pstMsg->stDstL3Addr.enAddrType = /*(EN_IOT_MSG_L3_ADDR_TYPE)*/(OPP_NTOHL(
			pstMsg->stDstL3Addr.enAddrType));
	pstMsg->stDstL3Addr.stObject.enObjectType =
	/*(EN_IOT_OBJECT_TYPE)*/(OPP_NTOHL(
			pstMsg->stDstL3Addr.stObject.enObjectType));
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0] = OPP_NTOHL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]);
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[1] = OPP_NTOHL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[1]);
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[2] = OPP_NTOHL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[2]);
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[3] = OPP_NTOHL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[3]);
	//App
	pstMsg->ulSrcTransNo = OPP_NTOHL(pstMsg->ulSrcTransNo);
	pstMsg->ulDstTransNo = OPP_NTOHL(pstMsg->ulDstTransNo);
	pstMsg->ulMsgLen = OPP_NTOHL(pstMsg->ulMsgLen);
	pstMsg->ulCheckSum = OPP_NTOHL(pstMsg->ulCheckSum);
	pstMsg->ulMsgType = OPP_NTOHL(pstMsg->ulMsgType);
	pstMsg->ulReserve = OPP_NTOHL(pstMsg->ulReserve);
}
//������������
void ICACHE_FLASH_ATTR IOT_TransHostOrderToNetOrder(
		ST_IOT_MSG_BASE_HEAD_MSG* pstMsg)
{
	//L2
	pstMsg->stSrcL2Addr.ulIP = OPP_HTONL(pstMsg->stSrcL2Addr.ulIP);
	pstMsg->stSrcL2Addr.ulPort = OPP_HTONL(pstMsg->stSrcL2Addr.ulPort);
	pstMsg->stDstL2Addr.ulIP = OPP_HTONL(pstMsg->stDstL2Addr.ulIP);
	pstMsg->stDstL2Addr.ulPort = OPP_HTONL(pstMsg->stDstL2Addr.ulPort);
	pstMsg->ulL2Type = OPP_HTONL(pstMsg->ulL2Type);
	//L3
	pstMsg->ulL3Version = OPP_HTONL(pstMsg->ulL3Version);
	pstMsg->ulServType = OPP_HTONL(pstMsg->ulServType);
	pstMsg->ulDataPkgLen = OPP_HTONL(pstMsg->ulDataPkgLen);
	pstMsg->ulL3Id = OPP_HTONL(pstMsg->ulL3Id);
	pstMsg->ulOffset = OPP_HTONL(pstMsg->ulOffset);
	pstMsg->ulTtl = OPP_HTONL(pstMsg->ulTtl);
	pstMsg->ulProto = OPP_HTONL(pstMsg->ulProto);
	pstMsg->ulL3ChkSum = OPP_HTONL(pstMsg->ulL3ChkSum);
	pstMsg->stSrcL3Addr.enAddrType = /*(EN_IOT_MSG_L3_ADDR_TYPE)*/(OPP_HTONL(
			pstMsg->stSrcL3Addr.enAddrType));
	pstMsg->stSrcL3Addr.stObject.enObjectType =
	/*(EN_IOT_OBJECT_TYPE)*/(OPP_HTONL(
			pstMsg->stSrcL3Addr.stObject.enObjectType));
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0] = OPP_HTONL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0]);
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[1] = OPP_HTONL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[1]);
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[2] = OPP_HTONL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[2]);
	pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[3] = OPP_HTONL(
			pstMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[3]);
	pstMsg->stDstL3Addr.enAddrType = /*(EN_IOT_MSG_L3_ADDR_TYPE)*/(OPP_HTONL(
			pstMsg->stDstL3Addr.enAddrType));
	pstMsg->stDstL3Addr.stObject.enObjectType =
	/*(EN_IOT_OBJECT_TYPE)*/(OPP_HTONL(
			pstMsg->stDstL3Addr.stObject.enObjectType));
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0] = OPP_HTONL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0]);
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[1] = OPP_HTONL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[1]);
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[2] = OPP_HTONL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[2]);
	pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[3] = OPP_HTONL(
			pstMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[3]);
	//App
	pstMsg->ulSrcTransNo = OPP_HTONL(pstMsg->ulSrcTransNo);
	pstMsg->ulDstTransNo = OPP_HTONL(pstMsg->ulDstTransNo);
	pstMsg->ulMsgLen = OPP_HTONL(pstMsg->ulMsgLen);
	pstMsg->ulCheckSum = OPP_HTONL(pstMsg->ulCheckSum);
	pstMsg->ulMsgType = OPP_HTONL(pstMsg->ulMsgType);
	pstMsg->ulReserve = OPP_HTONL(pstMsg->ulReserve);
}
//�ӽ����㷨(1):���ӽ����㷨
void ICACHE_FLASH_ATTR AlgorithmDOExclusiveOr(U8* pucStart, U32 ulDataLen,
		U8 aucPassPhrase[20])
{
	U8* pucWork = pucStart;
	U32 ulLoop = 0;
	if (NULL == pucStart)
	{
		return;
	}
	for (pucWork = pucStart, ulLoop = 0; ulLoop < ulDataLen;
			ulLoop++, pucWork++)
	{
		*pucWork ^= aucPassPhrase[ulLoop];
	}
}
void ICACHE_FLASH_ATTR AlgorithmEnDecExclusiveOr(U8* pucStart, U32 ulDataLen,
		U8 aucPassPhrase[20])
{
	U8* pucWork = pucStart;
	U32 ulDataRemain = ulDataLen;
	U32 ulCalcLen = 0;
	if (NULL == pucStart)
	{
		return;
	}
	//ESP_DBG("ulDataRemain=%d ulDataLen=%d\r\n", ulDataRemain, ulDataLen);
	for (pucWork = pucStart, ulDataRemain = ulDataLen; 0 < ulDataRemain;)
	{
		ulCalcLen =
				(20/*sizeof(aucPassPhrase)*/> ulDataRemain) ?
						ulDataRemain : 20/*sizeof(aucPassPhrase)*/;

		AlgorithmDOExclusiveOr(pucWork, ulCalcLen, aucPassPhrase);

		pucWork += ulCalcLen;
		ulDataRemain -= ulCalcLen;
	}
}
//���������
U32 ICACHE_FLASH_ATTR IOT_DECodeNetMsgToHostMsg(
		ST_IOT_MSG_BASE_HEAD_MSG* pstMsg, U32 ulOffsetStart, U32 ulOffsetEnd,
		U8 aucPassPhrase[20])
{
	U32 ulAlgorithm = 1;			//pstMsg->ulProto;
	//�ӽ����㷨(1)
	if (1 == ulAlgorithm)
	{
		//ESP_DBG("ulOffsetStart=%d ulOffsetEnd=%d \r\n", ulOffsetStart, ulOffsetEnd);
		AlgorithmEnDecExclusiveOr(((U8*) pstMsg + ulOffsetStart),
				(ulOffsetEnd - ulOffsetStart), aucPassPhrase);
	}
	//�ӽ����㷨(2)
	else if (2 == ulAlgorithm)
	{
	}
	//�����ӽ����㷨,����չ
	else
	{
	}
	return 0;
}
//���������
U32 ICACHE_FLASH_ATTR IOT_ENCodeHostMsgToNetMsg(
		ST_IOT_MSG_BASE_HEAD_MSG* pstMsg, U32 ulOffsetStart, U32 ulOffsetEnd,
		U8 aucPassPhrase[20])
{
	U32 ulAlgorithm = 1;			//pstMsg->ulProto;
	//�ӽ����㷨(1)
	if (1 == ulAlgorithm)
	{
		AlgorithmEnDecExclusiveOr(((U8*) pstMsg + ulOffsetStart),
				(ulOffsetEnd - ulOffsetStart), aucPassPhrase);
	}
	//�ӽ����㷨(2)
	else if (2 == ulAlgorithm)
	{
	}
	//�����ӽ����㷨,����չ
	else
	{
	}
	return 0;
}

void ICACHE_FLASH_ATTR IOT_CHAT_SendToObject(U32 ulSelfID, U32 ulPeerIP,
		U32 ulPeerPort, U32 ulPeerAddrType, U32 ulPeerIDType, U32 ulPeerID,
		U8* pucAppMsg, U32 ulAppMsgLen, U32 ulAppENCFlag)
{
	U8 aucMsgBuff[1024];
	ST_IOT_MSG_BASE_HEAD_MSG* pstOutMsg = (ST_IOT_MSG_BASE_HEAD_MSG*) aucMsgBuff;
	U8 aucPassPhrase[21] = "1234567890abcdfghjef";
	U8 aucOpPassPhrase[21] = "";
	u8 pass[16];
	U32 ulCheckSumCRC = 0;
	*(u32*) udp_conn.proto.udp->remote_ip = ulPeerIP;
	udp_conn.proto.udp->remote_port = ulPeerPort;
	*(u32*) udp_conn.proto.udp->local_ip = Sys.Net.ipinfo.ip.addr;
	udp_conn.proto.udp->local_port = IOT_LOCAL_PORT;
	//L2
	pstOutMsg->stSrcL2Addr.ulIP = *(u32*) udp_conn.proto.udp->local_ip;
	pstOutMsg->stSrcL2Addr.ulPort = udp_conn.proto.udp->local_port;
	pstOutMsg->stDstL2Addr.ulIP = ulPeerIP;
	pstOutMsg->stDstL2Addr.ulPort = ulPeerPort;
	pstOutMsg->ulL2Type = 0x3f2;
	//L3
	pstOutMsg->ulL3Version = 0x2775;
	pstOutMsg->ulServType = 0;
	pstOutMsg->ulDataPkgLen = IOT_MSG_L3_HEAD_LEN + ulAppMsgLen;
	pstOutMsg->ulL3Id = 1;
	pstOutMsg->ulOffset = 2;
	pstOutMsg->ulTtl = 3;
	pstOutMsg->ulProto = 4;
	pstOutMsg->ulL3ChkSum = 5;
	pstOutMsg->stSrcL3Addr.enAddrType = EN_IOT_MSG_L3_ADDR_OBJ;
	pstOutMsg->stSrcL3Addr.stObject.enObjectType = 1;
	pstOutMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[0] = ulSelfID;
	pstOutMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[1] = 0;
	pstOutMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[2] = 0;
	pstOutMsg->stSrcL3Addr.stObject.stObjectID.aulObjectID[3] = 0;
	pstOutMsg->stDstL3Addr.enAddrType = ulPeerAddrType;
	pstOutMsg->stDstL3Addr.stObject.enObjectType = ulPeerIDType;
	pstOutMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[0] = ulPeerID;
	pstOutMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[1] = 0;
	pstOutMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[2] = 0;
	pstOutMsg->stDstL3Addr.stObject.stObjectID.aulObjectID[3] = 0;
	//App
	memcpy((void*) &(pstOutMsg->ulSrcTransNo), pucAppMsg, ulAppMsgLen);
	//��Ϣͷ�ֽ���ת��
	IOT_TransHostOrderToNetOrder(pstOutMsg);
	//CRCУ�����
	pstOutMsg->ulCheckSum = OPP_HTONL(0);
	ulCheckSumCRC = OppCalcCRC((U8*) (&(pstOutMsg->ulSrcTransNo)),
			OPP_NTOHL(pstOutMsg->ulMsgLen));
	pstOutMsg->ulCheckSum = OPP_HTONL(ulCheckSumCRC);
	if (1 == ulAppENCFlag)
	{
		//APP��Ϣ��(pstOutMsg->ulReserve֮��(������)����������)����
		//��ȡ������Կ
		if (memcmp(Sys.Config.aucOpPwd, Sys.Net.stamac, 6) == 0)
		{
			os_memset(pass, 0, 16);
			os_memcpy(pass, Sys.Net.stamac, 6);
			//pass[7] = Sys.Config.Device[find_dev_by_id(ulSelfID)].sn;
			//ESP_DBG("��Կ=");
			//print_buffer(pass, 16);
		}
		else
		{
			memcpy(pass, Sys.Config.aucOpPwd, 16);
		}
		IOT_PassPhrase_Generate(pass, aucOpPassPhrase);
		//print_buffer(pass, 16);
		//print_buffer(aucOpPassPhrase, 20);
		//print_buffer(pstOutMsg, 124 + ulAppMsgLen);
		//APP��Ϣ�����
		IOT_ENCodeHostMsgToNetMsg(pstOutMsg,
				OffsetOfNext(ST_IOT_MSG_BASE_HEAD_MSG, ulReserve),
				(OffsetOfNext(ST_IOT_MSG_BASE_HEAD_MSG, ulReserve)
						+ (OPP_NTOHL(pstOutMsg->ulMsgLen)
								- IOT_MSG_BASE_HEAD_LEN)), aucOpPassPhrase);
		//print_buffer(pstOutMsg, 124 + ulAppMsgLen);
	}
	if ((Sys.Net.iot_ip == ulPeerIP) && (IOT_PORT == ulPeerPort))
	{
		//����IOT������ƽ̨ϵͳ��,������Ϣͷ����β��
		//����
		IOT_ENCodeHostMsgToNetMsg(pstOutMsg,
				OffsetOf(ST_IOT_MSG_BASE_HEAD_MSG, ulSrcTransNo),
				OffsetOfNext(ST_IOT_MSG_BASE_HEAD_MSG, ulReserve),
				aucPassPhrase);
	}
	//ESP_DBG(
	//		"selfip=%08x port=%d,selfid=%d,peerip=%08x,port=%d,peeridtype=%d,peerid=%d,len=%d,flag=%d\r\n",
	//		*(u32*) udp_conn.proto.udp->local_ip,
	//		udp_conn.proto.udp->local_port, ulSelfID, ulPeerIP, ulPeerPort,
	//		ulPeerIDType, ulPeerID, ulAppMsgLen, ulAppENCFlag);
	s8 result;
	result = espconn_sendto(&udp_conn, (u8*) pstOutMsg,
			(IOT_MSG_L2_HEAD_LEN + OPP_NTOHL(pstOutMsg->ulDataPkgLen)));
	if (result == ESPCONN_OK)
	{
		//ESP_DBG("espconn_send:�ɹ�\r\n");
	}
	else if (result == ESPCONN_ARG)
	{
		ESP_DBG("espconn_send:��������\r\n");
	}
	else if (result == ESPCONN_MEM)
	{
		ESP_DBG("espconn_send:�ռ䲻��\r\n");
	}
	else if (result == ESPCONN_MAXNUM)
	{
		ESP_DBG("espconn_send:�ײ㷢����������������ʧ��\r\n");
	}
	else if (result == ESPCONN_IF)
	{
		ESP_DBG("espconn_send:����ʧ��\r\n");
	}
}
u8 ICACHE_FLASH_ATTR check_nid_ready(void)
{
	u8 i;
	for (i = 0; i < MAX_DEVICE; i++)
	{
		if (Sys.Config.Device[i].nid == 0 || Sys.Config.Device[i].fakeid == 1)
		{
			if (i == 0 || Sys.Config.Device[i].sn != 0)
			{
				return 0;
			}
		}
	}
	return 1;
}
void ICACHE_FLASH_ATTR iot_beat(void)
{
	u8 i;
	static u8 devn = 0;
	if (Sys.Net.Stuatus.hasip && Sys.Net.Stuatus.hasiotip)
	{
		ST_IOT_CHAT_SHKHAND_REQ_MSG stObjMsg;
		stObjMsg.ulSrcTransNo = 0;
		stObjMsg.ulDstTransNo = 0;
		stObjMsg.ulMsgLen = IOT_MSG_BASE_HEAD_LEN
				+ sizeof(stObjMsg.aucPhyObjID);
		stObjMsg.ulCheckSum = 0;
		stObjMsg.ulMsgType = IOT_SHKHAND_REQ;
		stObjMsg.ulReserve = 0;
		os_memcpy(Sys.Net.selfSN, Sys.Net.stamac, 6);
		Sys.Net.selfSN[6] = 0;
		Sys.Net.selfSN[7] = Sys.Config.Device[devn].sn;
		Sys.Net.selfSN[8] = 0;
		Sys.Net.selfSN[9] = 0;
		os_memcpy(stObjMsg.aucPhyObjID, Sys.Net.selfSN, sizeof(Sys.Net.selfSN));
		Sys.Net.selfID = Sys.Config.Device[devn].nid;
		IOT_CHAT_SendToObject(Sys.Net.selfID, Sys.Net.iot_ip, IOT_PORT,
				EN_IOT_MSG_L3_ADDR_DEAL, 1, Sys.Net.selfID, (U8*) (&stObjMsg),
				stObjMsg.ulMsgLen, 0);
		ESP_DBG("iot_beat:dev[%d]:nid=%d,sn=%d,sku=%x\r\n", devn,
				Sys.Config.Device[devn].nid, Sys.Config.Device[devn].sn,
				Sys.Config.Device[devn].sku);

		devn++;										// next device
		for (i = devn; i < MAX_DEVICE; i++)			// jump over empty device
		{
			if (Sys.Config.Device[i].sn == 0)
			{
				devn++;
			}
			else
			{
				break;
			}
		}
		if (Sys.idready == 0)						// if all ready,change speed
		{
			Sys.idbeatcout++;
			if (check_nid_ready() || Sys.idbeatcout > 600)
			{
				Sys.idready = 1;
				ESP_DBG("iot_beat:check_id_ready\r\n");
				display_devices();
				os_timer_disarm(&iot_beat_timer);
				os_timer_setfn(&iot_beat_timer, (os_timer_func_t *) iot_beat,
				NULL);
				os_timer_arm(&iot_beat_timer, BEAT_TIME_IOT, 1);
				//config_ram2flash();
			}
		}
		if (devn >= MAX_DEVICE)						// make sure devn correct
		{
			devn = 0;
		}
	}
}
void ICACHE_FLASH_ATTR hex_beat(void)
{
	if (tcp_conn.state == ESPCONN_CONNECT)
	{
		char pbuf[1024] =
		{ 0 };
		char fwv[6];
		os_sprintf(fwv, "%d.%d", IOT_VERSION_MAJOR, IOT_VERSION_MINOR);
		char hid[13];
		os_sprintf(hid, "%02X%02X%02X%02X%02X%02X", Sys.Net.stamac[0],
				Sys.Net.stamac[1], Sys.Net.stamac[2], Sys.Net.stamac[3],
				Sys.Net.stamac[4], Sys.Net.stamac[5]);
		os_sprintf(pbuf,
				"GET /upgrade/query?hdv=%s&fwv=%s&hid=%s&model=%s HTTP/1.0\r\nHost: %s:%d\r\n"queryhead,
				DEVICE_HDV, fwv, hid, DEVICE_TYPE,
				HEX_DOMAIN,
				HEX_PORT);
		//ESP_DBG(pbuf);
		ESP_DBG("��ѯ�ƶ˹̼�\r\n");
		user_tcpc_sent(&tcp_conn, pbuf);
	}
	else
	{
		espconn_connect(&tcp_conn);
	}
	os_timer_disarm(&hex_beat_timer);
	os_timer_setfn(&hex_beat_timer, (os_timer_func_t *) hex_beat, NULL);
	os_timer_arm(&hex_beat_timer, BEAT_TIME_HEX, 0);
}

void ICACHE_FLASH_ATTR user_check(void)
{
	wifi_get_ip_info(STATION_IF, &Sys.Net.ipinfo);
	if (wifi_station_get_connect_status() == STATION_GOT_IP
			&& Sys.Net.ipinfo.ip.addr != 0)
	{
		if (Sys.Net.Stuatus.hasip == 0)
		{
			Sys.Net.Stuatus.hasip = 1;
			ESP_DBG("������·������\r\n");
		}
		if (Sys.Net.Stuatus.hasiotip == 0)
		{
			espconn_gethostbyname(&udp_conn, IOT_DOMAIN,
					(ip_addr_t*) &Sys.Net.iot_ip, user_iot_dns_found);
		}
		if (Sys.Net.Stuatus.hashexip == 0)
		{
			espconn_gethostbyname(&tcp_conn, HEX_DOMAIN,
					(ip_addr_t*) &Sys.Net.hex_ip, user_hex_dns_found);
		}
	}
	else
	{
		if (Sys.Net.Stuatus.hasip == 1)
		{
			Sys.Net.Stuatus.hasip = 0;
			Sys.Net.Stuatus.hasiotip = 0;
			Sys.Net.Stuatus.hashexip = 0;
			ESP_DBG("LOST_IP\r\n");
		}
	}
}

