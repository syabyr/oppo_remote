#include "include.h"

u8 mdayn[12] =
{ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
char* wdays[7] =
{ "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
char* months[12] =
{ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
		"Dec" };

struct tm ICACHE_FLASH_ATTR user_strtime2tm(char *strtime)
{
	u8 i;
	struct tm tm;
	char buf[5];
	for (i = 0; i < 7; i++)
	{
		if (strncmp(strtime, wdays[i], 3) == 0)
		{
			tm.tm_wday = i;
			break;
		}
	}
	strtime += 4;
	for (i = 0; i < 12; i++)
	{
		if (strncmp(strtime, months[i], 3) == 0)
		{
			tm.tm_mon = i;
			break;
		}
	}
	strtime += 4;
	memcpy(buf, strtime, 2);
	buf[2] = 0;
	tm.tm_mday = atoi(buf);
	strtime += 3;
	memcpy(buf, strtime, 2);
	buf[2] = 0;
	tm.tm_hour = atoi(buf);
	strtime += 3;
	memcpy(buf, strtime, 2);
	buf[2] = 0;
	tm.tm_min = atoi(buf);
	strtime += 3;
	memcpy(buf, strtime, 2);
	buf[2] = 0;
	tm.tm_sec = atoi(buf);
	strtime += 3;
	memcpy(buf, strtime, 4);
	buf[4] = 0;
	tm.tm_year = atoi(buf);
	return tm;
}
void ICACHE_FLASH_ATTR net_set_time(void)
{
	// if it is a valie time
	if (Sys.Time.timestamp > 1433513952)
	{
		time_t timer;
		struct tm tm;
		tm = user_strtime2tm((char*) sntp_get_real_time(Sys.Time.timestamp));
		//ESP_DBG(
		//		"year=%d month=%d mday=%d wday=%d hour=%d minute=%d second=%d\r\n",
		//		tm.tm_year, tm.tm_mon + 1, tm.tm_mday, tm.tm_wday,
		//		tm.tm_hour, tm.tm_min, tm.tm_sec);
		timer = system_mktime(Sys.Time.rtc.uwYear, Sys.Time.rtc.ucMon + 1,
				Sys.Time.rtc.ucDay, Sys.Time.rtc.ucHour, Sys.Time.rtc.ucMin,
				Sys.Time.rtc.ucSec);
		if (Sys.Time.rtc.uwYear < 2015)
		{
			Sys.Time.rtc.uwYear = tm.tm_year;
			Sys.Time.rtc.ucMon = tm.tm_mon;
			Sys.Time.rtc.ucDay = tm.tm_mday;
			Sys.Time.rtc.ucWDay = tm.tm_wday;
			Sys.Time.rtc.ucHour = tm.tm_hour;
			Sys.Time.rtc.ucMin = tm.tm_min;
			Sys.Time.rtc.ucSec = tm.tm_sec;
			ESP_DBG("��һ�θ���ʱ��\r\n");
			ESP_DBG("timer: %d, %s %s \r\n", timer, wdays[Sys.Time.rtc.ucWDay],
					months[Sys.Time.rtc.ucMon]);
			ESP_DBG("sntp : %d, %s\r\n", Sys.Time.timestamp,
					sntp_get_real_time(Sys.Time.timestamp));
		}
		if (tm.tm_hour == 4 && tm.tm_min == 0)
		{
			Sys.Time.rtc.uwYear = tm.tm_year;
			Sys.Time.rtc.ucMon = tm.tm_mon;
			Sys.Time.rtc.ucDay = tm.tm_mday;
			Sys.Time.rtc.ucWDay = tm.tm_wday;
			Sys.Time.rtc.ucHour = tm.tm_hour;
			Sys.Time.rtc.ucMin = tm.tm_min;
			Sys.Time.rtc.ucSec = tm.tm_sec;
			ESP_DBG("��Ҫ����ʱ��\r\n");
			ESP_DBG("timer: %d, %s %s \r\n", timer, wdays[Sys.Time.rtc.ucWDay],
					months[Sys.Time.rtc.ucMon]);
			ESP_DBG("sntp : %d, %s\r\n", Sys.Time.timestamp,
					sntp_get_real_time(Sys.Time.timestamp));
		}
	}
}
void ICACHE_FLASH_ATTR get_time(void)
{
	u8 i, j;
	Sys.Time.rtc.ucSec++;
	if (Sys.Time.rtc.ucSec > 59)
	{
		Sys.Time.rtc.ucSec = 0;
		Sys.Time.rtc.ucMin++;
		if (Sys.Time.rtc.ucMin > 59)
		{
			Sys.Time.rtc.ucMin = 0;
			if (++Sys.Time.rtc.ucHour > 23)
			{
				Sys.Time.rtc.ucHour = 0;
				if (Sys.Time.rtc.uwYear % 400 == 0
						|| (Sys.Time.rtc.uwYear % 100 != 0
								&& Sys.Time.rtc.uwYear % 4 == 0))
				{
					mdayn[1] = 29;
				}
				else
				{
					mdayn[1] = 28;
				}
				Sys.Time.rtc.ucDay++;
				if (Sys.Time.rtc.ucDay >= mdayn[Sys.Time.rtc.ucMon])
				{
					Sys.Time.rtc.ucDay = 0;
					if (++Sys.Time.rtc.ucMon > 11)
					{
						Sys.Time.rtc.ucMon = 0;
						Sys.Time.rtc.uwYear++;
					}
				}
				if (++Sys.Time.rtc.ucWDay > 6)
				{
					Sys.Time.rtc.ucWDay = 0;
				}
			}
		}
	}
	time_t rtc_stamp = system_mktime(Sys.Time.rtc.uwYear,
			Sys.Time.rtc.ucMon + 1, Sys.Time.rtc.ucDay, Sys.Time.rtc.ucHour,
			Sys.Time.rtc.ucMin, Sys.Time.rtc.ucSec);
	for (i = 1; i < MAX_DEVICE; i++)
	{
		for (j = 0; j < MAX_TIMER; j++)
		{
			if (rtc_stamp > (Sys.DTimer[i].Timer[j].excutestamp + 20))
			{
				Sys.DTimer[i].Timer[j].excutestamp = 0;
			}
		}
	}
	if (Sys.debug)
	{
		ESP_DBG("rtc time : %02d:%02d:%02d %d/%d/%d\r\n", Sys.Time.rtc.ucHour,
				Sys.Time.rtc.ucMin, Sys.Time.rtc.ucSec, Sys.Time.rtc.uwYear,
				Sys.Time.rtc.ucMon + 1, Sys.Time.rtc.ucDay);
	}
}
