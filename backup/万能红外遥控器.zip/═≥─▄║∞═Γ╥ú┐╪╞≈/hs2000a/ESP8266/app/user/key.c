#include "include.h"

LOCAL ETSTimer timer_key;
LOCAL unsigned char key_status = 0;
LOCAL unsigned int key_press_time = 0;
u8 bufff[2048] =
{ 0x06, 0x68, 0x00, 0x38, 0x4a, 0x02, 0x16, 0x00, 0x00, 0x5b, 0x00, 0xab, 0xab,
		0xcd, 0x29, 0x2f, 0x2b, 0x49, 0xf1, 0x09, 0x89, 0x1e, 0x41, 0x8d, 0x47,
		0x8f, 0x45, 0xbc, 0x3c, 0xbe, 0x3e, 0xb8, 0x38, 0xb5, 0xba, 0x97, 0x17,
		0x95, 0xea, 0x13, 0xd9, 0x11, 0xdb, 0x48, 0x82, 0x36, 0x4a, 0xcc, 0x4c,
		0xce, 0x4e, 0x14, 0x5d, 0x96, 0x16, 0x90, 0x5a, 0x92, 0x12, 0xff, 0x35,
		0xfd, 0x37, 0xfb, 0x00, 0x79, 0xf9, 0x22, 0xa2, 0xd6, 0x20, 0xa6, 0x26,
		0xa4, 0x24, 0x74, 0xbe, 0x76, 0xf6, 0x70, 0xaf, 0xf2, 0x72, 0xc7, 0x0d,
		0x65, 0xc5, 0x09, 0xc3, 0x0b, 0xc1, 0xc7, 0x1b, 0x19, 0x19, 0x1f, 0x1f,
		0x36, 0x1d, 0x48, 0x48, 0x4a, 0x72, 0x4c, 0x4c, 0x4e, 0x4e, 0x0c, 0x0c,
		0x9d, 0x0e, 0x08, 0x08, 0x0a, 0x22 };
u8 buuf[2048];
LOCAL void ICACHE_FLASH_ATTR sleep_dont_wakeup(void)
{
	system_deep_sleep(0);
	wifi_station_disconnect();
	wifi_set_opmode(NULL_MODE);
	wifi_fpm_set_sleep_type(MODEM_SLEEP_T);
	wifi_fpm_open();
	wifi_fpm_do_sleep(0xFFFFFFF);
	ESP_DBG("WIFI���ܹر�,��оƬ�������ģʽ�������Զ����ѣ����������ϵ�����л�RFƵ��\r\n");
}
LOCAL void ICACHE_FLASH_ATTR key_prog(void)
{
	if (key_status)
	{
		if (key_status == 1)
		{
			ESP_DBG("click 1 times\r\n");
			if (Sys.Rftestfactory)
			{
				u8 buf[4];
				ESP_DBG("����һ�����߲����źţ�2.4G  315  433...\r\n");
				usart_cmd_send24g2(RF_CMD_FactTest, NULL, 0);
				os_delay_us(10000);
				os_delay_us(1000000);

				buf[0] = 'h';
				buf[1] = 's';
				buf[2] = 'd';
				usart_cmd_send415(USART_CMD_SEND_315, 0x01, buf, 3);
				os_delay_us(10000);
				os_delay_us(1000000);

				buf[0] = 'h';
				buf[1] = 's';
				buf[2] = 'd';
				usart_cmd_send415(USART_CMD_SEND_433, 0x01, buf, 3);
				os_delay_us(10000);
				os_delay_us(1000000);
			}
			else if (Sys.RFtest)
			{
				ESP_DBG("RF24G ��������...\r\n");
				usart_cmd_rftest(USART_CMD_TEST_24G);
				sleep_dont_wakeup();
			}
			else
			{
				ESP_DBG("free heap size = %d\r\n", system_get_free_heap_size());
				display_devices();
				led_green_on();
				memcpy(buuf, bufff, 2048);
				IR_Sent_Start(&buuf[1], &buuf[9]);
				ESP_DBG("ir send by gateway ir test\r\n");
				led_green_off();
			}
			//user_iot_sent(Sys.Config.Device[0].nid, 0, 5, Sys.Net.iot_ip,
			//IOT_PORT, IOT_CHAT_CONTENT, "��������", strlen("��������"), 0);
			//user_iot_sent(Sys.Config.Device[0].nid, 0, 8, Sys.Net.iot_ip,
			//IOT_PORT, IOT_CHAT_CONTENT, "hello every test",
			//		strlen("hello every test"), 0);
			//srand(system_get_time());
			//ESP_DBG("rand = %08x\r\n\r\n\r\n",rand());
			//ir_learn_start(5);
			//u8 i, j;
			//for (i = 1; i < MAX_DEVICE; i++)
			//{
			//	for (j = 0; j < MAX_TIMER; j++)
			//	{
			//		Sys.Config.Device[i].Timer[j].Hour = Sys.Time.rtc.ucHour;
			//		Sys.Config.Device[i].Timer[j].Minute = Sys.Time.rtc.ucMin
			//				+ 1;
			//	}
			//}
			//led_green_on();
			//Sys.Status.study = 1;
			//Sys.Status.study_type = STUDY_REPT;
			//tv_ctrl(MAX_REPEATER, NULL);
		}
		else if (key_status == 2)
		{
			ESP_DBG("click 2 times\r\n");
			if (Sys.RFtest)
			{
				ESP_DBG("RF315 ��������...\r\n");
				usart_cmd_rftest(USART_CMD_TEST_315);
				sleep_dont_wakeup();
			}
			else
			{
				Sys.debug = 0;
				Sys.facttest = 2;
				//usart_cmd_send24g2(RF_CMD_FactTest, NULL, 0);
				//os_delay_us(10000);
				//ir_learn_start(0);
				//Sys.Status.study = 1;
			}
		}
		else if (key_status == 3)
		{
			ESP_DBG("click 3 times\r\n");
			if (Sys.RFtest)
			{
				ESP_DBG("RF433 ��������...\r\n");
				usart_cmd_rftest(USART_CMD_TEST_433);
				sleep_dont_wakeup();
			}
			else
			{
				Sys.debug = 1;
			}
		}
		else if (key_status == 4)
		{
			ESP_DBG("click 4 times\r\n");
			if (Sys.RFtest)
			{
				Sys.RFtest = 0;
				ESP_DBG("���볧��ģʽ������\r\n");
				Sys.Rftestfactory = 1;
			}
			else
			{
				Sys.Status.forceupgrade = 1;
				hex_beat();
			}
		}
		else if (key_status == 5)
		{
			ESP_DBG("click 5 times\r\n");
			mcu_boot();
		}
		else if (key_status == 7)
		{
			ESP_DBG("click 7 times\r\n");
			if (Sys.RFtest == 0)
			{
				ESP_DBG("...�������ģʽ...\r\n");
				Sys.RFtest = 1;
			}
			else
			{
				ESP_DBG("...�˳�����ģʽ...\r\n");
				Sys.RFtest = 0;
			}
		}
		else if (key_status == 8)
		{
			ESP_DBG("click 8 times\r\n");
			retry_smartconfig();
		}
		else if (key_status == LONG_PRESS_KEEP)
		{
			if (key_press_time > press_time_max) 		//7s
			{
				ESP_DBG("set key long pressed 10 seconds\r\n");
				led_blue_toggle();
				led_green_on();
			}
			else if (key_press_time > press_time_min)	//5s
			{
			}
		}
		else if (key_status == LONG_PRESS_RELEASE)
		{
			if (key_press_time > press_time_max)
			{
				ESP_DBG("set key long released 10 seconds\r\n");
				sys_factory_reset();
			}
			else if (key_press_time > press_time_min)
			{
			}
			key_press_time = 0;
		}
		key_status = 0;
	}
}

LOCAL void ICACHE_FLASH_ATTR key_service(void)
{
	static unsigned char key_release_time = 0;
	static unsigned char key_click = 0;
	static unsigned char Continue = 0;
	unsigned char ReadData = 0;
	unsigned char Release;
	unsigned char Trigger;
	if (!GPIO_INPUT_GET(KEY_IO_NUM))
	{
		ReadData = 1;
	}
	Trigger = ReadData & (ReadData ^ Continue);
	Release = (ReadData ^ Trigger ^ Continue);
	Continue = ReadData;
	if (Trigger)
		key_press_time = 0; //	�������ͷ�ʱ����
	if (Continue)
	{
		if (key_press_time++ > press_time_min)
		{
			key_status = LONG_PRESS_KEEP; // ��������
		}
	}
	if (Release)
	{
		if ((key_press_time > click_time_min)
				&& (key_press_time <= click_time_max)) // �̰�����, ����30ms��500ms
		{
			key_click++;
		}
		else if ((key_press_time > click_time_max)
				&& (key_press_time <= press_time_min))
		{
			key_click = 0;
		}
		else if (key_press_time > press_time_min) // �����ͷ�
		{
			key_status = LONG_PRESS_RELEASE;
		}
		key_release_time = 0;
	}
	if (key_release_time++ > click_time_max)
	{
		if (key_click)
		{
			key_status = key_click;
			key_click = 0;
		}
	}
	key_prog();
}

void ICACHE_FLASH_ATTR key_init(void)
{
	PIN_FUNC_SELECT(KEY_IO_MUX, KEY_IO_FUNC);
	GPIO_DIS_OUTPUT(KEY_IO_NUM);
	PIN_PULLUP_EN(KEY_IO_MUX);
	os_timer_disarm(&timer_key);
	os_timer_setfn(&timer_key, (ETSTimerFunc *) key_service, NULL);
	os_timer_arm(&timer_key, 10, true);
}

