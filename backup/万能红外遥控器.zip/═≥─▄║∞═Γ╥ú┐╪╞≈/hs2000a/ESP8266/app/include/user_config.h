#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#define	CONFIG_ADDR		0x200000
#define	STUDY_ADDR		0x208000

#define RST_IO_NUM		13
#define	RST_IO_MUX		PERIPHS_IO_MUX_MTCK_U
#define	RST_IO_FUNC		FUNC_GPIO13
#define BOOT_IO_NUM		5
#define	BOOT_IO_MUX		PERIPHS_IO_MUX_GPIO5_U
#define	BOOT_IO_FUNC	FUNC_GPIO5
#define	LED1_IO_NUM		0
#define	LED1_IO_MUX		PERIPHS_IO_MUX_GPIO0_U
#define	LED1_IO_FUNC	FUNC_GPIO0
#define	LED2_IO_NUM		15
#define	LED2_IO_MUX		PERIPHS_IO_MUX_MTDO_U
#define	LED2_IO_FUNC	FUNC_GPIO15
#define	KEY_IO_NUM		4
#define	KEY_IO_MUX		PERIPHS_IO_MUX_GPIO4_U
#define	KEY_IO_FUNC		FUNC_GPIO4
#define	IRIN_IO_NUM		12
#define	IRIN_IO_MUX		PERIPHS_IO_MUX_MTDI_U
#define	IRIN_IO_FUNC	FUNC_GPIO12

#define	BEAT_TIME_HEX	600000
#define	BEAT_TIME_IOT	20000
#define	BEAT_TIME_IOT_F	500

#define TESTSSID		"HS-TEST-PROD"
#define TESTPASS		"huashengtest"

#define HEX_DOMAIN      "qiaohui.me"
#define HEX_PORT		8081
#define IOT_DOMAIN		"iotctrl.opple.com"
#define IOT_PORT		65501
#define IOT_LOCAL_PORT	55001

#define MAX_TRANSNO		10
#define	NAME_LEN		16
#define	MAX_DEVICE		50					// include gateway
#define	MAX_STUDY		100
#define	MAX_REPEATER	5
#define	MAX_SCENE		10
#define	MAX_TIMER		2
#define STUDY_DAT_LEN	1000

#define IOT_VERSION_MAJOR		1U
#define IOT_VERSION_MINOR		1U

#define	IOT_MCU_VERSION			0x02
#define DEVICE_TYPE       		"2000A"
#define	DEVICE_HDV		  		"1.0"

#define queryhead "\
User-Agent: 2000A\r\n\
X-Token: 234\r\n\r\n"
#define upgradehd "\
Connection: keep-alive\r\n\
Cache-Control: no-cache\r\n\
User-Agent: Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36 \r\n\
Accept: */*\r\n\
Accept-Encoding: gzip,deflate,sdch\r\n\
Accept-Language: zh-CN,zh;q=0.8\r\n\r\n"

#define ESP_DEBUG
#ifdef	ESP_DEBUG
#define ESP_DBG os_printf
#else
#define ESP_DBG
#endif

#define VERSION_NUM   (IOT_VERSION_MAJOR * 1000 + IOT_VERSION_MINOR * 100 + IOT_VERSION_REVISION)
#define VERSION_TYPE      "v"

#define ONLINE_UPGRADE    0
#define LOCAL_UPGRADE     0
#define ALL_UPGRADE       1
#define NONE_UPGRADE      0

#if	ONLINE_UPGRADE
#define UPGRADE_FALG	"O"
#elif  LOCAL_UPGRADE
#define UPGRADE_FALG	"l"
#elif  ALL_UPGRADE
#define UPGRADE_FALG	"a"
#elif NONE_UPGRADE
#define UPGRADE_FALG	"n"
#endif

#endif

