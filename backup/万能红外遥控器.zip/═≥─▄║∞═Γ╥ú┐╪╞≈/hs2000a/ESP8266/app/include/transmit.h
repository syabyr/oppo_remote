#ifndef	_TRANSMIT_H_
#define	_TRANSMIT_H_

void ICACHE_FLASH_ATTR air_udp_recv(void *arg, char *data, unsigned short len);
void ICACHE_FLASH_ATTR user_udp_recv(void *arg, char *data, unsigned short len);
void ICACHE_FLASH_ATTR user_iot_sent(U32 ulSelfID, U32 IDType, u32 targetID,U32 ulPeerIP, U32 ulPeerPort, u32 ulMsgType, char* pbuf, u32 len,U32 ulAppENCFlag);

#endif
