#ifndef __USER_INCLUDE_H__
#define __USER_INCLUDE_H__

#include "math.h"
#include "time.h"
#include "ets_sys.h"
#include "c_types.h"
#include "os_type.h"
#include "mem.h"
#include "osapi.h"
#include "smartconfig.h"
#include "gpio.h"
#include "driver/uart.h"
#include "upgrade.h"

#include "user_interface.h"

#include "Opp_Std.h"
#include "define.h"
#include "key.h"
#include "espconn.h"
#include "transmit.h"
#include "IOT_Msg.h"

#include "Opp_Msg.h"

extern struct espconn udp_conn;
extern struct espconn tcp_conn;
extern os_timer_t iot_beat_timer;
extern os_timer_t hex_beat_timer;
extern os_timer_t ir_learn_timer;

void ICACHE_FLASH_ATTR smartconfig_done(sc_status status, void *pdata);
void ICACHE_FLASH_ATTR iot_beat(void);
void ICACHE_FLASH_ATTR hex_beat(void);
void ICACHE_FLASH_ATTR user_check(void);
void ICACHE_FLASH_ATTR usart_rx(void);
#endif

