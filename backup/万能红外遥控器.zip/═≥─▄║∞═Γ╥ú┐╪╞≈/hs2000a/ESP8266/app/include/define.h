#ifndef	_USER_DEFINE_H_
#define	_USER_DEFINE_H_

#define SYS_CPU_80MHz	80
#define	SYS_CPU_160MHz	160

#define IOT_CHAT_CONTENT			0x12700AEE
#define IOT_MESSAGE					0x12700ADD
#define IOT_SEARCH_RSP				0x12700ADE
#define IOT_SHKHAND_REQ				0x12789AEE
#define IOT_SHKHAND_ACK				0x12789AEF
#define IOT_SHKHAND_REQ_EX			0x12789AF0
#define IOT_SHKHAND_ACK_EX			0x12789AF1
#define IOT_UPDATE_HOST_IND			0x12789AFE
#define IOT_APP_FIND_REQ			0x02010000
#define IOT_APP_FIND_RSP			0x02020000
#define IOT_PASS_CHANGE_REQ			0x02030000
#define IOT_PASS_CHANGE_RSP			0x02040000
#define IOT_DEV_MOD_REQ				0x02050000
#define IOT_DEV_MOD_RSP				0x02060000
#define IOT_DEV_RESTORE_REQ			0x02070000
#define IOT_DEV_RESTORE_RSP			0x02080000
#define IOT_APP_OTA_REQ				0x020B0000
#define IOT_APP_OTA_RSP				0x020C0000
#define IOT_SCENE_CHECK_REQ			0x03070000
#define IOT_SCENE_CHECK_RSP			0x03080000
#define IOT_SCENE_SET_REQ			0x03090000
#define IOT_SCENE_SET_RSP			0x030A0000
#define IOT_SCENE_CAL_REQ			0x030D0000
#define IOT_SCENE_CAL_RSP			0x030E0000
#define IOT_DEV_CHECK_REQ			0x030F0000
#define IOT_DEV_CHECK_RSP			0x03100000
#define IOT_DEV_ONOFF_REQ			0x03110000
#define IOT_DEV_RGB_REQ				0x03170000
#define IOT_TIMER_CHECK_REQ			0x04010000
#define IOT_TIMER_CHECK_RSP			0x04020000
#define IOT_TIMER_SET_REQ			0x04030000
#define IOT_TIMER_SET_RSP			0x04040000
#define IOT_RSSI_CHECK_REQ			0x81050000
#define IOT_RSSI_CHECK_RSP			0x81060000

#define IOT_USER_ADD_DEVICE			0x01
#define IOT_USER_BUTTON_ADD			0x02
#define IOT_USER_BUTTON_MOD			0x04

#define IOT_USER_IR_SEND			0x06
#define IOT_USER_IR_STUDY			0x07
#define IOT_USER_IR_STUDY_RSP		0x08
#define IOT_USER_DEV_CTL			0x09
#define IOT_USER_DEL_DEVICE			0x0a
#define IOT_USER_DEL_DEVICE_RSP		0x0b
#define IOT_USER_REMOTEID_REQ		0x0c
#define IOT_USER_REMOTEID_RSP		0x0d
#define	IOT_USER_BUTTON_REQ			0x0e
#define	IOT_USER_BUTTON_RSP			0x0f
#define IOT_USER_OTA_CHECK			0x10
#define IOT_USER_OTA_CHECK_RSP		0x11
#define IOT_USER_OTA_START			0x12
#define IOT_USER_OTA_START_RSP		0x13
#define IOT_USER_MAC_LIST_REQ		0x14
#define IOT_USER_MAC_LIST_RSQ		0x15
#define IOT_USER_FIND_DEV_RSQ		0x17
#define IOT_USER_ADD_DEV_RSQ		0x18

#define IOT_USER_SCENE_DEL_REQ		0x80
#define IOT_USER_SCENE_DEL_RSP		0x81
#define IOT_USER_DEV_SYNC_REQ		0x82
#define IOT_USER_SCENE_STUDY_REQ	0x84
#define IOT_USER_SCENE_ACSTUDY_REQ	0x85

#define PRODUCT_SKU_LVC2000A		0x0101
#define PRODUCT_SKU_24G1			0x0103
#define PRODUCT_SKU_AC				0x0104
#define PRODUCT_SKU_TV				0x0105
#define PRODUCT_SKU_XM				0x010a
#define PRODUCT_SKU_LS				0x010c
#define PRODUCT_SKU_USER1			0x010d
#define PRODUCT_SKU_USER2			0x010e
#define PRODUCT_SKU_USER3			0x010f

#define PRODUCT_TYPE_433			0x01
#define PRODUCT_TYPE_315			0x02
#define PRODUCT_TYPE_IR				0x03
#define PRODUCT_TYPE_USER			0x04

#define STUDY_TIMEOUT				15

#define STUDY_24G					0x01
#define STUDY_USER					0x02
#define STUDY_REPT					0x03
#define STUDY_IR					0x04

//OPPLE������(ʧ����/ԭ����)����
typedef enum
{
	OPP_SUCCESS = 0, OPP_FAILURE, OPP_OVERFLOW, OPP_NO_PRIVILEGE, OPP_EXISTED,
	//����������չ
	OPP_UNKNOWN
} OPP_ERROR_CODE;
/*OPPLEʱ�����Ͷ���*/
typedef struct
{
	U16 uwYear; /*���(��: 2013)*/
	U8 ucMon; /*�·�(1~12)*/
	U8 ucDay; /*����(1~31)*/
	U8 ucWDay; /*���ڼ�(1~7)*/
	U8 ucHour; /*ʱ(0~23)*/
	U8 ucMin; /*��(0~59)*/
	U8 ucSec; /*��(0~59)*/
} ST_OPPLE_TIME;
typedef struct _STA_CONF_
{
	uint8 ssid[32];
	uint8 password[64];
	uint8 bssid_set; // Note: If bssid_set is 1, station will just connect to the router
	uint8 bssid[6];
	uint8 dumm;
} STA_CONF;

#define USART_CMD_ACK				0x02
#define	USART_CMD_SEND_24G			0x03
#define	USART_CMD_GET_VERSION		0x04
#define	USART_CMD_REPORT_VERSION	0x05
#define	USART_CMD_GET_24G			0x06
#define	USART_CMD_GET_868			0x07
#define	USART_CMD_SEND_868			0x08
#define USART_CMD_GET_433			0x09
#define USART_CMD_SEND_433			0x0a
#define USART_CMD_GET_315			0x0b
#define USART_CMD_SEND_315			0x0c
#define USART_CMD_TEST_315			0x0d
#define USART_CMD_TEST_433			0x0e
#define USART_CMD_TEST_24G			0x0f
#define	USART_CMD_DIS_USART			0xfe

#define	RF_CMD_IR_SEND				0x01
#define	RF_CMD_IR_STUDY				0x02
#define	RF_CMD_IR_REPORT			0x03
#define	RF_CMD_GET_VERSION			0x04
#define	RF_CMD_REPORT_VERSION		0x05
#define	RF_CMD_PAIR					0x06
#define	RF_CMD_FactTest				0x07
#define	RF_CMD_BEAT					0x08
#define	RF_CMD_FactTestRsp			0x09
#define RF_CMD_BEAT_STUDY			0x0a

typedef struct
{
	u8 Hour;			// Сʱ
	u8 Minute;			// ����
	u8 ValidFlag;		// ��ʱ��ʹ�ܱ�־
	u8 TimerFlag[7];	// ÿ��Ķ�ʱ��־
	u8 Reserve;			// û��
	u8 cmd;				// ������翪1����0
	u8 powertemp;		// ��Դ�¶ȣ���APP�޹�
	u8 LumiFrom;		// ģʽ��������APP�޹�
	u8 LumiTo;			// �������򣬺�APP�޹�
} TIMER_INFO;
typedef struct
{
	u8 power;
	u8 temp;
	u8 mode;
	u8 wind;
	u8 dir;
	u8 op;
	struct
	{
		u16 brand;
		u16 index;
	} model;
} ARC_Struct;
typedef struct
{
	u8 powertemp;
	u8 winddir;
	u8 modeop;
} AC_STATUS;
typedef struct
{
	u32 len;
	u32 checksum;
	u32 version;
	u32 startaddr;
	u32 *data;
} binfile_t;
typedef struct
{
	AC_STATUS action;
	char name[NAME_LEN];
} SCENE;
typedef struct
{
	u32 nid;
	u8 fakeid;
	u8 sn;
	u16 sku;
	u16 brand;
	u16 model;
	AC_STATUS status;
	TIMER_INFO Timer[MAX_TIMER];
	char name[NAME_LEN];
	SCENE Scene[MAX_SCENE];
	u8 remoteid[64];
	u8 type;
	u8 subtype;
	u8 reptn;
} DEVICE;
typedef struct
{
	u32 id;
	u8 bid;
	u8 type;
	u8 len;
	u8 para1;
	u8 dat[STUDY_DAT_LEN];
	char name[NAME_LEN];
} STUDY;
typedef struct
{
	u8 exist;
	u8 id[4];
} REPEATER;
typedef union
{
	struct
	{
		u8 len;
		u8 enc;
		u8 roll;
		u8 id[4];
		u8 type;
		u8 rept;
		u8 reptt;
		u8 cmd;
		u8 para[53];
	} Bytes;
	u8 buf[64];
} RF24G;
typedef struct _SYS_
{
//u8 smartconfig_do;
	struct
	{
		u8 State;
		u8 Version;
		u8 Option[2];
		u8 ID[2];
	} Mcup;
	struct
	{
		u8 Version;
	} Mcu;

	struct
	{
		u32 selfID;
		u8 selfSN[10];
		u32 hex_ip;						// hex server ip address
		u32 iot_ip;						// iot server ip address
		u32 outip;						// router out ip address
		u16 outport;					// router out port
		u8 stamac[6];
		struct ip_info ipinfo;
		struct station_config stainfo;
		struct
		{
			u8 hasip;
			u8 hasiotip;
			u8 hashexip;
			u8 tcpcsend;
		} Stuatus;
	} Net;
	struct
	{
		struct
		{
			u32 ms;
		} sys;
		u32 timestamp;
		ST_OPPLE_TIME rtc;
	} Time;
	struct
	{
		struct
		{
			u32 excutestamp;
		} Timer[MAX_TIMER];
	} DTimer[MAX_DEVICE];
	struct
	{
		u32 timeout;
		u8 smartconfiging;
		u8 forceupgrade;
		u8 upgrading;
		u8 study;
		u8 study_type;
		u8 study_func;
		u8 scenen;
		u8 doscene;
	} Status;
	struct
	{
		u8 a;
		u8 b;
		u8 c;
		u8 BlankFlag;
		u8 sn;								// sn counter
		u8 verh;
		u8 verl;
		s8 timezone;						// ʱ��
		u8 aucOpPwd[16];					//��Ʒ��������
		DEVICE Device[MAX_DEVICE];
		REPEATER Repeater[MAX_REPEATER];
	} Config;

	char rsp_name[NAME_LEN];
	u8 rsp_remoteid[64];					// maybe not used
	u8 rsp_bid;
	u8 debug;
	u8 facttest;
	u8 RFtest;
	u8 Rftestfactory;
	u8 idready;
	u32 idbeatcout;

	struct
	{
		u32 id;
		u32 srcidtype;
		u32 srcid;
		u32 transno[MAX_TRANSNO];
		u32 no;
		u32 rno;
		u32 ip;
		u32 port;
		u8 find_dev_pak;
	} NetSend;
	u8 buf[120];
	u16 len;
	u8 irrept;
} SYS;

#define is_same_net(addr1) ((addr1&Sys.Net.ipinfo.netmask.addr) == (Sys.Net.ipinfo.ip.addr&Sys.Net.ipinfo.netmask.addr))

extern SYS Sys;

#endif
