#ifndef __USER_IR_PROC_H__
#define __USER_IR_PROC_H__
/*
 *ver 1.04
 *change function ir_learn_start para type from pointer type to non-pointer type .
*ver 1.03
*disable timer1 after sending or learning are completed.
*ver 1.02
*support new data format.
*ver 1.0.1
*while no any input,changing 15s to 1s waiting time to avoid system reset.
*
* ver 1.0
*ir_sent_start  use MTMS(GPIO14)for 38khz output,hw timer for sending delay
*ir_learn_start use hw timer,GPIO12 for ir receiving
*/
extern void IR_Sent_Start(unsigned char Buf1[], unsigned short Lenth);//sucess return 0x66, return 0 if don't receive data over 1s
//extern unsigned char IR_Learn_Start(unsigned char Buf1[], unsigned short *Len);
extern unsigned char IR_Learn_Start(unsigned char Buf1[], unsigned short Len);
extern void Data_transfer(unsigned char Buf0_Rx[], unsigned char Buf0_Tx[],  unsigned char Buf1_Rx[], unsigned char Buf1_Tx[]);
//extern void IR_TestSent_Start(unsigned char Buf0[],unsigned char Buf1[]);
void tj_tx_init();

#endif
