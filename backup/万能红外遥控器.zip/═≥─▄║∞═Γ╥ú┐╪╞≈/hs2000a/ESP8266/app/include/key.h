#ifndef __USER_KEY_H__
#define __USER_KEY_H__

#define press_time_min	300			//  5s
#define press_time_max	500			// 10s
#define click_time_min	2			// 0.03s
#define click_time_max	50			// 0.5s

#define	LONG_PRESS_KEEP		254
#define	LONG_PRESS_RELEASE	255


void key_init(void);



#endif

