
#ifndef __OPP_STD_H__
#define __OPP_STD_H__

#define VOID void

#define INVALID_U8_VAL       (0xff)
#define INVALID_U16_VAL      (0xffff)
#define INVALID_U32_VAL      (0xffffffff)

#define VALID_VALUE          (1)
#define IS_VALID_VALUE(a)    (VALID_VALUE == (a))
#define IS_INVALID_VALUE(a)  ((0 == (a)) || (INVALID_U8_VAL == (a)) \
    || (INVALID_U16_VAL == (a)) || (INVALID_U32_VAL == (a)))

/*�ֽ���ת���궨��*/
#if 1
/*������(С����)��������(�����)�෴*/

//For Linux ?????
#if 0

#define OPP_NTOHL(x) ntohl((x))

#define OPP_NTOHS(x) ntohs((x))

#else

#define OPP_NTOHL(x)  ((((x) & 0xff000000) >> 24) \
    | (((x) & 0x00ff0000) >> 8) \
    | (((x) & 0x0000ff00) << 8) \
    | (((x) & 0x000000ff) << 24))

#define OPP_NTOHS(x)  ((((x) & 0xff00) >> 8) | (((x) & 0x00ff) << 8))

#endif

#else
/*������(�����)��������(�����)һ��*/

#define OPP_NTOHL(x)  (x)

#define OPP_NTOHS(x)  (x)

#endif
#define OPP_HTONL(x)  (OPP_NTOHL((x)))
#define OPP_HTONS(x)  (OPP_NTOHS((x)))

#define OPP_SWAP_L(x)  do {\
    x = OPP_NTOHL((x));\
} while(0)

#define OPP_SWAP_S(x)  do {\
    x = OPP_NTOHS((x));\
} while(0)

typedef u8 U8;
typedef s8 S8;

typedef u16 U16;
typedef s16 S16;

typedef u32 U32;
typedef s32 S32;

typedef float FLOAT;
typedef double DOUBLE;

#define OffsetOf(TYPE, MEMBER)  ((U32)(&(((TYPE*)0)->MEMBER)))
#define OffsetOfNext(TYPE, MEMBER)  (OffsetOf(TYPE, MEMBER) + sizeof(((TYPE*)0)->MEMBER))
#define OPP_ARRAY_SIZE(x)       (sizeof(x) / sizeof(x[0]))

#endif /*__OPP_STD_H__*/

