
#ifndef	_DELAY_H_
#define	_DELAY_H_


void _delay_us(unsigned int t);
void _delay_ms(unsigned int t);
void _delay_us_timer(u16 t);

#endif
